<?php

define('SPECIFIED_EXTENSIONS_TEXT', ['txt', 'csv', 'log', 'ini', 'json', 'xml', 'yaml', 'yml', 'md', 'rtf', 'doc', 'docx', 'css', 'html', 'php', 'htm', 'js']);
define('SPECIFIED_EXTENSIONS_IMAGE', ['jpg', 'jpeg', 'png', 'gif', 'bmp', 'tif', 'tiff', 'ico', 'svg', 'webp']);
define('SPECIFIED_EXTENSIONS_AUDIO', ['mp3', 'wav', 'ogg', 'mp4', 'avi', 'mkv', 'mov', 'flv', 'wmv']);
define('SPECIFIED_EXTENSIONS_SCRIPTS', ['exe', 'msi', 'sh', 'bash', 'bat', 'cmd', 'ps1']);
define('SPECIFIED_EXTENSIONS_ARCHIWE', ['zip', 'rar', '7z', 'tar', 'gz', 'xz']);
define('SPECIFIED_EXTENSIONS_OTHER', ['db', 'torrent', 'iso']);

$folderPath = './';
