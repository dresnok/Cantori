<?php
/**
 * ContatoreVisitatori.php
 * 
 * Autor: [GRAVITYX - accordian.org.pl]
 * Data utworzenia: [09:30 piątek, 6 września 2024]
 * Opis: Plik główny - nie zmieniaj nazw plików, powinien być dołączony w pliku np. 'index.php'.
 * Wersja: 2.3
 */
 
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}
date_default_timezone_set('Europe/Warsaw');
define('VISITS_FILE', 'cantori/visits.php');
define('VISITORS_FILE', 'cantori/visitors.txt');
define('SUSIP_FILE', 'cantori/susip.txt');
define('ERROR_FILE', 'errorFile.log');
define('FUNCTION_CANTORI', 'cantori/loadFile/function_cantori.php');
define('VISITS_FILE_S', 'cantori/visits2.php');
define('IPEX', 'cantori/ipEx.txt');
define('VISITORS_UNIK', 'cantori/newVisitors.php');
define('RESET_DATE', 'cantori/reset_date.txt');

if (file_exists(VISITS_FILE_S)) {
    include (VISITS_FILE_S);
}
include(FUNCTION_CANTORI);
include_once 'cantori/loadFile/vistits_file.php';


if (!file_exists(VISITS_FILE)) {
    justTo(VISITS_FILE);
} else {
    include VISITS_FILE;
}

// Pobranie adresu IP użytkownika
$userIp = $_SERVER['REMOTE_ADDR'];


 if (!isset($_COOKIE['unique_visit'])) {
    if (!checkIpExists($userIp)) {
        // Rejestracja danych wizyty
        countUniqueVisit();
	}
}
if (!empty($newFile)) {
    $errorData = "Data błędu: " . date('Y-m-d H:i:s') . "\n";
    $errorData.= "Lista błędów:\n";
    foreach ($newFile as $error) {
        $errorData.= $error . "\n";
    }
    $errorData.= "\n";
    file_put_contents(ERROR_FILE, $errorData, FILE_APPEND);
}
?>
</p>


