<?php


// Pobranie adresu IP użytkownika
$user_ip = "85.208.98.229";

// Użycie API do geolokalizacji IP
$api_url = "http://ip-api.com/json/{$user_ip}";

// Pobranie danych z API
$response = file_get_contents($api_url);
$data = json_decode($response, true);

// Wyświetlenie informacji o IP
if ($data['status'] == 'success') {
    echo "Adres IP: " . $data['query'] . "<br>";
    echo "Kraj: " . $data['country'] . "<br>";
    echo "Region: " . $data['regionName'] . "<br>";
    echo "Miasto: " . $data['city'] . "<br>";
    echo "Strefa czasowa: " . $data['timezone'] . "<br>";
    echo "Dostawca usług internetowych (ISP): " . $data['isp'] . "<br>";
} else {
    echo "Nie udało się pobrać informacji o IP.";
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <style>
       p {
  --line-clamp: 4;
  
  display: -webkit-box;
  -webkit-line-clamp: var(--line-clamp);
  -webkit-box-orient: vertical;
  
  /* extra demo styles */
  resize: vertical;
  padding-inline: 1em;
  hyphens: auto;
  width: 300px;
  min-width: 200px;
  max-width: 90%;
  border: 1em solid white;
  background: white;
  border-radius: 4px;
  margin: 0;
  overflow: hidden;
}

p::before {
  content: '';
  float: right;
  height: calc((var(--line-clamp) - 1) * 1lh);
}

p .show-more {
  clear: both;
  float: right;
  
  /* extra demo styles */
  margin-left: .5em;
  text-decoration: underline;
  cursor: pointer;
  color: DodgerBlue;
  font-size: 0.85em;
  line-height: 1.5; /* because of smaller font-size, need to align to bottom */
}

/* 
  no need to render the "show more" link if 
  the text is fully-visible and not truncated
*/
p:not(.truncated) .show-more {
  display: none;
}

p .show-more:hover {
  text-decoration: none;
}

body {
  display: grid;
  place-items: center;
  align-content: center;
  gap: 1em;
  font: 22px Roboto, Arial;
  height: 100vh;
  padding: 0;
  overflow: hidden;
  background: linear-gradient(to right top in lch, rgb(134, 239, 172), rgb(59, 130, 246), rgb(147, 51, 234));
}

h1 {
  font-size: 1.2em;
  text-align: center;
  color: #FFFFFF99;
}

h1 span { display: inline-block; }
    </style>
</head>
<body>


<form action="delete.php" method="post" onsubmit="return confirm('Czy na pewno chcesz usunąć ten plik?');">
    <input type="hidden" name="filename" value="plik_do_usunięcia.txt">
    <button type="submit">Usuń plik</button>
</form>



   <h1>
  <em>"Show More"</em> link is only visible <span>while text is truncated.</span><br>
Try resizing the box horizontally:
</h1>

<p id='truncatedContainer'>
  <a class='show-more'>Show More</a>
  Lorem ipsum dolor sit amet, consectetur adipiscing elit, 
  sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. 
  Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris
  nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor
</p>

<script>
function isTextTruncated(node){  
  const truncated = node.scrollHeight > node.clientHeight
  node.classList.toggle('truncated', truncated)
}

// observe resize
const resizeObserver = new ResizeObserver(m => isTextTruncated(m[0].target))

resizeObserver.observe(truncatedContainer, { attributes: true })
</script>