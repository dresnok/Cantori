<?php
/**
 * ContatoreVisitatori.php
 * 
 * Autor: [GRAVITYX - accordian.org.pl]
 * Data utworzenia: [09:30 piątek, 6 września 2024]
 * Opis: Panel administracyjny - nie zmieniaj nazw plików, usuwając pliki lub foldery możesz przerwać działanie skryptu.
 * Wersj3: 1.1, 2.1, 2.2, 2.3
 
 */
 
$lifetime = 30 * 24 * 60 * 60; // 30 dni w sekundach - odnośnie refresh_count2
session_set_cookie_params($lifetime);
date_default_timezone_set('Europe/Warsaw');

if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}



include_once'cantori/loadFile/modifica.php';

if (!isset($_SESSION['user_id'])) {
    header('Location: ' . LOGIN);
    exit();
}

if ($_SERVER["REQUEST_METHOD"] === "POST" && isset($_POST['visits_file_s'])) {
    file_put_contents(VISITS_FILE_S, "<?php\nconst LOAD_TIMES = array ();\n?>");
}

	if (!isset($_SESSION['refresh_count2'])) {
    $_SESSION['refresh_count2'] = 0;
}

if (file_exists(VISITS_FILE_S)) {
    include VISITS_FILE_S;
} elseif(($_SESSION['refresh_count2'] < 3)) {
	
	$_SESSION['refresh_count2']++;
	
    echo '<div class="alert alert-secondary">Prawdopodobnie nie chcesz lub nie dołączyłeś kodu niezbędnego do pomiaru szybkości wczytywania strony. Przeczytaj więcej: <a href="cantori/readmy/README.md" target="_blank" title="readme">README.md</a>, lub pod adresem <a href="https://github.com/dresnok/Cantori" target="_blank">https://github.com/dresnok/Cantori</a>.<br><form action="' . htmlspecialchars($_SERVER['PHP_SELF']) . '" method="post"><input type="hidden" name="visits_file_s"><label><i>Utwórz plik tymczasowy</i> </label> <input value="Prześlij" type="submit"></form></div>';
}


include_once(FUNCTIONE);
?>



<!DOCTYPE html>
<html lang="pl">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Panel Statystyk Strony</title>
  <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet"><link id="customStylesheet" rel="stylesheet" href="cantori/css/normalize.css">
  <link id="customStylesheet" rel="stylesheet" href="cantori/css/styl-gl.css">
  
  <link href="https://fonts.googleapis.com/css2?family=Cairo+Play:wght@200..1000&display=swap" rel="stylesheet">

  <style>
  
  @import url('https://fonts.googleapis.com/css2?family=Cairo+Play:wght@200..1000&display=swap');

@import url('https://fonts.googleapis.com/css2?family=Reem+Kufi+Fun:wght@400..700&display=swap');


  body {
	  background:url(<?php displayFilePaths(TARGETDIRECTORY); ?>) no-repeat;
	  background-attachment: fixed;
        background-color: #1e2b35;
		background-size: cover;
        color: #cdd3d8;
        font-family:  Arial, sans-serif;
		
    }

    .container {
        width: 70%;
        margin: 0 auto;
        background-color: #2d3e50;
        padding: 20px;

    }

.container a {
	font-family: "Reem Kufi Fun", sans-serif, Arial, sans-serif;
}
    .table td, .table th {
        padding: 10px;
        border: 1px solid #2d3e50;
        text-align: left;
        border-radius: 5px;
        transition: background-color 0.3s;
        background-color: #3a4b61;
        color: #cdd3d8;
    }

    .table td:hover, .table th:hover {
        background-color: #4e6a88;
    }

    .section, .header {
        margin-bottom: 20px;
    }

    .section h2 {
        font-size: 1.5em;
        margin-bottom: 15px;
        color: #7aa6c7;
    }

    .header h1 {
        font-size: 2em;
        margin-bottom: 15px;
        color: #cdd3d8;
    }

    .header h5 {
        font-size: 1.2em;
        color: #7aa6c7;
    }

   

    

    form {
        display: inline;
    }
@media (max-width: 800px) { 
td.at > input {
	width:50px;
}
 }

td.userIpCounts {max-height: 800px;
overflow-y: auto;display: block; }

a:link.vok, a:visited.vok {
	color:grey;
	
}

input[type=checkbox] {
	margin: 0 5px;
}


 button[type="submit"], input[type="submit"], input[type="button"], input[type="file"], button, select {
        padding: 10px 20px;
        border: none;
 border-radius: 5px ;
    box-shadow: inset 0 -2px 0 0 #6a8eae;
    padding: 8px;
        cursor: pointer;
        font-size: 16px;
        background-color: #6a8eae;
        color: #fff;
background-color: #587a9b;
		margin:3px;

    }

.ffPath {
    border-color: #3498db;
    box-shadow: none;
    transition: all 0.2s ease-in-out;
}

.ffPath:focus,
.ffPath:active {
    
    outline: none;
	color:silver;
}

.kkFile
{
	display: flex;justify-content: center;	
}


</style>
</head>
<body>

<?php

if(isset($_SESSION['newInfo'])){
    // Wyświetlenie komunikatu
    echo "<div class='alert alert-secondary'>" . $_SESSION['newInfo'] . "</div>";

    // Sprawdzenie i zwiększenie licznika odświeżeń
    if(!isset($_SESSION['newInfo1'])) {
        $_SESSION['newInfo1'] = 1; // Inicjalizacja licznika
    } else {
        $_SESSION['newInfo1']++; // Zwiększenie licznika przy każdym odświeżeniu
    }

    // Sprawdzenie, czy licznik osiągnął 2
    if($_SESSION['newInfo1'] >= 5) {
        // Lista kluczy sesji, które mają zostać zachowane
$keep_keys = ['user_id', 'csrf_token', 'csrf_token1', 'csrf_token2'];

// Iteracja przez wszystkie zmienne sesji
foreach ($_SESSION as $key => $value) {
    // Usuwanie zmiennych sesji, które nie są na liście do zachowania
    if (!in_array($key, $keep_keys)) {
        unset($_SESSION[$key]);
    }
}
    }
}
if (isset($_SESSION['newError'])) {
    echo "<div class='alert alert-secondary'>" . $_SESSION['newError'] . "</div>";
    $errorData = "Data błędu: " . date('Y-m-d H:i:s') . "\n";
    $errorData .= "Lista błędów:\n";

    if (is_array($_SESSION['newError'])) {
        $newError = $_SESSION['newError'];
        foreach ($newError as $info) {
            $errorData .= $info . "\n";
        }
    } else {
        $errorData .= $_SESSION['newError'] . "\n";
    }

file_put_contents('errorFile.log', $errorData . PHP_EOL, FILE_APPEND | LOCK_EX);
unset($_SESSION['newError']);
}

?> 


<div class="container">
    <div class="header">
	<div class="row my-3">
	<div class="col-6">
        <h1 style="display:inline">Panel Administracyjny</h1><br>
		<a href="https://accordian.org.pl/" title="link" class="vok">https://accordian.org.pl/</a>
		</div>
		<div class="clock col-6">
        <div class="time">
        
		<?php if(isset($time)){echo $time;}; ?>
        </div>
		
        <div class="date">
            <?php if(isset($date)){echo $date;} ?>
			



			<p><a href="http://cantori.antyki.space/" title="link" class="vok">http://cantori.antyki.space/</a></p>
    </div></div></div>
		
		<div class="my-3">
		   <form method="post" action="<?php echo(LOGIN);?>">
        
        <input type="hidden" name="logout">
        <input type="submit" value="Logout">
    </form></div>

    <!-- Wyświetlanie wyników tylko po wysłaniu formularza -->

        <div class="section">
            <h2>Rozmiar projektu (<?php if(isset($_SESSION['folderPath'])){echo $_SESSION['folderPath'];}else{echo"./";}?>)</h2>
<form method="post" action="<?php echo htmlspecialchars($_SERVER['PHP_SELF']); ?>">

<input class="btn btn-sm ffPath"  autocomplete="on" type="text" name="folderPath" id="folderPath" placeholder="Podaj ścieżkę">
<input type="hidden" name="csrf_token" value="<?php echo ($_SESSION['csrf_token']); ?>">
<input type="hidden" name="seeMore">
<button type="submit">Wczytaj dane</button>
</form>
		
        </div>
		
		    <?php
if (!isset($_SESSION['csrf_token'])) {
        echo "Nieudana próba CSRF 'info.php'.";
		unset($_SESSION['user_id']);
exit();
    }
			if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['seeMore'])): ?>
        <div class="section">
            <table class="table">
                <tbody>
                    <tr>
                        <td>Pliki tekstowe: <?php if (isset($waga_pText)) echo $waga_pText; ?> MB</td>
                    </tr>
                    <tr>
                        <td>Pliki graficzne: <?php if (isset($waga_pImage)) echo $waga_pImage; ?> MB</td>
                    </tr>
                    <tr>
                        <td>Pliki audio: <?php if (isset($waga_pAudio)) echo $waga_pAudio; ?> MB</td>
                    </tr>
                    <tr>
                        <td>Pliki skryptowe: <?php if (isset($waga_pScripts)) echo $waga_pScripts; ?> MB</td>
                    </tr>
                    <tr>
                        <td>Pliki archiwów: <?php if (isset($waga_pArchiwe)) echo $waga_pArchiwe; ?> MB</td>
                    </tr>
                    <tr>
                        <td>Inne pliki: <?php if (isset($waga_pOther)) echo $waga_pOther; ?> MB</td>

                    </tr>

                </tbody>
            </table>

        </div>
		   <?php endif; ?>


<div class="section">
            <h2>Średni czas ładowania strony (cantori/visits.php)</h2>
			
			<div class="section">
            
            <table class="table">
			<tbody><tr>
           <td><?php if(isset($averageLoadTime)){echo number_format($averageLoadTime, 2);} ?> ms</td>
			</tbody>
			</table>
						
			
			</div></div>
			
			<div class="section">
			
			<table class="table">
                <tbody>
           
			<tr><td> 5 ostanich wspisów:</td></tr> 
<?php
if (isset($lastEntries)) {
    $currentTime = date("Y-m-d H:i:s");
    foreach ($lastEntries as $entryTime) {
        echo "<tr><td>$entryTime ms</td></tr>";
    }
}
?>
			
            
			</tbody></table>
				</div>



<!-- Wizyty użytkowników -->
<div class="section">



<div class="my-3">
<a id="loadButton1" class="btn btn-secondary">Wizyty</a>
<!--<a id="loadButton3" class="btn btn-secondary">Okienka</a>-->
<a id="loadButton2" class="btn btn-secondary">Operacje</a>
</div>

<div id="content"></div>


		
		<script>
document.addEventListener("DOMContentLoaded", function() {
    // Odczytaj ID ostatnio załadowanego przycisku z localStorage
    var lastButtonId = localStorage.getItem('lastLoadedButton');
    
    // Wczytaj plik na podstawie ostatnio załadowanego przycisku
    if (lastButtonId === 'loadButton1') {
        loadFile('cantori/menu/info.php', lastButtonId);
    } else if (lastButtonId === 'loadButton2') {
        loadFile('cantori/menu/operations.php', lastButtonId);
    } else {
        // Domyślnie wczytaj info.php, jeśli nie ma zapisanych danych
        loadFile('cantori/menu/info.php', 'loadButton1');
    }
});

document.getElementById('loadButton1').addEventListener('click', function() {
    loadFile('cantori/menu/info.php', 'loadButton1');
});

document.getElementById('loadButton2').addEventListener('click', function() {
    loadFile('cantori/menu/operations.php', 'loadButton2');
});




 function loadFile(filename, buttonId) {
    var xhr = new XMLHttpRequest();
    xhr.open('GET', filename, true);
    xhr.onreadystatechange = function() {
        if (xhr.readyState === XMLHttpRequest.DONE) {
            if (xhr.status === 200) {
                document.getElementById('content').innerHTML = xhr.responseText;
                // Zapisz ID przycisku do localStorage
                localStorage.setItem('lastLoadedButton', buttonId);
            } else {
                console.error('Wystąpił błąd podczas wczytywania pliku.');
            }
        }
    };
    xhr.send();
}




</script>
		</div>
		

						


				
<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js"></script><script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
