<?php
define('NA_DZIEN', 2);
define('NA_TYDZIEN', 2);
define('NA_MIESIAC', 4);
define('STYCZEN', 0);
define('LUTY', 0);
define('MARZEC', 0);
define('KWIECIEN', 0);
define('MAJ', 0);
define('CZERWIEC', 0);
define('LIPIEC', 0);
define('SIERPIEN', 0);
define('WRZESIEN', 0);
define('PAZDZIERNIK', 3);
define('LISTOPAD', 0);
define('GRUDZIEN', 0);
