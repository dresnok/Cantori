<?php
define('NA_DZIEN', 1);
define('NA_TYDZIEN', 1);
define('NA_MIESIAC', 1);
define('STYCZEN', 0);
define('LUTY', 0);
define('MARZEC', 0);
define('KWIECIEN', 0);
define('MAJ', 0);
define('CZERWIEC', 0);
define('LIPIEC', 0);
define('SIERPIEN', 0);
define('WRZESIEN', 1);
define('PAZDZIERNIK', 0);
define('LISTOPAD', 0);
define('GRUDZIEN', 0);
