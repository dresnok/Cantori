<?php
session_start();

$action = isset($_GET['usun']) ? strip_tags($_GET['usun']) : null;
$allowed_actions = ['apocalypse', 'backup', 'last_year', 'downloadFile'];

if ($action && in_array($action, $allowed_actions)) {

    define('INFO_FILE', '../../info.php');

    // Pliki
    define('SUSIP_FILE', '../susip.txt');
    define('VISITS_FILE', '../visits.php');
    define('VISITORS_FILE', '../visitors.txt');
    define('IPEX', '../ipEx.txt');
    define('VISITORS_UNIK', '../newVisitors.php');
	define('VISITS_FILE_S', '../visits2.php');

    // Katalogi
    define('BACKUPDIRECTORY', '../backup/');
    define('DOWNLOADFILE', '../downloadFile/');
    define('LAST_YEAR', '../last_year/');

    switch ($action) {

        case "apocalypse":
            // Tablica z plikami do usunięcia
            $filesToDelete = array(VISITS_FILE_S, SUSIP_FILE, VISITS_FILE, VISITORS_FILE, VISITORS_UNIK, IPEX);

            // Usunięcie plików
            foreach ($filesToDelete as $file) {
                if (is_file($file)) {
                    unlink($file);
                }
            }


                $_SESSION['newInfo'] = "Udało się usunąć pliki.<br>";
       

            // Usunięcie zawartości katalogów
            $directoriesToDelete = array(BACKUPDIRECTORY, DOWNLOADFILE, LAST_YEAR);

            foreach ($directoriesToDelete as $dirPath) {
                if (is_dir($dirPath)) {
                    $files = array_diff(scandir($dirPath), array('.', '..'));
                    foreach ($files as $file) {
                        $filePath = $dirPath . '/' . $file;
                        if (is_file($filePath)) {
                            unlink($filePath);
                        }
                    }
					
                }
            }
$_SESSION['newInfo'] .= "Udało się opróżnić folder.";
       

            break;

        case "backup":
        case "last_year":
        case "downloadFile":
            $dirPath = ".." . DIRECTORY_SEPARATOR . $action . DIRECTORY_SEPARATOR;
            if (is_dir($dirPath)) {
                $files = array_diff(scandir($dirPath), array('.', '..'));
                foreach ($files as $file) {
                    $filePath = $dirPath . '/' . $file;
                    if (is_file($filePath)) {
                        unlink($filePath);
                    }
                }

               
                    $_SESSION['newInfo'] = "Udało się usunąć pliki z folderu: " . $action;
               
            } else {
                $_SESSION['newError'] = "Błąd: Folder " . $action . " nie istnieje.";
            }
            break;

        default:
            $_SESSION['newError'] = "Błąd: Nieznana akcja.";
            break;
    }

    header("Location: " . INFO_FILE);
    exit;
} else {
    $_SESSION['newError'] = "Błąd: Nie podano folderu do usunięcia.";
    header("Location: " . INFO_FILE);
    exit;
}
