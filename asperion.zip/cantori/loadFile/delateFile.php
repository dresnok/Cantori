<?php
session_start();
date_default_timezone_set('Europe/Warsaw');
define('INFO_FILE', '../../info.php#ipUnik');
define('SUSIP_FILE', '../susip.txt');
define('VISITS_FILE', '../visits.php');
define('IPEX', '../ipEx.txt');
define('VISITS_FILE_S', '../visits2.php');
define('BACKUPDIRECTORY', '../backup/');
define('DOWNLOADFILE', '../downloadFile/');
define('LAST_YEAR', '../lastYear/');
define('ERROR_FILE', '../../errorFile.log');

$pages = [
    "visits_file" => VISITS_FILE, 
    "susip_file" => SUSIP_FILE, 
    "errorfile" => ERROR_FILE,
];



$action = isset($_GET['usun']) ? strip_tags($_GET['usun']) : null;

if ($action && array_key_exists($action, $pages)) {
    $filePath = $pages[$action];
    if (file_exists($filePath)) {
		$newFilePath = BACKUPDIRECTORY . uniqid() . '_' . basename($file);
        if (rename($filePath, $newFilePath)) {
            $_SESSION['newInfo'] = "Udało się przenieść plik do kosza.";
        } else {
            $_SESSION['newError'] = "Błąd: nie udało się usunąć pliku z powodu problemów z uprawnieniami.";
			echo "Błąd: plik się nie przeniósł.";
        }
    } else {
        $_SESSION['newError'] = "Błąd: plik nie istnieje.";
		echo "Błąd: brak pliku.";
    }
}



$allowed_actions = ['apocalypse', 'backup', 'lastYear', 'downloadFile'];
$action2 = isset($_GET['usunT']) ? strip_tags($_GET['usunT']) : null;
if ($action2 && in_array($action2, $allowed_actions)) {
    switch ($action2) {
        case "apocalypse":
            $filesToDelete = [VISITS_FILE_S, SUSIP_FILE, VISITS_FILE, IPEX, ERROR_FILE];
			
            foreach ($filesToDelete as $file) {
				$filePath = BACKUPDIRECTORY . '/' . $file;
                if (is_file($file)) {
					
					$newFilePath = BACKUPDIRECTORY . uniqid() . '_' . basename($file);
                    rename($file, $newFilePath);
                }
				
            }
            $_SESSION['newInfo'] = "Udało się usunąć pliki.<br>";
			
            $directoriesToDelete = [DOWNLOADFILE, LAST_YEAR, BACKUPDIRECTORY];
foreach ($directoriesToDelete as $dirPath) {
    if (is_dir($dirPath)) {
        // Usunięcie plików
        $files = array_diff(scandir($dirPath), ['.', '..']);
        foreach ($files as $file) {
            $filePath = $dirPath . '/' . $file;
            if (is_file($filePath)) {
                unlink($filePath);
            }
        }
        
        // Usunięcie folderu
        rmdir($dirPath);

        // Ponowne utworzenie folderu
        if (!mkdir($dirPath)) {
            error_log("[" . date("Y-m-d H:i:s") . "] Błąd: nie udało się utworzyć katalogu " . $dirPath . ".");
        }
    }
}

$_SESSION['newInfo'] .= "Udało się opróżnić i ponownie utworzyć foldery.";
            break;

        case "backup":
		$dirPath = ".." . DIRECTORY_SEPARATOR . $action2 . DIRECTORY_SEPARATOR;
            if (is_dir($dirPath)) {
                $files = array_diff(scandir($dirPath), ['.', '..']);
                foreach ($files as $file) {
                    $filePath = $dirPath . '/' . $file;
                    if (is_file($filePath)) {
                        
                            unlink($filePath);
                    }
                }
                $_SESSION['newInfo'] = "Udało się usunąć pliki z folderu";
            } else {
                $_SESSION['newError'] = "Błąd: Folder nie istnieje.";
            }
			
			rmdir($dirPath);
			// Tworzenie folderu na nowo
        if (!mkdir($dirPath)) {
            error_log("[" . date("Y-m-d H:i:s") . "] Błąd: nie udało się utworzyć katalogu " . $dirPath .".");
        }
		
            break;
			
        case "lastYear":
		$dirPath = ".." . DIRECTORY_SEPARATOR . $action2 . DIRECTORY_SEPARATOR;
            if (is_dir($dirPath)) {
                $files = array_diff(scandir($dirPath), ['.', '..']);
                foreach ($files as $file) {
                    $filePath = $dirPath . '/' . $file;
                    if (is_file($filePath)) {
                        $newFilePath = BACKUPDIRECTORY . uniqid() . '_' . basename($file);
                            rename($filePath, $newFilePath);
                    }
                }
                $_SESSION['newInfo'] = "Udało się usunąć pliki z folderu";
            } else {
                $_SESSION['newError'] = "Błąd: Folder nie istnieje.";
            }
			rmdir($dirPath);
			// Tworzenie folderu na nowo
			        if (!mkdir($dirPath)) {
            error_log("[" . date("Y-m-d H:i:s") . "] Błąd: nie udało się utworzyć katalogu " . $dirPath . ".");
        }
			
            break;
			
        case "downloadFile":
            $dirPath = ".." . DIRECTORY_SEPARATOR . $action2 . DIRECTORY_SEPARATOR;
            if (is_dir($dirPath)) {
                $files = array_diff(scandir($dirPath), ['.', '..']);
                foreach ($files as $file) {
                    $filePath = $dirPath . '/' . $file;
                    if (is_file($filePath)) {
                        $newFilePath = BACKUPDIRECTORY . uniqid() . '_' . basename($file);
                            rename($filePath, $newFilePath);
                    }
                }
                $_SESSION['newInfo'] = "Udało się usunąć pliki z folderu";
            } else {
                $_SESSION['newError'] = "Błąd: Folder nie istnieje.";
            }
					rmdir($dirPath);
			// Tworzenie folderu na nowo
			        if (!mkdir($dirPath)) {
            error_log("[" . date("Y-m-d H:i:s") . "] Błąd: nie udało się utworzyć katalogu " . $dirPath . ".");
        }
		
            break;

        default:
            $_SESSION['newError'] = "Błąd: Nieznana akcja.";
            break;
    }
}
header("Location: " . INFO_FILE);
exit;
