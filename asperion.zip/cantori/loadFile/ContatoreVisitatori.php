<?php
/**
 * ContatoreVisitatori.php
 * 
 * Autor: [GRAVITYX - accordian.org.pl]
 * Data utworzenia: [09:30 piątek, 6 września 2024]
 * Opis: Plik główny - nie zmieniaj nazw plików, powinien być dołączony w pliku np. 'index.php'.
 * Wersja: 2.3
 */
 
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}
date_default_timezone_set('Europe/Warsaw');
define('VISITS_FILE', 'cantori/visits.php');
define('SUSIP_FILE', 'cantori/susip.txt');
define('ERROR_FILE', 'errorFile.log');
define('VISITS_FILE_S', 'cantori/visits2.php');
define('IPEX', 'cantori/ipEx.txt');
define('LAST_IP', 'cantori/last_ip.txt');
define('RESET_DATE', 'cantori/reset_date.txt');

if (file_exists(VISITS_FILE_S)) {
    include(VISITS_FILE_S);
}
?>

<?php

#Funkcja pobiera dane wszystkich odsłon strony

function countAllUnit($filePath) {

if (file_exists(LAST_IP)) {
	
$fileContents = file_get_contents(LAST_IP);
return $fileContents;

}
}

#Funkcja zlicza wystąpienia adresów IP z pliku i zwraca ich liczbę.

function countUniqueIps($filePath) {
    // Sprawdzenie, czy plik istnieje
    if (!file_exists($filePath)) {
        echo "Plik nie istnieje.";
        return 0;
    }

    // Odczytaj zawartość pliku
    $fileContents = file($filePath, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);

    // Tablica do zliczania unikalnych adresów IP
    $userIpCounts = [];

    // Przetwarzanie każdego wiersza
    foreach ($fileContents as $line) {
        // Podziel wiersz na pola
        list($entryUrl, $entryBrowser, $entryOs, $entryTime, $entryUserIp, $newData, $newData1, $newData2, $newData3) = explode('|', $line);

        // Zliczaj wystąpienia każdego adresu IP
        if (isset($userIpCounts[$entryUserIp])) {
            $userIpCounts[$entryUserIp]++;
        } else {
            $userIpCounts[$entryUserIp] = 1;
        }
    }

    // Wyświetlenie liczby unikalnych adresów IP
    $uniqueIpCount = 0;
    foreach ($userIpCounts as $userIp => $count) {
        $uniqueIpCount++;
        //echo "Adres IP: $userIp, liczba wystąpień: $count\n";
    }

    //echo "$uniqueIpCount\n";
    return $uniqueIpCount;
}


/**
 * Funkcja `countUniqueIps` zlicza unikalne adresy IP z pliku.
 * Każda linia zawiera informacje o odwiedzinach użytkownika, w tym adres IP.
 *
 * - Funkcja najpierw sprawdza, czy plik istnieje.
 * - Jeśli plik istnieje, jego zawartość zostaje odczytana do tablicy, gdzie każda linia odpowiada jednemu wpisowi.
 * - Dla każdej linii, funkcja dzieli dane na poszczególne pola (np. URL, przeglądarka, system operacyjny, czas, adres IP, itp.).
 * - Na koniec, funkcja wyświetla i zwraca liczbę unikalnych adresów IP.
 */

function logVisitorData($filePath) {
    $time = date("Y-m-d H:i:s");
    $url = filter_var($_SERVER['REQUEST_URI'], FILTER_SANITIZE_STRING);
    $userIp = filter_var($_SERVER['REMOTE_ADDR'], FILTER_VALIDATE_IP);

    $browsers = [
        'Chrome' => 'Google Chrome',
        'Firefox' => 'Mozilla Firefox',
        'Safari' => 'Safari',
        'MSIE' => 'Internet Explorer',
        'Trident' => 'Internet Explorer',
        'Edge' => 'Microsoft Edge'
    ];

    $osList = [
        'Windows NT 10.0' => 'Windows 10',
        'Windows NT 6.3' => 'Windows 8.1',
        'Windows NT 6.2' => 'Windows 8',
        'Windows NT 6.1' => 'Windows 7',
        'Macintosh' => 'Mac OS',
        'Linux' => 'Linux',
        'Android' => 'Android',
        'iPhone' => 'iOS',
        'iPad' => 'iOS'
    ];

    $userAgent = filter_var($_SERVER['HTTP_USER_AGENT'], FILTER_SANITIZE_STRING);

    $browser = 'Inna przeglądarka';
    foreach ($browsers as $key => $value) {
        if (strpos($userAgent, $key) !== false) {
            $browser = $value;
            break;
        }
    }

    $os = 'Inny system operacyjny';
    foreach ($osList as $key => $value) {
        if (strpos($userAgent, $key) !== false) {
            $os = $value;
            break;
        }
    }

    function fetchAndDisplayIPData($ip_address) {
        if (!filter_var($ip_address, FILTER_VALIDATE_IP)) {
            $_SESSION['newFile'] = "Nieprawidłowy adres IP: $ip_address";
            return '';
        }

        $api_url = "http://ip-api.com/json/{$ip_address}";
        $response = @file_get_contents($api_url);

        if ($response !== FALSE) {
            $data = json_decode($response, true);

            if (isset($data['status']) && $data['status'] == 'success') {
                $newData = "ip-api.com: Kraj: " . htmlspecialchars($data['country']) . "|" . "Region: " . htmlspecialchars($data['regionName']) . "|" . "Miasto: " . htmlspecialchars($data['city']) . "|" . "ISP: " . htmlspecialchars($data['isp']) . "|";
                return $newData;
            } else {
                $_SESSION['newFile'] = "Błąd w pobieraniu danych z API dla IP: $ip_address";
            }
        } else {
            $_SESSION['newFile'] = "Nie udało się połączyć z API dla IP: $ip_address";
        }

        return '';
    }

    $newData = fetchAndDisplayIPData($userIp);
    $logEntry = $url . "|" . $browser . "|" . $os . "|" . $time . "|" . $userIp . "|" . $newData . PHP_EOL;
    file_put_contents($filePath, $logEntry, FILE_APPEND | LOCK_EX);
}
?>

<?php

function checkIpExists($userIp, $filePath = IPEX) {
    $file = fopen($filePath, 'r');
    if ($file) {
        while (($line = fgets($file)) !== false) {
            $line = trim($line); // Usunięcie dodatkowych białych znaków
            
            if ($line === $userIp) {
                fclose($file);
                return true; // IP zostało znalezione
            }
        }
        fclose($file);
    }
    return false; // IP nie zostało znalezione
}

function checkIpInFile($ip, $filePath) {
    // Otwieramy plik do odczytu
    $fileContent = file_get_contents($filePath);
    
    // Dzielimy zawartość pliku na wiersze
    $lines = explode("\n", $fileContent);

    // Przeszukujemy każdą linię
    foreach ($lines as $line) {
        // Dzielimy linię na części oddzielone "|"
        $parts = explode('|', $line);

        // Sprawdzamy, czy w linii znajduje się podane IP
        if (in_array($ip, $parts)) {
            return true; // IP istnieje w pliku
        }
    }

    return false; // IP nie istnieje w pliku
}

function getUserIp() {
    // Sprawdź, czy klient używa proxy
    if (!empty($_SERVER['HTTP_CLIENT_IP'])) {
        $ip = $_SERVER['HTTP_CLIENT_IP'];
    } elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
        // Może zawierać listę IP oddzielonych przecinkami, weź pierwsze
        $ip = explode(',', $_SERVER['HTTP_X_FORWARDED_FOR'])[0];
    } else {
        // W ostateczności użyj 'REMOTE_ADDR'
        $ip = $_SERVER['REMOTE_ADDR'];
    }
    
    // Opcjonalnie: zweryfikuj, czy adres IP jest poprawny (IPv4/IPv6)
    if (filter_var($ip, FILTER_VALIDATE_IP)) {
        return $ip;
    } else {
        return 'IP nieprawidłowy';
    }
}




define('REFERER_LOG_FILE', 'cantori/referer_log.txt');

// Funkcja zapisująca referer do pliku logowania
function logReferer() {
    // Sprawdzenie, czy zmienna HTTP_REFERER jest ustawiona
    if (isset($_SERVER['HTTP_REFERER'])) {
        // Pobranie adresu URL z HTTP_REFERER i przefiltrowanie
        $referer = filter_var($_SERVER['HTTP_REFERER'], FILTER_SANITIZE_URL);

        // Data i czas zapisu
        $timestamp = date("Y-m-d H:i:s");

        // Formatowanie danych do zapisu
        $logEntry = $timestamp . " - " . $referer . PHP_EOL;

        // Zapis do pliku referer_log.txt
        file_put_contents(REFERER_LOG_FILE, $logEntry, FILE_APPEND | LOCK_EX);
    }
	else{
		$_SESSION['newFile'] = "HTTP_REFERER null";
	}
}
logReferer();


function incrementCounter($filePath) {
    // Odczytaj zawartość pliku, jeśli istnieje, w przeciwnym razie ustaw wartość początkową
    $counter = file_exists($filePath) ? (int)file_get_contents($filePath) : 0;
    $counter++;

    // Zapisz nową wartość do pliku
    if (file_put_contents($filePath, $counter, LOCK_EX) === false) {
        $_SESSION['newFile'] = "Błąd podczas zapisu do pliku.";
    }
}


function checkNewYear() {
    $currentYear = date('Y');
    $lastYear = $currentYear - 1;
    $lastYearFile = 'cantori/lastYear/visits_' . $lastYear . '.php';
    $lastYearFile1 = 'cantori/lastYear/susip_' . $lastYear . '.php';

    if (date('m-d') !== '01-01' || file_exists($lastYearFile)) {
        return;
    }

    if (file_exists(VISITS_FILE)) {
        if (copy(VISITS_FILE, $lastYearFile)) {
            $_SESSION['newFile'] = "Plik 'visits' został skopiowany: " . $lastYearFile;
        } else {
            $_SESSION['newFile'] = "Backup z ostatniego roku dla 'visits' nie powiódł się.";
        }
    } else {
        $_SESSION['newFile'] = "Plik 'visits' nie istnieje.";
    }
}

function resetCountersIfNeeded() {
    $_SESSION['unique_visits_day'] = NA_DZIEN;
    $_SESSION['unique_visits_week'] = NA_TYDZIEN;
    $_SESSION['unique_visits_month'] = NA_MIESIAC;
    $_SESSION['monthly_visits'] = [
        'STYCZEN' => STYCZEN,
        'LUTY' => LUTY,
        'MARZEC' => MARZEC,
        'KWIECIEN' => KWIECIEN,
        'MAJ' => MAJ,
        'CZERWIEC' => CZERWIEC,
        'LIPIEC' => LIPIEC,
        'SIERPIEN' => SIERPIEN,
        'WRZESIEN' => WRZESIEN,
        'PAZDZIERNIK' => PAZDZIERNIK,
        'LISTOPAD' => LISTOPAD,
        'GRUDZIEN' => GRUDZIEN,
    ];
}


function reset_another() {
    
    $resetFile = RESET_DATE;
    $resetDate = file_exists($resetFile) ? file_get_contents($resetFile) : 0;
    $resetDate = $resetDate ? strtotime($resetDate) : 0;
    $currentDate = time();
    
    // Flaga wskazująca, czy powinno nastąpić zapisanie danych
    $shouldSave = false;

    if ($resetDate == 0 || date('Y-m-d', $resetDate) != date('Y-m-d', $currentDate)) {
		if (!isset($_COOKIE['unique_visit'])) {
        $_SESSION['unique_visits_day'] = 1;
		}
		else{
			$_SESSION['unique_visits_day'] = 0;
		}
        $shouldSave = true; // Dzień się zmienił, ustaw flagę
        file_put_contents($resetFile, date('Y-m-d H:i:s', $currentDate));
    }

    if ($resetDate == 0 || date('W', $resetDate) != date('W', $currentDate)) {
		if (!isset($_COOKIE['unique_visit'])) {
			$_SESSION['unique_visits_week'] = 1;
			}
			else{
        $_SESSION['unique_visits_week'] = 0;
			}
        $shouldSave = true; // Tydzień się zmienił, ustaw flagę
    }

    if ($resetDate == 0 || date('Y-m', $resetDate) != date('Y-m', $currentDate)) {
		if (!isset($_COOKIE['unique_visit'])) {
			$_SESSION['unique_visits_month'] = 1;
		}
		else{
        $_SESSION['unique_visits_month'] = 0;
		}
        $shouldSave = true; // Miesiąc się zmienił, ustaw flagę
    }
    
    // Zapisz dane, tylko jeśli powinno nastąpić zapisanie
    if ($shouldSave) {
        saveVisitCounts(
            $_SESSION['unique_visits_day'],
            $_SESSION['unique_visits_week'],
            $_SESSION['unique_visits_month'],
            $_SESSION['monthly_visits']
        );
    }
}

function countUniqueVisit() {
    
    logVisitorData(SUSIP_FILE);

    $_SESSION['unique_visits_day'] += 1;
    $_SESSION['unique_visits_week'] += 1;
    $_SESSION['unique_visits_month'] += 1;

    $englishToPolishMonths = [
        'January' => 'STYCZEN',
        'February' => 'LUTY',
        'March' => 'MARZEC',
        'April' => 'KWIECIEN',
        'May' => 'MAJ',
        'June' => 'CZERWIEC',
        'July' => 'LIPIEC',
        'August' => 'SIERPIEN',
        'September' => 'WRZESIEN',
        'October' => 'PAZDZIERNIK',
        'November' => 'LISTOPAD',
        'December' => 'GRUDZIEN',
    ];
    $currentMonth = strtoupper($englishToPolishMonths[date('F')]);

    $_SESSION['monthly_visits'][$currentMonth] += 1;
    setcookie('unique_visit', '1', time() + (86400), "/");

    saveVisitCounts(
        $_SESSION['unique_visits_day'],
        $_SESSION['unique_visits_week'],
        $_SESSION['unique_visits_month'],
        $_SESSION['monthly_visits']
    );
}


function startTimer() {
    global $startTime;
    $startTime = microtime(true);
}

function endTimer() {
    global $startTime;
    $endTime = microtime(true);
    $loadTime = ($endTime - $startTime) * 1000;

    $updatedLoadTimes = updateLoadTimes($loadTime);
    $averageLoadTime = array_sum($updatedLoadTimes) / count($updatedLoadTimes);

    return [
        'currentLoadTime' => number_format($loadTime, 2),
        'averageLoadTime' => number_format($averageLoadTime, 2)
    ];
}

function updateLoadTimes($newLoadTime) {
    $loadTimes = [];

    if (defined('LOAD_TIMES')) {
        $loadTimes = LOAD_TIMES;
    }

    if (count($loadTimes) >= 5) {
        array_shift($loadTimes);
    }
    $loadTimes[] = str_replace('.', ',', number_format($newLoadTime, 2));

    $data = "<?php\n";
    $data .= "const LOAD_TIMES = " . var_export($loadTimes, true) . ";\n";
    $data .= "?>";

    file_put_contents(VISITS_FILE_S, $data);

    return $loadTimes;
}

?>

<?php

include 'cantori/loadFile/vistits_file.php';


if (!file_exists(VISITS_FILE)) {

//vistits_file.php
    justTo(VISITS_FILE);
} else {
    include(VISITS_FILE);
}

// Pobranie adresu IP użytkownika
$userIp = getUserIp();
resetCountersIfNeeded();

reset_another();

if (!isset($_COOKIE['unique_visit'])) {
    if (!checkIpExists($userIp)) {
        // Rejestracja danych wizyty
        countUniqueVisit();
    }
} 


if (checkIpInFile($userIp, SUSIP_FILE)) {
    incrementCounter(LAST_IP);
}


// Sprawdzanie zmiennej sesyjnej i zapisywanie błędów
if (!empty($_SESSION['newFile'])) {
    $errorData = "Data błędu: " . date('Y-m-d H:i:s') . "\n";
    $errorData .= "Lista błędów:\n";
    
    // Użyj $_SESSION['newFile'] zamiast $newFile
    if (is_array($_SESSION['newFile'])) {
        foreach ($_SESSION['newFile'] as $error) {
            $errorData .= $error . "\n";
        }
    }
    
    $errorData .= "\n";
    file_put_contents(ERROR_FILE, $errorData, FILE_APPEND);
}

?>
