<?php
/**
 * ContatoreVisitatori.php
 * 
 * Autor: [GRAVITYX - accordian.org.pl]
 * Data utworzenia: [09:30 piątek, 6 września 2024]
 * Opis: Plik główny - nie zmieniaj nazw plików, powinien być dołączony w pliku np. 'index.php'.
 * Wersja: 2.3
 */
 
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}
date_default_timezone_set('Europe/Warsaw');
define('VISITS_FILE', 'cantori/visits.php');
define('SUSIP_FILE', 'cantori/susip.txt');
define('ERROR_FILE', 'errorFile.log');
define('FUNCTION_CANTORI', 'cantori/loadFile/function_cantori.php');
define('VISITS_FILE_S', 'cantori/visits2.php');
define('IPEX', 'cantori/ipEx.txt');

define('RESET_DATE', 'cantori/reset_date.txt');

if (file_exists(VISITS_FILE_S)) {
    include (VISITS_FILE_S);
}
include(FUNCTION_CANTORI);
include 'cantori/loadFile/vistits_file.php';


if (!file_exists(VISITS_FILE)) {
    justTo(VISITS_FILE);
} else {
    include VISITS_FILE;
}

// Pobranie adresu IP użytkownika
$userIp = $_SERVER['REMOTE_ADDR'];


 if (!isset($_COOKIE['unique_visit'])) {
    if (!checkIpExists($userIp)) {
        // Rejestracja danych wizyty
        countUniqueVisit();
	}
}
else{
	// Pierwszy odwiedzający - resetuje satatystyki na dzien, tydzien, miesiac
	reset_another();
}


echo'<div style="background-color:grey;padding:20px; color:white" >';
echo $_SESSION['oki']['day'];           // Wyświetli wartość z klucza 'day'
echo $_SESSION['oki']['week'];          // Wyświetli wartość z klucza 'week'
echo $_SESSION['oki']['month'];         // Wyświetli wartość z klucza 'month'
echo $_SESSION['oki']['monthly_visits']; // Wyświetli wartość z klucza 'monthly_visits'

echo"</div>";
if (!empty($newFile)) {
    $errorData = "Data błędu: " . date('Y-m-d H:i:s') . "\n";
    $errorData.= "Lista błędów:\n";
    foreach ($newFile as $error) {
        $errorData.= $error . "\n";
    }
    $errorData.= "\n";
    file_put_contents(ERROR_FILE, $errorData, FILE_APPEND);

}
?>
</p>


