<?php
define('HASHED_PASSWORD', '$2y$10$K4JZ4AWG.6ZnF90icIfB/eWn8.pEugB13XQaVKkkJTFeTcwBT6eVS');
define('USER_ID', 'amin');