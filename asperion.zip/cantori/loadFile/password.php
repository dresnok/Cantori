<?php
define('HASHED_PASSWORD', '$2y$10$X.HF.skYAX./1aOrz5BEQuDoImRNYErlkhac5EleLnjPLB8BVnZv6');
define('USER_ID', 'amin');