<?php
define('HASHED_PASSWORD', '$2y$10$tHMADlBtlQMJkCwvfCkUH.JEi9eM1TDAd6PBXxfv1rcUypDQA2DQe');
define('USER_ID', 'amin');