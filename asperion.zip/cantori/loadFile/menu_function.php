<?php
date_default_timezone_set('Europe/Warsaw');
if(!file_exists(VISITS_FILE)){

	justTo(VISITS_FILE);
	
	}else {
    include VISITS_FILE;
}

if (file_exists(VISITS_FILE)) {

    $_SESSION['unique_visits_day'] = NA_DZIEN;
    $_SESSION['unique_visits_week'] = NA_TYDZIEN;
    $_SESSION['unique_visits_month'] = NA_MIESIAC;
	
	
	// Utworzenie tablicy z miesięcznymi wizytami
    $_SESSION['monthly_visits'] = [
        'STYCZEN' => STYCZEN,
        'LUTY' => LUTY,
        'MARZEC' => MARZEC,
        'KWIECIEN' => KWIECIEN,
        'MAJ' => MAJ,
        'CZERWIEC' => CZERWIEC,
        'LIPIEC' => LIPIEC,
        'SIERPIEN' => SIERPIEN,
        'WRZESIEN' => WRZESIEN,
        'PAZDZIERNIK' => PAZDZIERNIK,
        'LISTOPAD' => LISTOPAD,
        'GRUDZIEN' => GRUDZIEN
    ];
} else {
    
    $newFile [] = "Plik (cantori/visits.php) nie istnieje. ";
}




function displayFilePaths($directory) {
    $iterator = new DirectoryIterator($directory);
    foreach ($iterator as $file) {
        if ($file->isFile()) {
            $filePath = $directory . '/' . $file->getFilename();
            $fileInfo = getimagesize($filePath);
            if ($fileInfo && in_array($fileInfo['mime'], IMAGE_TYPES)) {
                echo $filePath . PHP_EOL;
            }
        }
    }
}


// sendemail_file




function timeSinceFileCreation($filePath) {
    if (file_exists($filePath)) {
        $fileCreationTime = filectime($filePath);

        $fileCreationDate = new DateTime();
        $fileCreationDate->setTimestamp($fileCreationTime);

        $currentDate = new DateTime();

        $interval = $currentDate->diff($fileCreationDate);

        return [
            'days' => $interval->days,
            'hours' => $interval->h,
            'minutes' => $interval->i
        ];

    } else {
        return [
            'days' => 0,
            'hours' => 0,
            'minutes' => 0
        ];
    }
}

function timeSinceFileUpdate($filePath) {
    if (file_exists($filePath)) {
        $fileUpdateTime = filemtime($filePath);

        $fileUpdateDate = new DateTime();
        $fileUpdateDate->setTimestamp($fileUpdateTime);

        $currentDate = new DateTime();

        $interval = $currentDate->diff($fileUpdateDate);

        return [
            'days' => $interval->days,
            'hours' => $interval->h,
            'minutes' => $interval->i
        ];

    } else {
        return [
            'days' => 0,
            'hours' => 0,
            'minutes' => 0
        ];
    }
}

function getFileOrFolderTimes($path) {
    $fileTimes = [];

    // Sprawdź, czy ścieżka to plik
    if (is_file($path)) {
        $fileTimes[] = [
            'path' => $path,
            'creation' => timeSinceFileCreation($path),
            'update' => timeSinceFileUpdate($path)
        ];
    }
    // Sprawdź, czy ścieżka to folder
    elseif (is_dir($path)) {
        $fileTimes[] = [
            'path' => $path,
            'creation' => timeSinceFileCreation($path),
            'update' => timeSinceFileUpdate($path)
        ];
    } else {
        return "Podana ścieżka nie istnieje.";
    }

    return $fileTimes;
}


function ilePlikow($folder) {
    if (is_dir($folder)) {
        $files = array_diff(scandir($folder), array('.', '..')); // Pobierz pliki, zignoruj '.' i '..'
        $fileCount = 0;
        
        foreach ($files as $file) {
            if (is_file($folder . '/' . $file)) {
                $fileCount++;
            }
        }
        
        return $fileCount; // Zwraca liczbę plików w folderze
    } else {
        return 0; // Jeśli folder nie istnieje, zwraca 0
    }
}

function deleteFile($filePath) {
    if(file_exists($filePath)){
        unlink($filePath);
    }
}


// Odczytanie wszystkich zapisanych danych z pliku logu
$logData = file_exists(SUSIP_FILE) ? file(SUSIP_FILE, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES) : [];

// Tablice do zliczania poszczególnych wartości
$urlCounts = [];
$browserCounts = [];
$osCounts = [];
$userIpCounts = [];
$serverIpCounts = [];
$userIpDates = []; // Tablica do przechowywania dat dla każdego IP

// Zmienne do zliczania
$totalEntries = 0; // Całkowita liczba wpisów
$uniqueIpCount = 0; // Liczba unikalnych IP

// Przetworzenie każdego wpisu w pliku logu
foreach ($logData as $entry) {
    $parts = explode('|', $entry);
    
    // Sprawdzenie, czy liczba elementów jest odpowiednia
if (count($parts) === 10) {
        list($entryUrl, $entryBrowser, $entryOs, $entryTime, $entryUserIp, $newData, $newData1, $newData2, $newData3) = $parts;
     } else {
        // Pominięcie niekompletnego wpisu
        $_SESSION['newError'] = 'Wystąpił niekompletny wpis.' . $entry;
        continue;
    } 

    // Zliczanie URLi
    if (!isset($urlCounts[$entryUrl])) {
        $urlCounts[$entryUrl] = 0;
    }
    $urlCounts[$entryUrl]++;

    // Zliczanie przeglądarek
    if (!isset($browserCounts[$entryBrowser])) {
        $browserCounts[$entryBrowser] = 0;
    }
    $browserCounts[$entryBrowser]++;

    // Zliczanie systemów operacyjnych
    if (!isset($osCounts[$entryOs])) {
        $osCounts[$entryOs] = 0;
    }
    $osCounts[$entryOs]++;

    // Zliczanie adresów IP użytkowników
    if (!isset($userIpCounts[$entryUserIp])) {
        $userIpCounts[$entryUserIp] = 0;
        $userIpDates[$entryUserIp] = []; // Inicjalizowanie pustej tablicy dla dat
    }
    $userIpCounts[$entryUserIp]++;
    $userIpDates[$entryUserIp][] = $entryTime; // Dodawanie daty do tablicy

$totalEntries++;
	
	
}



function displayFileOrFolderTimes($path) {
    $fileTimes = getFileOrFolderTimes($path);

    if (!is_array($fileTimes)) {
        echo $fileTimes; // Wyświetla wiadomość o błędzie (np. nieistniejąca ścieżka)
        return;
    }

    foreach ($fileTimes as $fileTimesEntry) {
        echo "<strong>{$fileTimesEntry['path']}</strong><br>";
        echo "Czas utworzenia: " . ($fileTimesEntry['creation']['days'] ?? 0) . " dni, " . 
             ($fileTimesEntry['creation']['hours'] ?? 0) . " godzin i " . 
             ($fileTimesEntry['creation']['minutes'] ?? 0) . " minut.<br>";
        echo "Czas aktualizacji: " . ($fileTimesEntry['update']['days'] ?? 0) . " dni, " . 
             ($fileTimesEntry['update']['hours'] ?? 0) . " godzin i " . 
             ($fileTimesEntry['update']['minutes'] ?? 0) . " minut.<br><br>";
    }
}




