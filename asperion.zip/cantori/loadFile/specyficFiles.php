<?php

define('SPECIFIED_EXTENSIONS_TEXT', ['ttf', 'txt', 'csv', 'log', 'ini', 'json', 'xml', 'yaml', 'yml', 'md', 'rtf', 'doc', 'docx', 'css', 'html', 'php', 'htm', 'js', 'tex']);
define('SPECIFIED_EXTENSIONS_IMAGE', ['jpg', 'jpeg', 'png', 'gif', 'bmp', 'tif', 'tiff', 'ico', 'svg', 'webp', 'psd', 'raw']);
define('SPECIFIED_EXTENSIONS_AUDIO', ['mp3', 'wav', 'ogg', 'mp4', 'avi', 'mkv', 'mov', 'flv', 'wmv', 'aac', 'flac', 'alac']);
define('SPECIFIED_EXTENSIONS_SCRIPTS', ['exe', 'msi', 'sh', 'bash', 'bat', 'cmd', 'ps1', 'py', 'rb']);
define('SPECIFIED_EXTENSIONS_ARCHIVE', ['zip', 'rar', '7z', 'tar', 'gz', 'xz', 'tar.gz', 'tar.bz2', 'tar.xz']);
define('SPECIFIED_EXTENSIONS_OTHER', ['db', 'torrent', 'iso', 'env', 'log']);



