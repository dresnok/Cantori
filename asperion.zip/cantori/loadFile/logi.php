<?php

/* define('SPEED_TEST_FILE', 'cantori/speedTest.txt');

function userTimeSet($filePath) {
if (isset($_POST['timeSpent'])) {
    $timeSpent = (float)$_POST['timeSpent'];
    
    // Zapisz czas do pliku
    file_put_contents(SPEED_TEST_FILE, $timeSpent . PHP_EOL, FILE_APPEND | LOCK_EX);
    
    // Odczyt wszystkich czasów z pliku
    $fileContents = file(SPEED_TEST_FILE, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
    
    // Zlicz czasy, jeśli w pliku jest więcej niż 20 wpisów, usuń najstarsze
    if (count($fileContents) > 20) {
        $fileContents = array_slice($fileContents, -20);
        file_put_contents(SPEED_TEST_FILE, implode(PHP_EOL, $fileContents) . PHP_EOL);
    }
    
    // Oblicz średnią
    $totalTime = array_sum($fileContents);
    $averageTime = $totalTime / count($fileContents);
    
    // Przykładowe wyrażenie procentowe
    $baseline = 5; // zakładając, że 5 sekund to 100%
    $averagePercentage = ($averageTime / $baseline) * 100;

    echo "Średni czas ładowania: " . number_format($averageTime, 5) . " sekund<br>";
    echo "Średni procent wczytywania: " . number_format($averagePercentage, 2) . "%";
	
}
} */

#Funkcja pobiera dane wszystkich odsłon strony
if (!defined('LAST_IP')) {
define('LAST_IP', 'cantori/last_ip.txt');
}
function countAllUnit($filePath) {

if (file_exists(LAST_IP)) {
	
$fileContents = file_get_contents(LAST_IP);
return $fileContents;

}
}

#Funkcja zlicza wystąpienia adresów IP z pliku i zwraca ich liczbę.
if (!defined('SUSIP_FILE')) {
define('SUSIP_FILE', 'cantori/susip.txt'); // Ścieżka do pliku
}

function countUniqueIps($filePath) {
    // Sprawdzenie, czy plik istnieje
    if (!file_exists($filePath)) {
        echo "Plik nie istnieje.";
        return 0;
    }

    // Odczytaj zawartość pliku
    $fileContents = file($filePath, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);

    // Tablica do zliczania unikalnych adresów IP
    $userIpCounts = [];

    // Przetwarzanie każdego wiersza
    foreach ($fileContents as $line) {
        // Podziel wiersz na pola
        list($entryUrl, $entryBrowser, $entryOs, $entryTime, $entryUserIp, $newData, $newData1, $newData2, $newData3) = explode('|', $line);

        // Zliczaj wystąpienia każdego adresu IP
        if (isset($userIpCounts[$entryUserIp])) {
            $userIpCounts[$entryUserIp]++;
        } else {
            $userIpCounts[$entryUserIp] = 1;
        }
    }

    // Wyświetlenie liczby unikalnych adresów IP
    $uniqueIpCount = 0;
    foreach ($userIpCounts as $userIp => $count) {
        $uniqueIpCount++;
        //echo "Adres IP: $userIp, liczba wystąpień: $count\n";
    }

    //echo "$uniqueIpCount\n";
    return $uniqueIpCount;
}


/**
 * Funkcja `countUniqueIps` zlicza unikalne adresy IP z pliku.
 * Każda linia zawiera informacje o odwiedzinach użytkownika, w tym adres IP.
 *
 * - Funkcja najpierw sprawdza, czy plik istnieje.
 * - Jeśli plik istnieje, jego zawartość zostaje odczytana do tablicy, gdzie każda linia odpowiada jednemu wpisowi.
 * - Dla każdej linii, funkcja dzieli dane na poszczególne pola (np. URL, przeglądarka, system operacyjny, czas, adres IP, itp.).
 * - Na koniec, funkcja wyświetla i zwraca liczbę unikalnych adresów IP.
 */

function logVisitorData($filePath) {
    $time = date("Y-m-d H:i:s");
    $url = filter_var($_SERVER['REQUEST_URI'], FILTER_SANITIZE_STRING);
    $userIp = filter_var($_SERVER['REMOTE_ADDR'], FILTER_VALIDATE_IP);

    $browsers = [
        'Chrome' => 'Google Chrome',
        'Firefox' => 'Mozilla Firefox',
        'Safari' => 'Safari',
        'MSIE' => 'Internet Explorer',
        'Trident' => 'Internet Explorer',
        'Edge' => 'Microsoft Edge'
    ];

    $osList = [
        'Windows NT 10.0' => 'Windows 10',
        'Windows NT 6.3' => 'Windows 8.1',
        'Windows NT 6.2' => 'Windows 8',
        'Windows NT 6.1' => 'Windows 7',
        'Macintosh' => 'Mac OS',
        'Linux' => 'Linux',
        'Android' => 'Android',
        'iPhone' => 'iOS',
        'iPad' => 'iOS'
    ];

    $userAgent = filter_var($_SERVER['HTTP_USER_AGENT'], FILTER_SANITIZE_STRING);

    $browser = 'Inna przeglądarka';
    foreach ($browsers as $key => $value) {
        if (strpos($userAgent, $key) !== false) {
            $browser = $value;
            break;
        }
    }

    $os = 'Inny system operacyjny';
    foreach ($osList as $key => $value) {
        if (strpos($userAgent, $key) !== false) {
            $os = $value;
            break;
        }
    }

    function fetchAndDisplayIPData($ip_address) {
        if (!filter_var($ip_address, FILTER_VALIDATE_IP)) {
            $_SESSION['newFile'] = "Nieprawidłowy adres IP: $ip_address";
            return '';
        }

        $api_url = "http://ip-api.com/json/{$ip_address}";
        $response = @file_get_contents($api_url);

        if ($response !== FALSE) {
            $data = json_decode($response, true);

            if (isset($data['status']) && $data['status'] == 'success') {
                $newData = "ip-api.com: Kraj: " . htmlspecialchars($data['country']) . "|" . "Region: " . htmlspecialchars($data['regionName']) . "|" . "Miasto: " . htmlspecialchars($data['city']) . "|" . "ISP: " . htmlspecialchars($data['isp']) . "|";
                return $newData;
            } else {
                $_SESSION['newFile'] = "Błąd w pobieraniu danych z API dla IP: $ip_address";
            }
        } else {
            $_SESSION['newFile'] = "Nie udało się połączyć z API dla IP: $ip_address";
        }

        return '';
    }

    $newData = fetchAndDisplayIPData($userIp);
    $logEntry = $url . "|" . $browser . "|" . $os . "|" . $time . "|" . $userIp . "|" . $newData . PHP_EOL;
    file_put_contents($filePath, $logEntry, FILE_APPEND | LOCK_EX);
}
?>