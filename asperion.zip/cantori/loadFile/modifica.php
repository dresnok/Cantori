<?php


if (!defined('LAST_IP')) {
define('LAST_IP', 'cantori/last_ip.txt');
}
if (!defined('MENU_FUNCTION')) {
define('MENU_FUNCTION', 'cantori/loadFile/menu_function.php');
}
if (!defined('VISTITS_FILE')) {
define('VISTITS_FILE', 'cantori/loadFile/vistits_file.php');
}
if (!defined('ERROR_FILE')) {
define('ERROR_FILE', 'errorFile.log');
}
if (!defined('SUSIP_FILE')) {
define('SUSIP_FILE', 'cantori/susip.txt');
}
if (!defined('VISITS_FILE')) {
define('VISITS_FILE', 'cantori/visits.php');
}

if (!defined('VISITS_FILE_S')) {
define('VISITS_FILE_S', 'cantori/visits2.php');
}
if (!defined('SFONDO')) {
define('SFONDO', 'cantori/dodatki/sfondo.php');
}
if (!defined('INFO_FILE')) {
define('INFO_FILE', 'info.php');
}
if (!defined('IPEX')) {
    define('IPEX', 'cantori/ipEx.txt');
}

#last_word
if (!defined('FUNCTIONE')) {
define('FUNCTIONE', 'cantori/loadFile/index_function.php');
}
if (!defined('PASSWORD_T')) {
define('PASSWORD_T', 'cantori/loadFile/password.php');
}
if (!defined('SENDEMAIL')) {
define('SENDEMAIL', 'cantori/loadFile/SendEmail.php');
}
if (!defined('MODIFICA')) {
define('MODIFICA', 'cantori/loadFile/modifica.php');
}


if (!defined('LOGIN')) {
define('LOGIN', 'cantori/loadFile/login.php');
}

#sfondo

if (!defined('TARGETDIRECTORY')) {
    define('TARGETDIRECTORY', 'cantori/dorme/');
}

if (!defined('BACKUPDIRECTORY')) {
    define('BACKUPDIRECTORY', 'cantori/backup/');
}

if (!defined('DOWNLOADFILE')) {
    define('DOWNLOADFILE', 'cantori/downloadFile/');
}

if (!defined('LAST_YEAR')) {
    define('LAST_YEAR', 'cantori/lastYear/');
}

if (!defined('LOADTIMES')) {
    define('LOADTIMES', 'cantori/loadFile/loadTimes.php');
}


if (!defined('TEMPLATEONE')) {
    define('TEMPLATEONE', 'cantori/dodatki/templateone.webp');
}

if (!defined('TEMPLATETWO')) {
    define('TEMPLATETWO', 'cantori/dodatki/templatetwo.webp');
}

if (!defined('IMAGE_TYPES')) {
define('IMAGE_TYPES', ['image/jpeg', 'image/png', 'image/gif', 'image/bmp', 'image/webp']);
}


