<?php
session_start();
date_default_timezone_set('Europe/Warsaw');

include 'password.php';
define('INFO_FILE', '../../info.php?net=loadButton2#td');
define('PASSWORD_T', 'password.php');

define('VISITS_FILE', '../visits.php');
define('SUSIP_FILE', '../susip.txt');
define('ERROR_FILE', '../../errorFile.log');
define('IPEX', '../ipEx.txt');

define('BACKUPDIRECTORY', '../backup');
define('DOWNLOADFILE', '../downloadFile/');
define('LAST_YEAR', '../lastYear');


function safe_redirect($url) {
    header("Location: " . $url);
    exit();
}


$nowe = filter_input(INPUT_POST, 'nowe', FILTER_SANITIZE_SPECIAL_CHARS);
if ($nowe !== null) {
    $haslo = @filter_input(INPUT_POST, 'haslo', FILTER_SANITIZE_STRING); // Opcjonalnie można to dodać, ale nie jest to konieczne przy password_hash
    
	
    // Walidacja hasła
    if (!empty($haslo)) {
		$_SESSION['hash_hasla'] = password_hash($haslo, PASSWORD_DEFAULT);
		$_SESSION['newInfo'] = "Hasło wygenerowane pomyślnie (generator hasła).";
		}
		safe_redirect(INFO_FILE);
		
		}

if(isset($_POST['new_password'])) {

    $new_password = trim($_POST['new_password']);
    $confirm_password = trim($_POST['confirm_password']);
    $password2 = trim($_POST['password2']);
	
if (password_verify($password2, HASHED_PASSWORD)) {

        // Sprawdź, czy nowe hasło i potwierdzenie są takie same
        if ($new_password === $confirm_password) {
            // Zhashuj nowe hasło
            $new_hashed_password = password_hash($new_password, PASSWORD_DEFAULT);

            // Zaktualizuj plik z hasłem, tylko zmieniając linię z hasłem
            $password_file_content = file(PASSWORD_T);
            foreach ($password_file_content as &$line) {
                if (strpos($line, "define('HASHED_PASSWORD'") !== false) {
                    $line = "define('HASHED_PASSWORD', '" . $new_hashed_password . "');\n";
                    break;
                }
            }
            file_put_contents(PASSWORD_T, implode('', $password_file_content));


			$_SESSION['newInfo'] = "Hasło zostało zmienione.";
		
				
            
        } else {
			 $_SESSION['newInfo'] = 'Błąd: nowe hasło i potwierdzenie nie są takie same.';

} 
}
else{
			 $_SESSION['newInfo'] = 'Wprowadziłeś błędne hasło dostępu.';
}
safe_redirect(INFO_FILE);

}




if (isset($_POST['downloadFile'])) {


    $directory = DOWNLOADFILE;
    if (!is_dir($directory)) {
        mkdir($directory, 0777, true);
    }

    // Generowanie unikatowej nazwy pliku
	    $unique_filename = 'raport_' . date('Ymd_His') . '.html';
    $file_path = "$directory$unique_filename";
	

    // Pliki do odczytu
    $plik1 = VISITS_FILE;
    $plik2 = SUSIP_FILE;
    $plik3 = ERROR_FILE;
    $plik5 = IPEX;

    // Foldery do sprawdzenia
    $folders = [
        BACKUPDIRECTORY,
        DOWNLOADFILE,
        LAST_YEAR
    ];

$content1 = @file_get_contents($plik1);

if ($content1 !== false) {
    // Najpierw konwersja specjalnych znaków na bezpieczne dla HTML
    $content1 = htmlspecialchars($content1);
    
    
} else {
    error_log("Nie udało się odczytać pliku: $plik1");
}


    $content2 = @file_get_contents($plik2) ?: error_log("Nie udało się odczytać pliku: $plik2") && "<p>Nie udało się odczytać pliku: $plik2</p>";
    $content3 = @file_get_contents($plik3) ?: error_log("Nie udało się odczytać pliku: $plik3") && "<p>Nie udało się odczytać pliku: $plik3</p>";
/*     $content4 = @file_get_contents($plik4) ?: error_log("Nie udało się odczytać pliku: $plik4") && "<p>Nie udało się odczytać pliku: $plik4</p>"; */

    $content5 = '';
    if (file_exists($plik5)) {
        $content5 = @file_get_contents($plik5) ?: error_log("Nie udało się odczytać pliku: $plik5") && "<p>Nie udało się odczytać pliku: $plik5</p>";
    }

    // Odczyt zawartości folderów
    $folder_contents = '';
    foreach ($folders as $folder) {
        if (is_dir($folder)) {
            $files = array_diff(scandir($folder), array('.', '..'));
            if (empty($files)) {
                $folder_contents .= "<p>Folder $folder jest pusty.</p>";
            } else {
                $folder_contents .= "<h2>Zawartość folderu: $folder</h2><ul>";
                foreach ($files as $file) {
                    $folder_contents .= "<li>$file</li>";
                }
                $folder_contents .= "</ul>";
            }
        } else {
            error_log("Folder $folder nie istnieje");
        }
    }

    // Tworzenie struktury HTML z minimalistycznym CSS
    $html_template = "
    <!DOCTYPE html>
    <html lang='pl'>
    <head>
        <meta charset='UTF-8'>
        <meta name='viewport' content='width=device-width, initial-scale=1.0'>
        <title>Raport Statystyk</title>
        <style>
            body {
                font-family: Arial, sans-serif;
               background-color: #e0f5e0;

                color: #2d5c2d;

                margin: 0;
                padding: 20px;
            }
            .container {
                max-width: 800px;
                margin: 0 auto;
                padding: 20px;
                border: 1px solid #ddd;
                background-color: #cfe9cf;

            }
            h1, h2 {
                color: #000;
                margin-bottom: 10px;
            }
            pre {
                background-color: #f0f0f0;
                padding: 10px;
                border: 1px solid #ccc;
                overflow-x: auto;
                white-space: pre-wrap;
				
            }
            p {
                color: #333;
            }
            ul {
                list-style-type: none;
                padding-left: 0;
            }
            li {
			
                padding: 5px 0;
                border-bottom: 1px solid #ddd;
            }
			
			.ov {
			background-color: #b0d8b0;
				max-height: 800px;
overflow-y: auto;display: block;
			}
        </style>
    </head>
    <body>
        <div class='container'>
            <h1>Raport Statystyk</h1>
            <h2>Visits.php</h2>
            <pre><code>$content1</code></pre>
            <h2>Susip.php</h2>
            <pre class=ov>$content2</pre>
            <h2>ErrorFile.log</h2>
            <pre class=ov>$content3</pre>
            <h2>IpEx.txt</h2>
            <pre>$content5</pre>
            $folder_contents
        </div>
    </body>
    </html>";

    // Zapisanie zawartości do nowo utworzonego pliku HTML
    $file = fopen($file_path, "w");
    if ($file) {
        fwrite($file, $html_template);
        fclose($file);

        // Pobieranie nowo stworzonego pliku
        header('Content-Type: application/octet-stream');
        header('Content-Disposition: attachment; filename="' . basename($file_path) . '"');
        header('Content-Length: ' . filesize($file_path));
        readfile($file_path);
        
		$_SESSION['newInfo'] = "Udało się pobrać plik. (cantori/downloadFile)";
    } else {
		$_SESSION['newInfo'] = "Błąd: nie udało się pobrać pliku.";
        error_log("Nie udało się zapisać pliku: $file_path");
    }
	
			 
				//safe_redirect(INFO_FILE);
}


if ( isset($_POST['wykluczenia'])){


   // Funkcja do walidacji adresu IP
    function isValidIP($ip) {
        return filter_var($ip, FILTER_VALIDATE_IP) !== false;
    }

    // Ścieżka do pliku
    $filePath = IPEX;

    // Sprawdzenie czy plik istnieje, jeśli nie to tworzenie pliku
    if (!file_exists($filePath)) {
        $fileDir = dirname($filePath);
        if (!is_dir($fileDir)) {
            mkdir($fileDir, 0777, true);
        }
        touch($filePath);
    }

    // Odczyt zawartości pliku do tablicy
    $existingIPs = file($filePath, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);

    // Funkcja do sprawdzenia, czy adres IP już istnieje w pliku
    function ipExists($ip, $existingIPs) {
        return in_array($ip, $existingIPs);
    }

if (isset($_POST['action']) && $_POST['action'] === 'dodaj_local') {
    // Przetwarzanie checkboxów
    if (isset($_POST['address'])) {
        foreach ($_POST['address'] as $address) {
            if ($address === '127.0.0.1' && !ipExists('127.0.0.1', $existingIPs)) {
                file_put_contents($filePath, "127.0.0.1\n", FILE_APPEND);
							$_SESSION['newInfo'] = "Dodano wykluczenie: $address (Wykluczenia IP).";
        
            } elseif ($address === 'moj_adres_ip') {
                $myIPAddress = $_SERVER['REMOTE_ADDR']; // Przykładowe aktualne IP
                if (!ipExists($myIPAddress, $existingIPs)) {
                    file_put_contents($filePath, "$myIPAddress\n", FILE_APPEND);
					$_SESSION['newInfo'] = "Dodano wykluczenie: $myIPAddress (Wykluczenia IP).";
        
                }
            }
        }
		
    }
}

// Dodawanie wykluczenia
if (isset($_POST['action']) && $_POST['action'] === 'dodaj_wykluczenie') {
    if (!empty($_POST['dodaj_wykluczenie'])) {
        $dodaj_wykluczenie = $_POST['dodaj_wykluczenie'];
        
        // Sprawdzenie, czy IP jest poprawne oraz czy nie istnieje już w pliku
        if (isValidIP($dodaj_wykluczenie) && !ipExists($dodaj_wykluczenie, $existingIPs)) {
            // Dodanie IP do pliku wykluczeń
            if (file_put_contents($filePath, "$dodaj_wykluczenie\n", FILE_APPEND | LOCK_EX)) {
                $_SESSION['newInfo'] = "Dodano wykluczenie: $dodaj_wykluczenie (Wykluczenia IP).";
            } else {
                // Obsługa błędów związanych z zapisem do pliku
                $_SESSION['newError'] = "Błąd zapisu do pliku przy dodawaniu wykluczenia: $dodaj_wykluczenie.";
                
            }
        } elseif (!isValidIP($dodaj_wykluczenie)) {
            // Obsługa błędów związanych z nieprawidłowym adresem IP
            $_SESSION['newError'] = "Nieprawidłowy adres IP do dodania: $dodaj_wykluczenie (Wykluczenia IP).";
        
        } else {
            // Obsługa sytuacji, gdy adres IP już istnieje
            $_SESSION['newInfo'] = "Nieprawidłowy adres IP: $dodaj_wykluczenie";
        }
    } 
}


if (isset($_POST['action']) && $_POST['action'] === 'usun_wykluczenie') {
    // Usuwanie wykluczenia
    if (!empty($_POST['usun_wykluczenie'])) {
        $usun_wykluczenie = $_POST['usun_wykluczenie'];
        if (isValidIP($usun_wykluczenie)) {
            $fileContents = file_get_contents($filePath);
            $fileContents = str_replace("$usun_wykluczenie\n", '', $fileContents);
            file_put_contents($filePath, $fileContents);
			$_SESSION['newInfo'] = "Usunięto wykluczenie: $usun_wykluczenie (Wykluczenia IP).";
       
		
            
        } else {
		$_SESSION['newInfo'] = "Nieprawidłowy adres IP do usunięcia. (Wykluczenia IP).";
       

        }
    }
}

    // Usuwanie wszystkich wykluczeń
    if (isset($_POST['action']) && $_POST['action'] === 'usun_wszystkie_wykluczenia') {
        file_put_contents($filePath, '');
		$_SESSION['newInfo'] = "Usunięto wszystkie wykluczenia. (Wykluczenia IP).";
        
       
    }
	
		safe_redirect(INFO_FILE);
}






?>