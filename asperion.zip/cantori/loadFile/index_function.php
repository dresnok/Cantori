<?php
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}


date_default_timezone_set('Europe/Warsaw');

// Pobierz aktualny czas
$now = new DateTime();

// Ustaw formatowanie na polski
$formatter_time = new IntlDateFormatter(
    'pl_PL', 
    IntlDateFormatter::SHORT, 
    IntlDateFormatter::NONE, 
    'Europe/Warsaw'
);
$formatter_date = new IntlDateFormatter(
    'pl_PL', 
    IntlDateFormatter::FULL, 
    IntlDateFormatter::NONE, 
    'Europe/Warsaw'
);

// Sformatuj czas i datę
$time = $now->format('H:i:s');
$date = $formatter_date->format($now);


if(file_exists(VISITS_FILE_S)){
$LOAD_TIMES = LOAD_TIMES;
if (isset($LOAD_TIMES)) {

function calculateAverageLoadTime($times) {
    if (empty($times)) {
        return 0; // Dla uproszczenia zakładam, że średni czas to 0, gdy brak danych
    }
    return array_sum($times) / count($times);
}


    if (function_exists('calculateAverageLoadTime')) {
        // Obliczenie średniego czasu ładowania
        $averageLoadTime = calculateAverageLoadTime($LOAD_TIMES);
        // Pobranie 5 ostatnich wpisów, jeśli istnieją
        $lastEntries = array_slice($LOAD_TIMES, -5);
    } else {
        $averageLoadTime = 0;
        $_SESSION['newError'] = "Wczytywanie wyników: błąd funkcji 'calculateAverageLoadTime'.";
    }
} 

}else {
    $averageLoadTime = 0;
    $lastEntries = []; // Ustawienie pustej tablicy dla ostatnich wpisów
}


if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['seeMore'])) {
	
        // Sprawdzenie tokenu CSRF
        if (!isset($_SESSION['csrf_token']) || $_POST['csrf_token'] !== $_SESSION['csrf_token']) {
            $_SESSION['newError'] = "Nieudana próba CSRF 'loadTimes.php'";
            header("Location: ./info.php");
            exit();
        }

        // Pobranie ścieżki z formularza, walidacja i ustawienie domyślnej wartości
        $folderPath = isset($_POST['folderPath']) && !empty(trim($_POST['folderPath'])) ? trim($_POST['folderPath']) : './';

        // Zapis ścieżki do sesji
        $_SESSION['folderPath'] = $folderPath;

        // Sprawdzenie, czy ścieżka istnieje i jest katalogiem
        if (!is_dir($folderPath)) {
            $_SESSION['newError'] = "Podana ścieżka nie jest katalogiem lub nie istnieje.";
            header("Location: ./info.php");
            exit();
        }

        function sumSpecifiedFilesWeightInMegabytes($dir, $extensions) {
            $totalWeight = 0;
            $files = new RecursiveIteratorIterator(new RecursiveDirectoryIterator($dir));
            foreach ($files as $file) {
                if ($file->isFile()) {
                    $extension = $file->getExtension();
                    if (in_array($extension, $extensions)) {
                        $totalWeight += $file->getSize();
                    }
                }
            }
            // Konwersja z bajtów na megabajty
            return $totalWeight / (1024 * 1024);
        }

        include "cantori/loadFile/specyficFiles.php";

        try {
            if (function_exists('sumSpecifiedFilesWeightInMegabytes')) {
                // Obliczenie wagi plików dla każdej kategorii
                $totalFolderWeightMegabytesText = sumSpecifiedFilesWeightInMegabytes($folderPath, SPECIFIED_EXTENSIONS_TEXT);
                $totalFolderWeightMegabytesImage = sumSpecifiedFilesWeightInMegabytes($folderPath, SPECIFIED_EXTENSIONS_IMAGE);
                $totalFolderWeightMegabytesAudio = sumSpecifiedFilesWeightInMegabytes($folderPath, SPECIFIED_EXTENSIONS_AUDIO);
                $totalFolderWeightMegabytesScripts = sumSpecifiedFilesWeightInMegabytes($folderPath, SPECIFIED_EXTENSIONS_SCRIPTS);
                $totalFolderWeightMegabytesArchiwe = sumSpecifiedFilesWeightInMegabytes($folderPath, SPECIFIED_EXTENSIONS_ARCHIVE);
                $totalFolderWeightMegabytesOther = sumSpecifiedFilesWeightInMegabytes($folderPath, SPECIFIED_EXTENSIONS_OTHER);

                // Formatowanie wyników do dwóch miejsc po przecinku
                $waga_pText = number_format($totalFolderWeightMegabytesText, 2);
                $waga_pImage = number_format($totalFolderWeightMegabytesImage, 2);
                $waga_pAudio = number_format($totalFolderWeightMegabytesAudio, 2);
                $waga_pScripts = number_format($totalFolderWeightMegabytesScripts, 2);
                $waga_pArchiwe = number_format($totalFolderWeightMegabytesArchiwe, 2);
                $waga_pOther = number_format($totalFolderWeightMegabytesOther, 2);

                $_SESSION['newInfo'] = "$folderPath Dane wczytane poprawnie (Rozmiar projektu).";
            } else {
                throw new Exception("Funkcja sumSpecifiedFilesWeightInMegabytes nie istnieje.");
            }
        } catch (Exception $e) {
            $_SESSION['newError'] = 'Wystąpił błąd: ' . $e->getMessage();
        }

        try {
            // Zapisywanie wartości do sesji
            $_SESSION['waga_pText'] = $waga_pText;
            $_SESSION['waga_pImage'] = $waga_pImage;
            $_SESSION['waga_pAudio'] = $waga_pAudio;
            $_SESSION['waga_pScripts'] = $waga_pScripts;
            $_SESSION['waga_pArchiwe'] = $waga_pArchiwe;
            $_SESSION['waga_pOther'] = $waga_pOther;
        } catch (Exception $e) {
            $_SESSION['newError'] = 'Wystąpił błąd podczas przetwarzania danych sesji: ' . $e->getMessage();
        }
    }
}


function displayFilePaths($directory) {
    $iterator = new DirectoryIterator($directory);
    foreach ($iterator as $file) {
        if ($file->isFile()) {
            $filePath = $directory . '/' . $file->getFilename();
            $fileInfo = getimagesize($filePath);
            if ($fileInfo && in_array($fileInfo['mime'], IMAGE_TYPES)) {
                echo $filePath . PHP_EOL;
            }
        }
    }
}


?>



