<?php
session_start();
include 'password.php';

if (!defined('ERROR_FILE')) {
    define('ERROR_FILE', './../../errorFile.log');
}

define('INFO_FILE', './../../info.php');
define('LOGIN', 'login.php?logout=success');

if (isset($_GET['logout']) && $_GET['logout'] == 'success') {
    echo "Logout successful!";
}

if (($_SERVER['REQUEST_METHOD'] == 'POST') && !isset($_POST['logout'])) {
    $password = trim($_POST['password']);

    if (password_verify($password, HASHED_PASSWORD)) {
        // Regeneracja ID sesji po udanym logowaniu
        session_regenerate_id(true);

        // Ustawienie sesji użytkownika
        $_SESSION['user_id'] = USER_ID;

		// Przekierowanie po zalogowaniu
        header('Location: ' . INFO_FILE);
        exit;
    } else {
        echo "Invalid password!";
        $errors[] = "Logowanie: Invalid password!";
    }
} elseif (isset($_POST['logout'])) {
    session_destroy();
    header('Location: ' . LOGIN);
    exit;
}

if (!empty($errors)) {
    $errorData = "Data błędu: " . date('Y-m-d H:i:s') . "\n";
    $errorData .= "Lista błędów:\n";
    foreach ($errors as $error) {
        $errorData .= $error . "\n";
    }
    $errorData .= "\n";
    file_put_contents(ERROR_FILE, $errorData, FILE_APPEND);
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Login</title>
</head>
<body>
  <script>
        document.addEventListener("DOMContentLoaded", function() {
            // Ustaw fokus na polu 'password' po załadowaniu DOM
            document.getElementById('password').focus();
        });
    </script>

    <form method="post" action="login.php">
        <label for="password">Password:</label>
        <input type="password" id="password" name="password" autofocus required>
        <input type="submit" value="Login">
    </form>
</body>
</html>