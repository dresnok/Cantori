<?php
session_start();
include 'password.php';

// Token CSRF
define('CSRF_TOKEN', 'csrf_token');
define('ERROR_FILE', './../../errorFile.log');
define('INFO_FILE', './../../info.php');
define('LOGIN', 'login.php?logout=success');

// Generowanie tokena CSRF
function generateCsrfToken() {
    return bin2hex(random_bytes(32));
}

// Sprawdzanie tokena CSRF
function checkCsrfToken($token) {
    return hash_equals($_SESSION[CSRF_TOKEN], $token);
}

// Inicjalizacja tokena CSRF w sesji, jeśli nie jest już ustawiony
if (empty($_SESSION[CSRF_TOKEN])) {
    $_SESSION[CSRF_TOKEN] = generateCsrfToken();
}

// Sprawdzenie, czy użytkownik jest już zalogowany
if (isset($_SESSION['user_id'])) {
    header('Location: ' . INFO_FILE);
    exit;
}

// Obsługa logowania i wylogowywania
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if (isset($_POST['logout'])) {
        session_unset();
        session_destroy();
        setcookie(session_name(), '', time() - 3600, '/'); // Usunięcie ciasteczka sesji
        header('Location: ' . LOGIN);
        exit;
    }

    // Sprawdzenie tokena CSRF
    if (!checkCsrfToken($_POST['csrf_token'])) {
        echo "Invalid CSRF token!";
        exit;
    }

    $password = trim($_POST['password']);
    
    if (password_verify($password, HASHED_PASSWORD)) {
        session_regenerate_id(true);
        $_SESSION['user_id'] = USER_ID;
        header('Location: ' . INFO_FILE);
        exit;
    } else {
        echo "Invalid password!";
        $errors[] = "Logowanie: Invalid password!";
    }
}

// Logowanie błędów
if (!empty($errors)) {
    $errorData = "Data błędu: " . date('Y-m-d H:i:s') . "\n";
    $errorData .= "Lista błędów:\n";
    foreach ($errors as $error) {
        $errorData .= $error . "\n";
    }
    $errorData .= "\n";
    file_put_contents(ERROR_FILE, $errorData, FILE_APPEND);
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Login</title>
</head>
<body>
  <script>
        document.addEventListener("DOMContentLoaded", function() {
            document.getElementById('password').focus();
        });
    </script>

    <form method="post" action="login.php">
        <input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars($_SESSION[CSRF_TOKEN]); ?>">
        <label for="password">Password:</label>
        <input type="password" id="password" name="password" autofocus required>
        <input type="submit" value="Login">
    </form>
</body>
</html>
