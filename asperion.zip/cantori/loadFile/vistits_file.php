<?php
function saveVisitCounts($dailyVisits, $weeklyVisits, $monthlyVisits, $monthlyData) {
    $data = "<?php\n";
    $data .= "define('NA_DZIEN', $dailyVisits);\n";
    $data .= "define('NA_TYDZIEN', $weeklyVisits);\n";
    $data .= "define('NA_MIESIAC', $monthlyVisits);\n";
    
    
    
    foreach ($monthlyData as $month => $count) {
        $data .= "define('$month', $count);\n";
    }
    
touch(VISITS_FILE);

    file_put_contents(VISITS_FILE, $data);
	
}

function justTo($file) {
 
        // Definiowanie stałych, gdy plik nie istnieje
        define('NA_DZIEN', 0);
        define('NA_TYDZIEN', 0);
        define('NA_MIESIAC', 0);
        define('STYCZEN', 0);
        define('LUTY', 0);
        define('MARZEC', 0);
        define('KWIECIEN', 0);
        define('MAJ', 0);
        define('CZERWIEC', 0);
        define('LIPIEC', 0);
        define('SIERPIEN', 0);
        define('WRZESIEN', 0);
        define('PAZDZIERNIK', 0);
        define('LISTOPAD', 0);
        define('GRUDZIEN', 0);
if (file_exists($file)) {
        unlink($file);
    }
        // Wywołanie funkcji zapisywania
        saveVisitCounts(0, 0, 0, [
            'STYCZEN' => 0,
            'LUTY' => 0,
            'MARZEC' => 0,
            'KWIECIEN' => 0,
            'MAJ' => 0,
            'CZERWIEC' => 0,
            'LIPIEC' => 0,
            'SIERPIEN' => 0,
            'WRZESIEN' => 0,
            'PAZDZIERNIK' => 0,
            'LISTOPAD' => 0,
            'GRUDZIEN' => 0        
			]);

}



?>