<?php
function saveVisitCounts($dailyVisits, $weeklyVisits, $monthlyVisits, $monthlyData) {
    $data = "<?php\n";
    $data .= "define('NA_DZIEN', $dailyVisits);\n";
    $data .= "define('NA_TYDZIEN', $weeklyVisits);\n";
    $data .= "define('NA_MIESIAC', $monthlyVisits);\n";

    foreach ($monthlyData as $month => $count) {
        $data .= "define('$month', $count);\n";
    }

   if (file_put_contents(VISITS_FILE, $data, LOCK_EX) === false) {

        $_SESSION['newFile'] = "Błąd zapisu do pliku: " . VISITS_FILE;
    }
}

function justTo($file) {
    define('NA_DZIEN', 0);
    define('NA_TYDZIEN', 0);
    define('NA_MIESIAC', 0);
    define('STYCZEN', 0);
    define('LUTY', 0);
    define('MARZEC', 0);
    define('KWIECIEN', 0);
    define('MAJ', 0);
    define('CZERWIEC', 0);
    define('LIPIEC', 0);
    define('SIERPIEN', 0);
    define('WRZESIEN', 0);
    define('PAZDZIERNIK', 0);
    define('LISTOPAD', 0);
    define('GRUDZIEN', 0);

    if (file_exists($file)) {
        if (!unlink($file)) {
            $_SESSION['newFile'] = "Nie udało się usunąć pliku: " . $file;
        }
    }

    saveVisitCounts(0, 0, 0, [
        'STYCZEN' => 0,
        'LUTY' => 0,
        'MARZEC' => 0,
        'KWIECIEN' => 0,
        'MAJ' => 0,
        'CZERWIEC' => 0,
        'LIPIEC' => 0,
        'SIERPIEN' => 0,
        'WRZESIEN' => 0,
        'PAZDZIERNIK' => 0,
        'LISTOPAD' => 0,
        'GRUDZIEN' => 0
    ]);
}
?>
