<?php
session_start();
date_default_timezone_set('Europe/Warsaw');

define('VISITS_FILE', '../visits.php');
include_once 'vistits_file.php';

$dir_info = "../../info.php";

if (!isset($_SESSION['csrf_token1']) || $_POST['csrf_token1'] !== $_SESSION['csrf_token1']) {
        $_SESSION['newError'] = "Nieudana próba CSRF 'SeeMoreFile'";
        header("Location: $dir_info#st_od");
		exit();
    }
	

$seeMoreFile = filter_var($_POST['SeeMoreFile'], FILTER_SANITIZE_NUMBER_INT);
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($seeMoreFile)) {
		
		

  $months = ['STYCZEN', 'LUTY', 'MARZEC', 'KWIECIEN', 'MAJ', 'CZERWIEC', 'LIPIEC', 'SIERPIEN', 'WRZESIEN', 'PAZDZIERNIK', 'LISTOPAD', 'GRUDZIEN'];

    // Mapowanie miesięcy z angielskiego na polski
    $monthMap = ['JANUARY' => 'STYCZEN', 'FEBRUARY' => 'LUTY', 'MARCH' => 'MARZEC', 'APRIL' => 'KWIECIEN', 'MAY' => 'MAJ', 'JUNE' => 'CZERWIEC', 'JULY' => 'LIPIEC', 'AUGUST' => 'SIERPIEN', 'SEPTEMBER' => 'WRZESIEN', 'OCTOBER' => 'PAZDZIERNIK', 'NOVEMBER' => 'LISTOPAD', 'DECEMBER' => 'GRUDZIEN'];

    // Aktualny miesiąc
    $currentMonth = $monthMap[strtoupper(date('F'))];

    $totalVisits = 0;

    // Obsługa indywidualnych zapisów dla każdego miesiąca
    foreach ($months as $month) {
        if (isset($_POST['submit_' . $month])) {
            $newVisits = (int)$_POST['visits_' . $month];
            $visitDifference = $newVisits - ($_SESSION['monthly_visits'][$month] ?? 0);
            $_SESSION['monthly_visits'][$month] = max($newVisits, 0);

            if ($month === $currentMonth) {
                $_SESSION['unique_visits_day'] = max($_SESSION['unique_visits_day'] + $visitDifference, 0);
                $_SESSION['unique_visits_week'] = max($_SESSION['unique_visits_week'] + $visitDifference, 0);
                $_SESSION['unique_visits_month'] = $_SESSION['monthly_visits'][$month];
            }

            saveVisitCounts($_SESSION['unique_visits_day'], $_SESSION['unique_visits_week'], $_SESSION['unique_visits_month'], $_SESSION['monthly_visits']);
            $_SESSION['newInfo'] = "Zapisano pomyślnie dane dla miesiąca: $month.";
            header("Location: $dir_info#st_od");
            exit;
        }
    }
	
	 // Zapisanie wszystkich miesięcy
                foreach ($months as $month) {
                    if (isset($_POST['visits_' . $month])) {
                        $newVisits = (int)$_POST['visits_' . $month];
                        $_SESSION['monthly_visits'][$month] = max($newVisits, 0);
                        $totalVisits += $newVisits;
                    }
                }
                
                saveVisitCounts($_SESSION['unique_visits_day'], $_SESSION['unique_visits_week'], $_SESSION['unique_visits_month'], $_SESSION['monthly_visits']);
                
				
		
				
				$_SESSION['newInfo'] = "Dane zapisane pomyślnie";
                header("Location: $dir_info#st_od");
				exit;


       
    }
	else {
        // Obsłuż błąd braku wartości $seeMoreFile
        $_SESSION['newError'] = "Brak lub niepoprawna wartość SeeMoreFile";
        header("Location: $dir_info#st_od");
        exit();
    }

}