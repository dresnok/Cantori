function updateDateTime() {
    const now = new Date();
    
    const daysOfWeek = ['niedziela', 'poniedziałek', 'wtorek', 'środa', 'czwartek', 'piątek', 'sobota'];
    const months = ['stycznia', 'lutego', 'marca', 'kwietnia', 'maja', 'czerwca', 'lipca', 'sierpnia', 'września', 'października', 'listopada', 'grudnia'];

    const dayOfWeek = daysOfWeek[now.getDay()];
    const day = now.getDate();
    const month = months[now.getMonth()];
    const year = now.getFullYear();

    const hours = String(now.getHours()).padStart(2, '0');
    const minutes = String(now.getMinutes()).padStart(2, '0');
    const seconds = String(now.getSeconds()).padStart(2, '0');

    const formattedDate = `${dayOfWeek}, ${day} ${month} ${year}`;
    const formattedTime = `${hours}:${minutes}:${seconds}`;

    document.getElementById('date').innerHTML = `${formattedDate}`;
document.getElementById('time').innerHTML = `${formattedTime}`;
}

setInterval(updateDateTime, 1000);
updateDateTime();
