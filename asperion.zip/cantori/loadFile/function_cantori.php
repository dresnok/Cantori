<?php

function getUserIp() {
    // Sprawdź, czy klient używa proxy
    if (!empty($_SERVER['HTTP_CLIENT_IP'])) {
        $ip = $_SERVER['HTTP_CLIENT_IP'];
    } elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
        // Może zawierać listę IP oddzielonych przecinkami, weź pierwsze
        $ip = explode(',', $_SERVER['HTTP_X_FORWARDED_FOR'])[0];
    } else {
        // W ostateczności użyj 'REMOTE_ADDR'
        $ip = $_SERVER['REMOTE_ADDR'];
    }
    
    // Opcjonalnie: zweryfikuj, czy adres IP jest poprawny (IPv4/IPv6)
    if (filter_var($ip, FILTER_VALIDATE_IP)) {
        return $ip;
    } else {
        return 'IP nieprawidłowy';
    }
}




define('REFERER_LOG_FILE', 'cantori/referer_log.txt');

// Funkcja zapisująca referer do pliku logowania
function logReferer() {
    // Sprawdzenie, czy zmienna HTTP_REFERER jest ustawiona
    if (isset($_SERVER['HTTP_REFERER'])) {
        // Pobranie adresu URL z HTTP_REFERER i przefiltrowanie
        $referer = filter_var($_SERVER['HTTP_REFERER'], FILTER_SANITIZE_URL);

        // Data i czas zapisu
        $timestamp = date("Y-m-d H:i:s");

        // Formatowanie danych do zapisu
        $logEntry = $timestamp . " - " . $referer . PHP_EOL;

        // Zapis do pliku referer_log.txt
        file_put_contents(REFERER_LOG_FILE, $logEntry, FILE_APPEND | LOCK_EX);
    }
	else{
		$_SESSION['newFile'] = "HTTP_REFERER null";
	}
}
logReferer();




function incrementCounter($filePath) {
    // Odczytaj zawartość pliku, jeśli istnieje, w przeciwnym razie ustaw wartość początkową
    $counter = file_exists($filePath) ? (int)file_get_contents($filePath) : 0;
    $counter++;

    // Zapisz nową wartość do pliku
    if (file_put_contents($filePath, $counter, LOCK_EX) === false) {
        $_SESSION['newFile'] = "Błąd podczas zapisu do pliku.";
    }
}




function checkNewYear() {
    $currentYear = date('Y');
    $lastYear = $currentYear - 1;
    $lastYearFile = 'cantori/lastYear/visits_' . $lastYear . '.php';
    $lastYearFile1 = 'cantori/lastYear/susip_' . $lastYear . '.php';

    if (date('m-d') !== '01-01' || file_exists($lastYearFile)) {
        return;
    }

    if (file_exists(VISITS_FILE)) {
        if (copy(VISITS_FILE, $lastYearFile)) {
            $_SESSION['newFile'] = "Plik 'visits' został skopiowany: " . $lastYearFile;
        } else {
            $_SESSION['newFile'] = "Backup z ostatniego roku dla 'visits' nie powiódł się.";
        }
    } else {
        $_SESSION['newFile'] = "Plik 'visits' nie istnieje.";
    }
}

function resetCountersIfNeeded() {
    $_SESSION['unique_visits_day'] = NA_DZIEN;
    $_SESSION['unique_visits_week'] = NA_TYDZIEN;
    $_SESSION['unique_visits_month'] = NA_MIESIAC;
    $_SESSION['monthly_visits'] = [
        'STYCZEN' => STYCZEN,
        'LUTY' => LUTY,
        'MARZEC' => MARZEC,
        'KWIECIEN' => KWIECIEN,
        'MAJ' => MAJ,
        'CZERWIEC' => CZERWIEC,
        'LIPIEC' => LIPIEC,
        'SIERPIEN' => SIERPIEN,
        'WRZESIEN' => WRZESIEN,
        'PAZDZIERNIK' => PAZDZIERNIK,
        'LISTOPAD' => LISTOPAD,
        'GRUDZIEN' => GRUDZIEN,
    ];
}


  


function reset_another() {

  $resetFile = RESET_DATE;
    $resetDate = file_exists($resetFile) ? file_get_contents($resetFile) : 0;
    $resetDate = $resetDate ? strtotime($resetDate) : 0;
    $currentDate = time();

    if ($resetDate == 0 || date('Y-m-d', $resetDate) != date('Y-m-d', $currentDate)) {
        $_SESSION['unique_visits_day'] = 0;
        file_put_contents($resetFile, date('Y-m-d H:i:s', $currentDate));
    }

    if ($resetDate == 0 || date('W', $resetDate) != date('W', $currentDate)) {
        $_SESSION['unique_visits_week'] = 0;
    }

    if ($resetDate == 0 || date('Y-m', $resetDate) != date('Y-m', $currentDate)) {
        $_SESSION['unique_visits_month'] = 0;
    }
	
    saveVisitCounts(
        $_SESSION['unique_visits_day'],
        $_SESSION['unique_visits_week'],
        $_SESSION['unique_visits_month'],
        $_SESSION['monthly_visits']
    );
}

function countUniqueVisit() {
    resetCountersIfNeeded();
    logVisitorData(SUSIP_FILE);

    $_SESSION['unique_visits_day'] += 1;
    $_SESSION['unique_visits_week'] += 1;
    $_SESSION['unique_visits_month'] += 1;

    $englishToPolishMonths = [
        'January' => 'STYCZEN',
        'February' => 'LUTY',
        'March' => 'MARZEC',
        'April' => 'KWIECIEN',
        'May' => 'MAJ',
        'June' => 'CZERWIEC',
        'July' => 'LIPIEC',
        'August' => 'SIERPIEN',
        'September' => 'WRZESIEN',
        'October' => 'PAZDZIERNIK',
        'November' => 'LISTOPAD',
        'December' => 'GRUDZIEN',
    ];
    $currentMonth = strtoupper($englishToPolishMonths[date('F')]);

    $_SESSION['monthly_visits'][$currentMonth] += 1;
    setcookie('unique_visit', '1', time() + (86400), "/");

    saveVisitCounts(
        $_SESSION['unique_visits_day'],
        $_SESSION['unique_visits_week'],
        $_SESSION['unique_visits_month'],
        $_SESSION['monthly_visits']
    );
}

function checkIpExists($userIp, $filePath = IPEX) {
    $file = fopen($filePath, 'r');
    if ($file) {
        while (($line = fgets($file)) !== false) {
            $line = trim($line);
            if ($line === $userIp) {
                fclose($file);
                return true;
            }
        }
        fclose($file);
    }
    return false;
}

function startTimer() {
    global $startTime;
    $startTime = microtime(true);
}

function endTimer() {
    global $startTime;
    $endTime = microtime(true);
    $loadTime = ($endTime - $startTime) * 1000;

    $updatedLoadTimes = updateLoadTimes($loadTime);
    $averageLoadTime = array_sum($updatedLoadTimes) / count($updatedLoadTimes);

    return [
        'currentLoadTime' => number_format($loadTime, 2),
        'averageLoadTime' => number_format($averageLoadTime, 2)
    ];
}

function updateLoadTimes($newLoadTime) {
    $loadTimes = [];

    if (defined('LOAD_TIMES')) {
        $loadTimes = LOAD_TIMES;
    }

    if (count($loadTimes) >= 5) {
        array_shift($loadTimes);
    }
    $loadTimes[] = str_replace('.', ',', number_format($newLoadTime, 2));

    $data = "<?php\n";
    $data .= "const LOAD_TIMES = " . var_export($loadTimes, true) . ";\n";
    $data .= "?>";

    file_put_contents(VISITS_FILE_S, $data);

    return $loadTimes;
}

?>