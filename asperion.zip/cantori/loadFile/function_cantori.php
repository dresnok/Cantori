<?php

function logVisitorData($filePath) {
    // Walidacja i zabezpieczenie ścieżki pliku
    /* $filePath = realpath($filePath);
     if ($filePath === false || strpos($filePath, 'cantori/susip.txt') !== 0) {
        // Ścieżka jest nieprawidłowa lub nie jest w dozwolonym katalogu
        $newFile = "Ścieżka jest nieprawidłowa lub nie jest w dozwolonym katalogu\n";
		file_put_contents(ERROR_FILE, $newFile, FILE_APPEND);
		return;
    }  */

    // Pobranie aktualnej daty i godziny
    $time = date("Y-m-d H:i:s");

    // Pobranie adresu URL
    $url = filter_var($_SERVER['REQUEST_URI'], FILTER_SANITIZE_STRING);

    // Pobranie adresu IP klienta
    $userIp = filter_var($_SERVER['REMOTE_ADDR'], FILTER_VALIDATE_IP);

    // Lista przeglądarek
    $browsers = [
        'Chrome' => 'Google Chrome',
        'Firefox' => 'Mozilla Firefox',
        'Safari' => 'Safari',
        'MSIE' => 'Internet Explorer',
        'Trident' => 'Internet Explorer',
        'Edge' => 'Microsoft Edge'
    ];

  // Lista systemów operacyjnych
    $osList = [
        'Windows NT 10.0' => 'Windows 10',
        'Windows NT 6.3' => 'Windows 8.1',
        'Windows NT 6.2' => 'Windows 8',
        'Windows NT 6.1' => 'Windows 7',
        'Macintosh' => 'Mac OS',
        'Linux' => 'Linux',
        'Android' => 'Android',
        'iPhone' => 'iOS',
        'iPad' => 'iOS'
    ];

    $userAgent = filter_var($_SERVER['HTTP_USER_AGENT'], FILTER_SANITIZE_STRING);

    // Określenie przeglądarki
    $browser = 'Inna przeglądarka';
    foreach ($browsers as $key => $value) {
        if (strpos($userAgent, $key) !== false) {
            $browser = $value;
            break;
        }
    }

    // Określenie systemu operacyjnego
    $os = 'Inny system operacyjny';
    foreach ($osList as $key => $value) {
        if (strpos($userAgent, $key) !== false) {
            $os = $value;
            break;
        }
    }


function fetchAndDisplayIPData($ip_address) {
    // Walidacja adresu IP
    if (!filter_var($ip_address, FILTER_VALIDATE_IP)) {
        error_log("[ERROR] Nieprawidłowy adres IP: $ip_address");
        return '';
    }

    $api_url = "http://ip-api.com/json/{$ip_address}";
    $response = @file_get_contents($api_url);

    if ($response !== FALSE) {
        $data = json_decode($response, true);

        if (isset($data['status']) && $data['status'] == 'success') {
            $newData = "ip-api.com: Kraj: " . htmlspecialchars($data['country']) . "|" . "Region: " . htmlspecialchars($data['regionName']) . "|" . "Miasto: " . htmlspecialchars($data['city']) . "|" . "ISP: " . htmlspecialchars($data['isp']) . "|";
			return $newData;
        } else {
            error_log("[ERROR] Błąd w pobieraniu danych z API dla IP: $ip_address");
        }
    } else {
        error_log("[ERROR] Nie udało się połączyć z API dla IP: $ip_address");
    }

    return ''; // Zwróć pusty ciąg, jeśli wystąpił błąd
}

// Pobranie danych IP
$user = "52.208.140.159";
$newData = fetchAndDisplayIPData($user);

// Złożenie danych w jeden ciąg znaków
$logEntry = $url . "|" . $browser . "|" . $os . "|" . $time . "|" . $userIp . "|" . $newData . PHP_EOL;


    // Zapisanie danych do pliku logu
    file_put_contents($filePath, $logEntry, FILE_APPEND | LOCK_EX);
}



function checkNewYear() {
    $currentYear = date('Y');
    $lastYear = $currentYear - 1;
    $lastYearFile = 'cantori/lastYear/visits_' . $lastYear . '.php';
    $lastYearFile1 = 'cantori/lastYear/susip_' . $lastYear . '.php';

    // Sprawdzenie, czy data to 22 sierpnia i czy backup już istnieje
    if (date('m-d') !== '01-01' || file_exists($lastYearFile)) {
        return;
    }

    // Kopiowanie pliku VISITS_FILE
    if (file_exists(VISITS_FILE)) {
		
	

        if (copy(VISITS_FILE, $lastYearFile)) {
            $newFile[] = "Plik 'visits' został skopiowany: " . $lastYearFile;
        } else {
            $newFile[] = "Backup z ostatniego roku dla 'visits' nie powiódł się.";
        }
    } else {
        $newFile[] = "Plik 'visits' nie istnieje.";
    }

}



function resetCountersIfNeeded() {
    // Ustawienie domyślnych wartości zmiennych sesji
    $_SESSION['unique_visits_day'] = NA_DZIEN;
    $_SESSION['unique_visits_week'] = NA_TYDZIEN;
    $_SESSION['unique_visits_month'] = NA_MIESIAC;
    $_SESSION['monthly_visits'] = array(
        'STYCZEN' => STYCZEN,
        'LUTY' => LUTY,
        'MARZEC' => MARZEC,
        'KWIECIEN' => KWIECIEN,
        'MAJ' => MAJ,
        'CZERWIEC' => CZERWIEC,
        'LIPIEC' => LIPIEC,
        'SIERPIEN' => SIERPIEN,
        'WRZESIEN' => WRZESIEN,
        'PAZDZIERNIK' => PAZDZIERNIK,
        'LISTOPAD' => LISTOPAD,
        'GRUDZIEN' => GRUDZIEN,
    );
    

// Ścieżka do pliku z datą ostatniego resetu
$resetFile = RESET_DATE;

// Odczyt daty ostatniego resetu z pliku, jeśli plik istnieje
$resetDate = file_exists($resetFile) ? file_get_contents($resetFile) : 0;
$resetDate = $resetDate ? strtotime($resetDate) : 0;
$currentDate = time(); // Aktualna data

// Sprawdzenie, czy minął dzień
if ($resetDate == 0 || date('Y-m-d', $resetDate) != date('Y-m-d', $currentDate)) {
    // Resetowanie licznika dziennego
    $_SESSION['unique_visits_day'] = 0;
    // Aktualizacja pliku z datą resetu na aktualny dzień
    file_put_contents($resetFile, date('Y-m-d H:i:s', $currentDate));
}

// Sprawdzenie, czy minął tydzień
if ($resetDate == 0 || date('W', $resetDate) != date('W', $currentDate)) {
    // Resetowanie licznika tygodniowego
    $_SESSION['unique_visits_week'] = 0;
    // Aktualizacja pliku z datą resetu na aktualny dzień (zostało już zaktualizowane wcześniej)
}

// Sprawdzenie, czy minął miesiąc
if ($resetDate == 0 || date('Y-m', $resetDate) != date('Y-m', $currentDate)) {
    // Resetowanie licznika miesięcznego
    $_SESSION['unique_visits_month'] = 0;
    // Aktualizacja pliku z datą resetu na aktualny dzień (zostało już zaktualizowane wcześniej)
}


}

function reset_another() {
resetCountersIfNeeded();
saveVisitCounts(
        $_SESSION['unique_visits_day'],
        $_SESSION['unique_visits_week'],
        $_SESSION['unique_visits_month'],
        $_SESSION['monthly_visits'],
        
    );
}


function countUniqueVisit() {
    resetCountersIfNeeded();

	// Rejestracja odwiedzin
    logVisitorData(SUSIP_FILE);


    $_SESSION['unique_visits_day'] += 1;
    $_SESSION['unique_visits_week'] += 1;
    $_SESSION['unique_visits_month'] += 1;

    $englishToPolishMonths = [
        'January' => 'STYCZEN',
        'February' => 'LUTY',
        'March' => 'MARZEC',
        'April' => 'KWIECIEN',
        'May' => 'MAJ',
        'June' => 'CZERWIEC',
        'July' => 'LIPIEC',
        'August' => 'SIERPIEN',
        'September' => 'WRZESIEN',
        'October' => 'PAZDZIERNIK',
        'November' => 'LISTOPAD',
        'December' => 'GRUDZIEN',
    ];
    $currentMonth = strtoupper($englishToPolishMonths[date('F')]);

    $_SESSION['monthly_visits'][$currentMonth] += 1;

    setcookie('unique_visit', '1', time() + (86400), "/"); // 86400 sekund = 1 dzień

    saveVisitCounts(
        $_SESSION['unique_visits_day'],
        $_SESSION['unique_visits_week'],
        $_SESSION['unique_visits_month'],
        $_SESSION['monthly_visits'],
        
    );
}







function checkIpExists($userIp, $filePath = IPEX) {
    $file = fopen($filePath, 'r');
    if ($file) {
        while (($line = fgets($file)) !== false) {
            $line = trim($line); // Usunięcie dodatkowych białych znaków
            
            if ($line === $userIp) {
                fclose($file);
                return true; // IP zostało znalezione
            }
        }
        fclose($file);
    }
    return false; // IP nie zostało znalezione
}


// Funkcja do uruchomienia na początku skryptu
function startTimer() {
    global $startTime;
    $startTime = microtime(true);
}

// Funkcja do uruchomienia na końcu skryptu
function endTimer() {
    global $startTime;
    $endTime = microtime(true);
    $loadTime = ($endTime - $startTime) * 1000; // Przekształcenie na milisekundy

    // Zapisanie czasu ładowania strony do pliku
    $updatedLoadTimes = updateLoadTimes($loadTime);

    // Obliczenie średniego czasu ładowania
    $averageLoadTime = array_sum($updatedLoadTimes) / count($updatedLoadTimes);

    return [
        'currentLoadTime' => number_format($loadTime, 2),
        'averageLoadTime' => number_format($averageLoadTime, 2)
    ];
	
}





// Funkcja do aktualizacji czasów ładowania
function updateLoadTimes($newLoadTime) {
    $loadTimes = [];

    // Sprawdź, czy plik istnieje przed próbą jego załadowania
    if (defined('LOAD_TIMES')) {
        $loadTimes = LOAD_TIMES;
    }

    if (count($loadTimes) >= 5) {
        array_shift($loadTimes); // Usuń najstarszy wpis, jeśli mamy już 5
    }
    $loadTimes[] = str_replace('.', ',', number_format($newLoadTime, 2));
 // Precyzja do 2 miejsc po przecinku

    // Zapisanie nowych czasów do pliku visits.php
    $data = "<?php\n";
    $data .= "const LOAD_TIMES = " . var_export($loadTimes, true) . ";\n";
    $data .= "?>";

    // Próba zapisu do pliku
    file_put_contents(VISITS_FILE_S, $data);

    return $loadTimes;
}