<?php
session_start();
date_default_timezone_set('Europe/Warsaw');

define('BACKUPDIRECTORY', '../backup/');
define('IMAGE_TYPES', ['image/jpeg', 'image/png', 'image/gif', 'image/bmp', 'image/webp']);
define('TARGETDIRECTORY', '../dorme/');
define('TEMPLATETWO', '../dodatki/templatetwo.webp');
define('TEMPLATEONE', '../dodatki/templateone.webp');

$dir_info = "../../info.php";

function moveFileToBackup($directory) {
    $allowedExtensions = ['jpg', 'jpeg', 'png', 'webp', 'tiff'];
    global $error_file, $errors;

    $iterator = new DirectoryIterator($directory);
    $fileFound = false;

    foreach ($iterator as $file) {
        if ($file->isFile()) {
            $extension = strtolower(pathinfo($file->getFilename(), PATHINFO_EXTENSION));
            if (in_array($extension, $allowedExtensions)) {
                $fileFound = true;
                $backupPath = BACKUPDIRECTORY . DIRECTORY_SEPARATOR . $file->getFilename();
                if (!file_exists(BACKUPDIRECTORY)) {
                    mkdir(BACKUPDIRECTORY, 0777, true);
                }
                rename($file->getRealPath(), $backupPath);
                return;
            }
        }
    }

    if (!$fileFound) {
        $_SESSION['newInfo'] = 'Plik nie istnieje.';
    }
}

function is_image($file_path) {
    $file_info = getimagesize($file_path);
    return $file_info && in_array($file_info['mime'], IMAGE_TYPES);
}

function clear_directory($directory) {
    $iterator = new DirectoryIterator($directory);
    foreach ($iterator as $file) {
        if (!$file->isDot() && $file->isFile()) {
            unlink($file->getPathname());
        }
    }
}

function copy_image($source_file, $target_dir) {
    global $newInfo;  // Aby zmienna $newInfo była widoczna

    if (!is_file($source_file)) {
        $_SESSION['newInfo'] = "Plik nie jest zdjęciem lub nie istnieje (Zmień tło): $source_file";
        return false;  // Dodaj zwrot fałszu
    }

    if (!is_dir($target_dir)) {
        $_SESSION['newInfo'] = "Katalog nie istnieje (Zmień tło): $target_dir";
        return false;  // Dodaj zwrot fałszu
    }

    // Wyczyść katalog docelowy
    clear_directory($target_dir);

    if (is_image($source_file)) {
        $file_name = basename($source_file);
        $target_file = $target_dir . DIRECTORY_SEPARATOR . $file_name;

        if (!copy($source_file, $target_file)) {
            $_SESSION['newInfo'] = "Nie udało się wykonać funkcji.";
            return false;  // Dodaj zwrot fałszu
        } else {
            $_SESSION['newInfo'] = "Przeniosłem plik do kosza.";
            return true;  // Dodaj zwrot prawdy
        }
    } else {
        $_SESSION['newInfo'] = "Plik nie jest zdjęciem (Zmień tło): $source_file";
        return false;  // Dodaj zwrot fałszu
    }
}

if (($_SERVER["REQUEST_METHOD"] == "POST") && isset($_POST['move_background'])) {
    $action = $_POST['action'] ?? '';
 
    switch ($action) {
        case 'moveOrDeleteFile':
            if (moveFileToBackup(TARGETDIRECTORY)) {
                $_SESSION['newInfo'] = 'Przeniosłem plik do folderu ' . BACKUPDIRECTORY;
            } else {
                $_SESSION['newInfo'] = "Akcja wykonana pomyślnie.";
            }
            break;
        
        case 'Template_one':
            if (copy_image(TEMPLATEONE, TARGETDIRECTORY)) {
                // Sukces, można coś tutaj dodać jeśli trzeba
            } else {
                $_SESSION['newInfo'] = 'Błąd: nie udało się skopiować obrazu.';
                error_log("[" . date("Y-m-d H:i:s") . "] Błąd: nie udało się skopiować obrazu. " . TEMPLATEONE . " - " . TARGETDIRECTORY);
            }
            break;

        case 'Template_two':
            if (copy_image(TEMPLATETWO, TARGETDIRECTORY)) {
                // Sukces, można coś tutaj dodać jeśli trzeba
            } else {
                $_SESSION['newInfo'] = 'Błąd: nie udało się skopiować obrazu.';
                error_log("[" . date("Y-m-d H:i:s") . "] Błąd: nie udało się skopiować obrazu. " . TEMPLATETWO . " - " . TARGETDIRECTORY);
            }
            break;
    }
	header("Location: $dir_info");
	exit;
}

if (isset($_POST['zmienTlo']) && $_POST['zmienTlo'] === "uploadFile") {
    $targetFile = TARGETDIRECTORY . '/' . basename($_FILES["fileToUpload"]["name"]);
    $uploadOk = 1;
    $imageFileType = strtolower(pathinfo($targetFile, PATHINFO_EXTENSION));

    // Sprawdź, czy plik jest obrazem
    if (isset($_POST["submit"])) {
        $check = getimagesize($_FILES["fileToUpload"]["tmp_name"]);
        if ($check !== false) {
            $_SESSION['newInfo'] = "Plik jest obrazem - " . $check["mime"] . ".";
            $uploadOk = 1;
        } else {
            $_SESSION['newInfo'] = "Plik nie jest obrazem.";
            $uploadOk = 0;
        }
    }

    // Sprawdź, czy plik już istnieje w katalogu docelowym
    if (file_exists($targetFile)) {
        $_SESSION['newInfo'] = "Przepraszamy, plik już istnieje.";
        $uploadOk = 0;
    }

    // Sprawdź rozmiar pliku
    if ($_FILES["fileToUpload"]["size"] > 5 * 1024 * 1024) { // Limit 5MB
        $_SESSION['newInfo'] = "Przepraszamy, Twój plik jest za duży.";
        $uploadOk = 0;
    }

    // Zezwól na określone formaty plików
    if (!in_array($imageFileType, ['jpg', 'jpeg', 'png', 'webp', 'tiff'])) {
        $_SESSION['newInfo'] = "Przepraszamy, tylko pliki JPG, JPEG, PNG, WEBP & TIFF są dozwolone.";
        $uploadOk = 0;
    }

    // Sprawdź, czy $uploadOk jest ustawiony na 0 z powodu błędu
    if ($uploadOk == 0) {
        $_SESSION['newInfo'] = "Twój plik nie został przesłany.";
    // jeśli wszystko jest ok, spróbuj przesłać plik
    } else {
        // Przenieś istniejący plik do katalogu zapasowego
        moveFileToBackup(TARGETDIRECTORY);

        if (move_uploaded_file($_FILES["fileToUpload"]["tmp_name"], $targetFile)) {
            $_SESSION['newInfo'] = "Plik " . htmlspecialchars(basename($_FILES["fileToUpload"]["name"])) . " został przesłany.";
        } else {
            $_SESSION['newInfo'] = "Wystąpił błąd podczas przesyłania pliku.";
        }
    }
	header("Location: $dir_info");
	exit;
}
?>
