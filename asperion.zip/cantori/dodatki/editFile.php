<!DOCTYPE html>
<html lang="pl">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Panel Statystyk Strony</title>
  <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
  <link id="customStylesheet" rel="stylesheet" href="cantori/css/default-styles.css">
  <style>
    /* Dodaj własne style tutaj, jeśli potrzebujesz */
  </style>
</head>
<body>

<?php
// Pobranie adresu IP użytkownika
$userIp = $_SERVER['REMOTE_ADDR'];
// Sprawdzenie, czy użytkownik jest lokalny (localhost)
if ($userIp === "::1" || $userIp === "localhost") {
    // Jeśli użytkownik jest lokalny, ustal ścieżkę w kontekście localhosta
    $basePath = $_SERVER['DOCUMENT_ROOT'] . "/asperion/";
} else {
    // Dla użytkowników zdalnych ustaw standardową ścieżkę
    $basePath = $_SERVER['DOCUMENT_ROOT'] . "/";
}
$zmienne = $basePath . "cantori/loadFile/modifica.php";
if (!file_exists($zmienne)) {
    $newInfo = "Plik: " . $zmienne . ", nie istnieje.";
    echo "<div class='alert alert-secondary'>" . $newInfo . "</div>";
    exit;
} else {
    include "../loadFile/modifica.php";
}
// Tablica stron z plikami, które można wyświetlić
$pages = ["visits" => $basePath . VISITS_FILE, "susip" => $basePath . SUSIP_FILE, "errorFile" => $basePath . ERROR_FILE, ];
// Sprawdzenie, czy parametr 'file' jest przekazany w URL i czy istnieje w tablicy $pages
$index = isset($_GET['file']) ? strip_tags($_GET['file']) : null;
if ($index && array_key_exists($index, $pages)) {
    // Odczytanie zawartości pliku
    if (file_exists($pages[$index])) {
        $content = file_get_contents($pages[$index]);
        // Wyświetlenie zawartości pliku
        echo nl2br($content);
    } else {
        echo "Brak pliku.";
    }
}
?>

</body>
</html>
