<?php
const LOAD_TIMES = array (
  0 => '2,036,40',
  1 => '23,06',
  2 => '44,38',
);
?>