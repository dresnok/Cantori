<?php
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
$jsonData = file_get_contents('php://input');
if ($jsonData) {
$orderData = json_decode($jsonData, true);
if (json_last_error() === JSON_ERROR_NONE) {
file_put_contents('order.json', json_encode($orderData, JSON_PRETTY_PRINT));
echo json_encode(['status' => 'success', 'message' => 'Dane zostały zapisane pomyślnie.']);
        } else {
echo json_encode(['status' => 'error', 'message' => 'Błąd dekodowania JSON.']);
        }
    } else {
echo json_encode(['status' => 'error', 'message' => 'Brak danych.']);
    }
} else {
echo json_encode(['status' => 'error', 'message' => 'Nieprawidłowa metoda żądania.']);
}
?>
