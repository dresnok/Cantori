<?php
// save_order.php

// Odczyt JSON z POST
$data = file_get_contents("php://input");
$decodedData = json_decode($data, true);

if (isset($decodedData['order'])) {
    // Zapisz nowy układ w pliku order.json
    file_put_contents('order.json', json_encode($decodedData['order'], JSON_PRETTY_PRINT));
    echo 'Układ został zapisany.';
} else {
    echo 'Niepoprawne dane.';
}
?>
