
<script>

document.write('Błąasdrem.');
</script>
