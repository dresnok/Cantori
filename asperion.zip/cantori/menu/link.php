<table id="sortable">
    <tbody>
       
    </tbody>
</table>
<div class="my-2">
<button id="toggle-buttons">
    <i class="fa-solid fa-pencil"></i>
</button>

<button id="add-entry">
    <i class="fa-solid fa-plus"></i> Nowy wpis
</button>
</div>
<script src="https://unpkg.com/validator@latest/validator.min.js"></script>
<script>
function saveOrder() {
    const listItems = document.querySelectorAll('#sortable tr');
    const order = Array.from(listItems).map(item => {
        const spanName = item.querySelector('span');
        const sciezka = item.id;
        const tekst = item.querySelector('textarea') ? item.querySelector('textarea').value : '';

        return {
            nazwa: spanName.textContent.trim(),
            sciezka: sciezka,
            tekst: tekst
        };
    });

    const xhr = new XMLHttpRequest();
    xhr.open("POST", "save_order.php", true);
    xhr.setRequestHeader("Content-Type", "application/json;charset=UTF-8");
    xhr.send(JSON.stringify(order));
}

function loadOrder() {
    const xhr = new XMLHttpRequest();
    xhr.open("GET", "order.json?v=" + new Date().getTime(), true);
    xhr.onload = function () {
        if (xhr.status === 200) {
            const order = JSON.parse(xhr.responseText);
            const list = document.getElementById('sortable');
            list.innerHTML = '';
            order.forEach(item => {
                const nazwa = item.nazwa ? item.nazwa.substring(0, 50) : 'Brak nazwy';
                const sciezka = item.sciezka ? item.sciezka : '';
                const tekst = item.tekst ? item.tekst.substring(0, 1000) : 'Brak opisu';

                createListItem(sciezka, nazwa, tekst);
            });
        } else {
            console.error("Błąd ładowania JSON: ", xhr.statusText);
        }
    };
    xhr.send();
}

function createListItem(id, name, description) {
    const table = document.getElementById('sortable');
    const tr = document.createElement('tr');
    tr.id = id;

    const td = document.createElement('td');

    const spanName = document.createElement('span');
    spanName.textContent = name.substring(0, 50);
    spanName.style.cursor = 'pointer';
    spanName.classList.add('name-style');
    
    td.appendChild(spanName);

    // Użycie validator.js do walidacji URL
    const sciezkaParagraph = document.createElement('a');
    sciezkaParagraph.classList.add('st-style');
    sciezkaParagraph.style.display = 'none'; 
    const errorMessage = document.createElement('span'); 
    errorMessage.style.display = 'none'; 

    // Użyj validator.isURL do sprawdzenia URL
    if (validator.isURL(id)) {
        if (!/^https?:\/\//i.test(id)) {
            sciezkaParagraph.href = 'http://' + id;
        } else {
            sciezkaParagraph.href = id;
        }
        sciezkaParagraph.textContent = id;
    } else {
        sciezkaParagraph.href = '#';
        sciezkaParagraph.textContent = id;
        errorMessage.textContent = 'link nieprawidłowy'; 
        errorMessage.style.color = 'lightblue'; 
        errorMessage.classList.add('track-style');
    }

    // Dodaj elementy do DOM
    td.appendChild(sciezkaParagraph);
    td.appendChild(errorMessage); 

    const descriptionParagraph = document.createElement('p');
    descriptionParagraph.textContent = description.substring(0, 1000);
    descriptionParagraph.style.display = 'none';
    descriptionParagraph.classList.add('dsc-style');

    td.appendChild(sciezkaParagraph);
    td.appendChild(descriptionParagraph);

    const inputName = document.createElement('input');
    inputName.type = 'text';
    inputName.value = name;
    inputName.maxLength = 50;
    inputName.style.display = 'none';
    inputName.className = 'input-control';

    const inputSciezka = document.createElement('input');
    inputSciezka.type = 'text';
    inputSciezka.value = id;
    inputSciezka.maxLength = 50;
    inputSciezka.style.display = 'none';
    inputSciezka.className = 'input-control';

    const inputDescription = document.createElement('textarea');
    inputDescription.value = description;
    inputDescription.maxLength = 1000;
    inputDescription.style.display = 'none';
    inputDescription.className = 'form-control';

    const editButton = document.createElement('button');
    editButton.innerHTML = '<i class="fas fa-edit"></i> Edytuj';
    editButton.classList.add('edit', 'option-button');

    const saveButton = document.createElement('button');
    saveButton.innerHTML = '<i class="fas fa-save"></i> Zapisz';
    saveButton.classList.add('save', 'option-button');
    saveButton.style.display = 'none';

    const deleteButton = document.createElement('button');
    deleteButton.innerHTML = '<i class="fas fa-trash-alt"></i> Usuń';
    deleteButton.classList.add('delete', 'option-button');

    td.appendChild(inputName);
    td.appendChild(inputSciezka);
    td.appendChild(inputDescription);
    td.appendChild(editButton);
    td.appendChild(saveButton);
    td.appendChild(deleteButton);

    tr.appendChild(td);
    table.appendChild(tr);

    spanName.addEventListener('click', () => {
        const isVisible = descriptionParagraph.style.display === 'block';
        descriptionParagraph.style.display = isVisible ? 'none' : 'block';
        sciezkaParagraph.style.display = isVisible ? 'none' : 'block';

        if (!validator.isURL(id)) {
            errorMessage.style.display = isVisible ? 'none' : 'block';
        }
    });

    editButton.addEventListener('click', () => {
        document.getElementById('toggle-buttons').disabled = true;
        const otherEditButtons = document.querySelectorAll('.delete, .edit, .save');
        otherEditButtons.forEach(button => {
            if (button !== editButton) {
                button.style.display = 'none';
            }
        });

        spanName.style.display = 'none';
        sciezkaParagraph.style.display = 'none';
        descriptionParagraph.style.display = 'none';
        inputName.style.display = 'block';
        inputSciezka.style.display = 'block';
        inputDescription.style.display = 'block';
        saveButton.style.display = 'inline-block';
        editButton.style.display = 'none';
        inputName.focus();
        errorMessage.style.display = 'none';
    });

function hasInvalidCharacters(str) {
    const forbiddenChars = /[^a-zA-Z0-9\s\-_\.@]/;
    return forbiddenChars.test(str);
}

saveButton.addEventListener('click', () => {
    const newName = inputName.value.trim();
    const newSciezka = inputSciezka.value.trim();
    const newDescription = inputDescription.value.trim();

    // Walidacja nazwy
    if (newName === '') {
        alert('Nazwa nie może być pusta!');
        inputName.focus();
        return;
    }
const message = 'Dozwolone znaki - A-z -_.@';

    // Sprawdzenie niedozwolonych znaków w nazwie
    if (hasInvalidCharacters(newName)) {
        alert(message);
        inputName.focus();
        return;
    }

    // Walidacja ścieżki
    if (!validator.isURL(newSciezka)) {
        alert('Ścieżka musi być prawidłowym URL!');
        inputSciezka.focus();
        return;
    }

    // Sprawdzenie niedozwolonych znaków w ścieżce
    if (hasInvalidCharacters(newSciezka)) {
        alert(message);
        inputSciezka.focus();
        return;
    }

    // Walidacja opisu
    if (newDescription.length > 1000) {
        alert('Opis nie może przekraczać 1000 znaków!');
        inputDescription.focus();
        return;
    }

    // Sprawdzenie niedozwolonych znaków w opisie
    if (hasInvalidCharacters(newDescription)) {
        alert(message);
        inputDescription.focus();
        return;
    }

    // Jeśli wszystko jest w porządku, zaktualizuj dane
    if (newName !== '') {
        spanName.textContent = newName.substring(0, 50); 
    }

    if (newSciezka !== '') {
        sciezkaParagraph.textContent = newSciezka.substring(0, 50); 
        tr.id = newSciezka; 
    }

    if (newDescription !== '') {
        descriptionParagraph.textContent = newDescription.substring(0, 1000); 
    }

    inputName.style.display = 'none';
    inputSciezka.style.display = 'none';
    inputDescription.style.display = 'none';
    spanName.style.display = 'block';
    sciezkaParagraph.style.display = 'block';
    descriptionParagraph.style.display = 'block';
    saveButton.style.display = 'none';
    editButton.style.display = 'inline-block';
    
    saveOrder();
    document.getElementById('toggle-buttons').disabled = false;

    const otherEditButtons = document.querySelectorAll('.delete, .edit, .save');
    otherEditButtons.forEach(button => {
        button.style.display = 'none';
    });
});


    const saveOnEnter = (event) => {
        if (event.key === 'Enter') {
            saveButton.click(); 
        }
    };

    inputName.addEventListener('keydown', saveOnEnter);
    inputSciezka.addEventListener('keydown', saveOnEnter);
    inputDescription.addEventListener('keydown', saveOnEnter);

    deleteButton.addEventListener('click', () => {
        const confirmation = confirm("Czy na pewno chcesz usunąć ten element?");
        if (confirmation) {
            table.removeChild(tr);
        }
        saveOrder();
    });
}

document.getElementById('toggle-buttons').addEventListener('click', () => {
    const editButtons = document.querySelectorAll('.edit, .delete');
    editButtons.forEach(button => {
        if (button.style.display === 'none' || button.style.display === '') {
            button.style.display = 'block';
        } else {
            button.style.display = 'none';
        }
    });
});

document.getElementById('add-entry').addEventListener('click', () => {
    const newId = `google.com`;
    const newName = 'Nowy element';
    const newDescription = 'Opis';

    createListItem(newId, newName, newDescription);
    saveOrder();
});

loadOrder();
</script>
