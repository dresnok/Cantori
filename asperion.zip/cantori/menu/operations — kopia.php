<?php

if (empty($_SESSION['csrf_token2'])) {
    $_SESSION['csrf_token2'] = bin2hex(random_bytes(32));
}

?>		
<!-- Operacje -->
<div class="section" id="operacje">
            <h2>Operacje</h2>
			<!--<a href="http://kinpin.antyki.space/" title="link" class="vok">http://kinpin.antyki.space/</a>-->
			</div>
			<div class="section bla">
			<table class="table">
                <tbody>
           

		<tr>
			<td>
			Wygeneruj plik</button>
			</td>
			
<td>

	<form method="post" action="cantori/loadFile/SendEmail.php">
	<button type="submit" name="downloadFile" >Download</button>
	</form>

</td>
</tr>
			
	
			
			<tr>
			<td rowspan="2">
			Wykluczenia IP
			</td>
		<td class="userIpCounts">
		<?php
		$plik1 = "cantori/ipEx.txt";

$content2 = @file_get_contents($plik1);

if ($content2 === false) {
    $content2 = "Plik nie istnieje: " . basename($plik1);
} else {
    // Zamiana nowych linii na <br> dla lepszej widoczności w HTML
    $content2 = nl2br(htmlspecialchars($content2));
}

// Wyświetlenie zawartości pliku
echo $content2;
		?>
		
		</td>
		
		</tr><tr>

			<td>
	<form method="post" action="cantori/loadFile/SendEmail.php">

<label>
<input class="btn" type="checkbox" name="address[]" value="127.0.0.1">localhost
</label>

<label>
<input class="btn" type="checkbox" name="address[]" value="moj_adres_ip">Mój adres IP
</label>
<button type="submit" name="action" value="dodaj_local">Dodaj</button>

<p>
        <!-- Dodaj wykluczenie -->
		 <label for="dodaj_wykluczenie">Dodaj wykluczenie:</label>
        <input class="btn btn-sm ffPath" type="text" name="dodaj_wykluczenie">
        <button type="submit" name="action" value="dodaj_wykluczenie">Dodaj</button>
</p>
<p>
        <!-- Usuń wykluczenie -->
		<label for="usun_wykluczenie">Usuń wykluczenie:</label>
        <input class="btn btn-sm ffPath" type="text" name="usun_wykluczenie">
        <button type="submit" name="action" value="usun_wykluczenie">Usuń</button>
		</p>

        <!-- Usuń wszystkie wykluczenia -->
        <button type="submit" name="action" value="usun_wszystkie_wykluczenia">Usuń wszystkie wykluczenia</button>

		<input type="hidden" name="wykluczenia">
	</form>

			</td>
			
			</tr>	
			
		
		
<tr>
			<td id="genHaslo">
			Generator hasła
			</td>
			
			<td>
			
			<?php
			

	if(isset($_SESSION['hash_hasla']) && $_SESSION['hash_hasla']){
echo "<p>" . $_SESSION['hash_hasla'] . "</p>";
}

?>

<form action="cantori/loadFile/SendEmail.php" method="post">
<input class="btn btn-sm ffPath" name="haslo" placeholder="Podaj hasło do schaszowania" type="password" required>
<input type="hidden" name="nowe" value="1">


<button type="submit">Generuj</button>

</form>

			</td>
			
			</tr>
<tr><td>Zmień hasło</td>
			
			<td>
			  <form action="cantori/loadFile/SendEmail.php" method="post">
        <label for="old_password">Stare hasło:</label>
        <input class="btn btn-sm ffPath" type="password" id="old_password" name="password2" required><br><br>
        
        <label for="new_password">Nowe hasło:</label>
        <input class="btn btn-sm ffPath" type="password" id="new_password" name="new_password" required><br><br>
        
        <label for="confirm_password">Potwierdź nowe hasło:</label>
        <input class="btn btn-sm ffPath" type="password" id="confirm_password" name="confirm_password" required><br><br>
        
        <input type="submit" value="Zmień hasło">
    </form>
			</td>
			
			</tr>


            
			<tr>
			<td>
			Zmień tło<br>
					<!--<a href="http://contafe.antyki.space/" title="link" class="vok">http://contafe.antyki.space/</a>-->
			</td>
			<td>
		<form method="post" action="cantori/dodatki/sfondo.php" enctype="multipart/form-data">
    
    Wybierz plik do przesłania:
    <p>
    <input class="btn btn-sm ffPath" type="file" name="fileToUpload" id="fileToUpload" required></p>
    <input type="hidden" name="csrf_token"value="<?php echo ($_SESSION['csrf_token2']); ?>">
    <p><button type="submit" value="uploadFile" name="zmienTlo">Prześlij plik</button></p>
    </form>
	
	<form method="post" action="cantori/dodatki/sfondo.php">
    <select name="action">
        <option value="moveOrDeleteFile">Usuń tło</option>
        <option value="Template_one">Template_one</option>
        <option value="Template_two">Template_two</option>
    </select>
<input type="hidden" name="move_background">
    <p><button type="submit">Wykonaj</button></p>
    
</form>

			</td>
			
			</tr>
			</tbody></table>
				</div>
