<?php
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}
date_default_timezone_set('Europe/Warsaw');

define('BACKUPDIRECTORY', '../backup/');
define('DOWNLOADFILE', '../downloadFile/');
define('IMAGE_TYPES', ['image/jpeg', 'image/png', 'image/gif', 'image/bmp', 'image/webp']);
define('SUSIP_FILE', '../susip.txt');
define('VISITS_FILE', '../visits.php');
define('INFO_FILE', '../../info.php');
define('ERROR_FILE', '../../errorFile.log');
define('LAST_YEAR', '../lastYear/');
define('VISTITS_FILE', '../loadFile/vistits_file.php');
define('MENU_FUNCTION', '../loadFile/menu_function.php');

//if(file_exists(VISITS_FILE)){include(VISITS_FILE);}
include(VISTITS_FILE);
include(MENU_FUNCTION);

if (empty($_SESSION['csrf_token1'])) {
    $_SESSION['csrf_token1'] = bin2hex(random_bytes(32));
}
?>

 
<!-- Wizyty użytkowników -->
<div class="section">



            <h2>Wizyty użytkowników na stronie (cantori/visits.php)</h2>
			
			<div class="section">
            
            <table class="table">
			
			 <thead>
                    <tr>
                        <th>W tym dniu</th>
<th>W tym tygodniu</th>
<th>W tym miesiącu</th>

                    </tr>
                </thead>
				
			<tbody><tr>
            <td><?php echo (!empty($_SESSION["unique_visits_day"]) ? $_SESSION["unique_visits_day"] : "");
			
?></td>
            <td><?php echo (!empty($_SESSION["unique_visits_week"]) ? $_SESSION["unique_visits_week"] : "");
?></td>
            <td><?php echo (!empty($_SESSION["unique_visits_month"]) ? $_SESSION["unique_visits_month"] : "");
?></td>
			
			</tr>
			</tbody>
			</table>
						
			
			</div></div>
			
<!-- Statystyki odwiedzin -->
<div class="section" id="st_od">
            <h2>Statystyki odwiedzin (cantori/visits.php)</h2>
			
			</div>
			
			<div class="section">
		<form action="cantori/loadFile/seeMoreFile.php" method="post">
		<table class="table">

           
<?php
$months = ['STYCZEN', 'LUTY', 'MARZEC', 'KWIECIEN', 'MAJ', 'CZERWIEC', 'LIPIEC', 'SIERPIEN', 'WRZESIEN', 'PAZDZIERNIK', 'LISTOPAD', 'GRUDZIEN'];
?>
<?php foreach ($months as $month): ?>

		<tr>
		<td class="col-4"><?php echo $month; ?></td>
		<td class="at col-4">
		
		<input class="btn ffPath" type="number" name="visits_<?php echo $month; ?>" value="<?php echo $_SESSION["monthly_visits"][$month] ?? ''; ?>">
		</td>
		<td class="col-4">
		<input type="submit" name="submit_<?php echo $month; ?>" value="Zapisz">
		


            <?php endforeach; ?>

<input type="hidden" name="SeeMoreFile">
<input type="hidden" name="csrf_token1" value="<?php echo ($_SESSION['csrf_token1']); ?>">
</form>

</td></tr>
    

    
	</table>
				</div>
				

<!-- Operacje -->
<div class="section">
            <h2>Statystyka raportu (cantori/susip.txt)</h2>
		
			

			</div>
			<div class="section bla">
			<table class="table">
                <tbody>
           
			<tr>
			
			<td>
			URL Counts
			</td>
			<td class="userIpCounts">
			
			<?php

// Pobranie adresu URL
$url = $_SERVER['REQUEST_URI'];
foreach ($urlCounts as $url => $count) {
echo "$url: $count<br>";

}

?>

			</td>
			</tr>
			
						<tr>
			
			<td>
			Browser Counts
			</td>
			<td>
			<?php
foreach ($browserCounts as $browser => $count) {
    echo "$browser: $count<br>";
}
?>
			</td>
			</tr>
			
									<tr>
			
			<td>
			OS Counts
			</td>
			<td>
			<?php
foreach ($osCounts as $os => $count) {
    echo "$os: $count<br>";
}
?>
			</td>
			</tr>
			
							<tr>
			
			<td>
			User IP Counts
			</td>
<td class="userIpCounts">
			<?php
			
// Wyświetlanie wyników dla adresów IP użytkowników
$uniqueIpCount = 0;
foreach ($userIpCounts as $userIp => $count) {
    echo "$userIp<br>";
	echo $newData1 . " | " . $newData2 . " | " . $newData3 . "<br>";
    echo "($count) Daty: " . implode(' | ', $userIpDates[$userIp]) . "<br><br>";
$uniqueIpCount++;

}


?>

			</td>
			</tr>
			
										<tr>
			
			<td>


			</td>
			<td>

			<?php
echo "Całkowita liczba wpisów: $totalEntries<br>";
echo "Liczba unikalnych adresów IP: $uniqueIpCount<br>";
?>

			</td>
			</tr>



			</table>
                </tbody>
			</div>
			
			
			
				
				<div class="section">
            <h2 id="ipUnik">Statystyki upływu czasu</h2>

	</div>
			
			<div class="section">
            
            <table class="table">
			<tbody><tr>
            <td>
			Panel
			</td>
            <td></td>
			<td>
			
<?php 

displayFileOrFolderTimes(INFO_FILE); ?>
			</td></tr>
			
			<tr><td>
			
			<a href="cantori/dodatki/editFile.php?file=visits" target="blank" title="visits">Statystyki odwiedzin: </a>
			
			</td>
            <td><a href="cantori/loadFile/delateFile.php?usun=visits_file" onclick="return confirm('Czy na pewno chcesz usunąć ten plik?');" class="kkFile" title="usuń">usuń</a></td>
			<td>
			<?php displayFileOrFolderTimes(VISITS_FILE); ?>
			</td>
			
			
			</tr><tr>
			
			<tr><td>
			
			<a href="cantori/dodatki/editFile.php?file=susip" target="blank" title="susip">Statystyka raportu: </a>
			
		
			
			</td>
            <td><a href="cantori/loadFile/delateFile.php?usun=susip_file" onclick="return confirm('Czy na pewno chcesz usunąć ten plik?');" class="kkFile" title="usuń">usuń</a></td>
			<td>
			<?php displayFileOrFolderTimes(SUSIP_FILE); ?>
			
			</td>
			
			
			</tr><tr>
			<td>
			<a href="cantori/dodatki/editFile.php?file=errorFile" target="blank" title="errorFile">Logi: </a>
			
				
			
			</td>
            <td><a href="cantori/loadFile/delateFile.php?usun=errorfile" onclick="return confirm('Czy na pewno chcesz usunąć ten plik?');" class="kkFile" title="usuń">usuń</a></td>
			<td>
			<?php displayFileOrFolderTimes(ERROR_FILE); ?>
			
			</td>
			
			
			</tr>
			
			
	

			<tr>
				<td>
			<?php echo "Pliki w koszu: ";
			echo " (plików: " . ilePlikow(BACKUPDIRECTORY) . ")";
			?>
			
			</td>
			<td><a href="cantori/loadFile/delateFile.php?usunT=backup" onclick="return confirm('Czy na pewno chcesz usunąć ten plik?');" class="kkFile" title="usuń">usuń</a></td>
			<td>
			<?php displayFileOrFolderTimes(BACKUPDIRECTORY); ?>
			
			</td>
			
			</tr>
			
			<tr>
				<td>


			<?php 
			echo "Wygeneruj plik: "; 
			echo "(plików: " . ilePlikow(DOWNLOADFILE) . ")";
			?>
			
			
			</td>
			<td><a href="cantori/loadFile/delateFile.php?usunT=downloadFile" onclick="return confirm('Czy na pewno chcesz usunąć ten plik?');" class="kkFile" title="usuń">usuń</a></td>
			<td>
			<?php displayFileOrFolderTimes(DOWNLOADFILE); ?>
			</td>
			
			</tr>
			
			<tr>
				<td>
			<?php echo "Backup - poprzedni rok: ";
			echo "(plików: " . ilePlikow(LAST_YEAR) . ")";
			?>
			
			</td>
			<td><a href="cantori/loadFile/delateFile.php?usunT=lastYear" onclick="return confirm('Czy na pewno chcesz usunąć ten plik?');" class="kkFile" title="usuń">usuń</a></td>
			<td>
			<?php displayFileOrFolderTimes(LAST_YEAR); ?>
			</td>
			
			</tr>
			
			<tr>
				<td>
				Czyszczenie statystyk: 
				

					</td>
			<td>
			<a href="cantori/loadFile/delateFile.php?usunT=apocalypse" onclick="return confirm('Czy na pewno chcesz usunąć ten plik?');" class="kkFile" title="usuń">usuń</a>
			</td>
			
			</tr>
				
			</tbody>
			</table>
						
			
			</div>
			
	
	


