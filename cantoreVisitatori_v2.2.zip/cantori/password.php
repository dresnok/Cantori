<?php
define('HASHED_PASSWORD', '$2y$10$0cCTazuxxbU/FmrJ8dzDQutHRHN8NDlK2RWJop1od12dv/6/ousSm');
define('USER_ID', 'amin');