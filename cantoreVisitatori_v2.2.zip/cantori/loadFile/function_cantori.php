<?php
function updateVisitorList($filePath) {
    // Pobranie adresu IP klienta
    $userIp = $_SERVER['REMOTE_ADDR'];

    // Odczytaj istniejącą zawartość pliku lub inicjalizuj pustą tablicę
    $visitors = file_exists($filePath) ? unserialize(file_get_contents($filePath)) : [];

    // Dodaj nowy adres IP, jeśli go nie ma w tablicy
    if (!in_array($userIp, $visitors)) {
        $visitors[] = $userIp;
        
        // Zapisz zaktualizowaną tablicę z powrotem do pliku
        file_put_contents($filePath, serialize($visitors));
    }
}


function logVisitorData($filePath) {
    // Pobranie aktualnej daty i godziny
    $time = date("Y-m-d H:i:s");

    // Pobranie adresu URL
    $url = $_SERVER['REQUEST_URI'];

    // Pobranie adresu IP serwera
    $serverIp = $_SERVER['SERVER_ADDR'];

    // Pobranie adresu IP klienta
    $userIp = $_SERVER['REMOTE_ADDR'];

    // Lista przeglądarek
    $browsers = [
        'Chrome' => 'Google Chrome',
        'Firefox' => 'Mozilla Firefox',
        'Safari' => 'Safari',
        'MSIE' => 'Internet Explorer',
        'Trident' => 'Internet Explorer',
        'Edge' => 'Microsoft Edge'
    ];

    // Lista systemów operacyjnych
    $osList = [
        'Windows NT 10.0' => 'Windows 10',
        'Windows NT 6.3' => 'Windows 8.1',
        'Windows NT 6.2' => 'Windows 8',
        'Windows NT 6.1' => 'Windows 7',
        'Macintosh' => 'Mac OS',
        'Linux' => 'Linux',
        'Android' => 'Android',
        'iPhone' => 'iOS',
        'iPad' => 'iOS'
    ];

    $userAgent = $_SERVER['HTTP_USER_AGENT'];

    // Określenie przeglądarki
    $browser = 'Inna przeglądarka';
    foreach ($browsers as $key => $value) {
        if (strpos($userAgent, $key) !== false) {
            $browser = $value;
            break;
        }
    }

    // Określenie systemu operacyjnego
    $os = 'Inny system operacyjny';
    foreach ($osList as $key => $value) {
        if (strpos($userAgent, $key) !== false) {
            $os = $value;
            break;
        }
    }

    // Złożenie danych w jeden ciąg znaków
    $logEntry = $url . "|" . $browser . "|" . $os . "|" . $time . "|" . $userIp . "|" . $serverIp . PHP_EOL;

    // Zapisanie danych do pliku logu
    file_put_contents($filePath, $logEntry, FILE_APPEND);
}


function checkNewYear() {
    $currentYear = date('Y');
    $lastYear = $currentYear - 1;
    $lastYearFile = 'cantori/last_year/visits_' . $lastYear . '.php';
    $lastYearFile1 = 'cantori/last_year/susip_' . $lastYear . '.php';

    // Sprawdzenie, czy data to 22 sierpnia i czy backup już istnieje
    if (date('m-d') !== '01-01' || file_exists($lastYearFile)) {
        return;
    }

    // Kopiowanie pliku VISITS_FILE
    if (file_exists(VISITS_FILE)) {
		
	

        if (copy(VISITS_FILE, $lastYearFile)) {
            $newFile[] = "Plik 'visits' został skopiowany: " . $lastYearFile;
        } else {
            $newFile[] = "Backup z ostatniego roku dla 'visits' nie powiódł się.";
        }
    } else {
        $newFile[] = "Plik 'visits' nie istnieje.";
    }

}

function resetCountersIfNeeded() {
    // Ustawienie domyślnych wartości zmiennych sesji
    $_SESSION['unique_visits_day'] = NA_DZIEN;
    $_SESSION['unique_visits_week'] = NA_TYDZIEN;
    $_SESSION['unique_visits_month'] = NA_MIESIAC;
    $_SESSION['monthly_visits'] = array(
        'STYCZEN' => STYCZEN,
        'LUTY' => LUTY,
        'MARZEC' => MARZEC,
        'KWIECIEN' => KWIECIEN,
        'MAJ' => MAJ,
        'CZERWIEC' => CZERWIEC,
        'LIPIEC' => LIPIEC,
        'SIERPIEN' => SIERPIEN,
        'WRZESIEN' => WRZESIEN,
        'PAZDZIERNIK' => PAZDZIERNIK,
        'LISTOPAD' => LISTOPAD,
        'GRUDZIEN' => GRUDZIEN,
    );
    

  session_start();

// Ścieżka do pliku z datą ostatniego resetu
$resetFile = RESET_DATE;

// Odczyt daty ostatniego resetu z pliku, jeśli plik istnieje
$resetDate = file_exists($resetFile) ? file_get_contents($resetFile) : 0;
$resetDate = $resetDate ? strtotime($resetDate) : 0;
$currentDate = time(); // Aktualna data

// Sprawdzenie, czy minął tydzień
if ($resetDate == 0 || date('W', $resetDate) != date('W', $currentDate)) {
    // Resetowanie licznika tygodniowego
    $_SESSION['unique_visits_week'] = 0;
    // Aktualizacja pliku z datą resetu
    file_put_contents($resetFile, date('Y-m-d H:i:s', $currentDate));
}

// Sprawdzenie, czy minął miesiąc
if ($resetDate == 0 || date('Y-m', $resetDate) != date('Y-m', $currentDate)) {
    // Resetowanie licznika miesięcznego
    $_SESSION['unique_visits_month'] = 0;
    // Aktualizacja pliku z datą resetu
    file_put_contents($resetFile, date('Y-m-d H:i:s', $currentDate));
}

}




function countUniqueVisit() {
    resetCountersIfNeeded();

    $file_path = VISITORS_UNIK;

if (!file_exists($file_path)) {
    $newVisitorContent = "<?php\n";
    $newVisitorContent .= "define('VISITORS_UNIK_IP', 0);\n";
    $newVisitorContent .= "?>";

    file_put_contents(VISITORS_UNIK, $newVisitorContent);
}

// Dołączanie pliku, jeśli został utworzony lub już istniał
include($file_path);

    // Zwiększ licznik unikalnych odwiedzających
    $currentVisitorsCount = VISITORS_UNIK_IP;
    $newVisitorsCount = $currentVisitorsCount + 1;

    // Zapisanie nowej wartości VISITORS_UNIK_IP w pliku newVisitors.php
    $newVisitorContent = "<?php\n";
    $newVisitorContent .= "define('VISITORS_UNIK_IP', $newVisitorsCount);\n";
    $newVisitorContent .= "?>";

    file_put_contents(VISITORS_UNIK, $newVisitorContent);

    

    // Rejestracja odwiedzin
    logVisitorData(SUSIP_FILE);
    updateVisitorList(VISITORS_FILE);

    $_SESSION['unique_visits_day'] += 1;
    $_SESSION['unique_visits_week'] += 1;
    $_SESSION['unique_visits_month'] += 1;

    $englishToPolishMonths = [
        'January' => 'STYCZEN',
        'February' => 'LUTY',
        'March' => 'MARZEC',
        'April' => 'KWIECIEN',
        'May' => 'MAJ',
        'June' => 'CZERWIEC',
        'July' => 'LIPIEC',
        'August' => 'SIERPIEN',
        'September' => 'WRZESIEN',
        'October' => 'PAZDZIERNIK',
        'November' => 'LISTOPAD',
        'December' => 'GRUDZIEN',
    ];
    $currentMonth = strtoupper($englishToPolishMonths[date('F')]);

    $_SESSION['monthly_visits'][$currentMonth] += 1;

    setcookie('unique_visit', '1', time() + (86400), "/"); // 86400 sekund = 1 dzień

    saveVisitCounts(
        $_SESSION['unique_visits_day'],
        $_SESSION['unique_visits_week'],
        $_SESSION['unique_visits_month'],
        $_SESSION['monthly_visits'],
        
    );
}







function checkIpExists($userIp, $filePath = IPEX) {
    $file = fopen($filePath, 'r');
    if ($file) {
        while (($line = fgets($file)) !== false) {
            $line = trim($line); // Usunięcie dodatkowych białych znaków
            
            if ($line === $userIp) {
                fclose($file);
                return true; // IP zostało znalezione
            }
        }
        fclose($file);
    }
    return false; // IP nie zostało znalezione
}


// Funkcja do uruchomienia na początku skryptu
function startTimer() {
    global $startTime;
    $startTime = microtime(true);
}

// Funkcja do uruchomienia na końcu skryptu
function endTimer() {
    global $startTime;
    $endTime = microtime(true);
    $loadTime = ($endTime - $startTime) * 1000; // Przekształcenie na milisekundy

    // Zapisanie czasu ładowania strony do pliku
    $updatedLoadTimes = updateLoadTimes($loadTime);

    // Obliczenie średniego czasu ładowania
    $averageLoadTime = array_sum($updatedLoadTimes) / count($updatedLoadTimes);

    return [
        'currentLoadTime' => number_format($loadTime, 2),
        'averageLoadTime' => number_format($averageLoadTime, 2)
    ];
	
}





// Funkcja do aktualizacji czasów ładowania
function updateLoadTimes($newLoadTime) {
    $loadTimes = [];

    // Sprawdź, czy plik istnieje przed próbą jego załadowania
    if (defined('LOAD_TIMES')) {
        $loadTimes = LOAD_TIMES;
    }

    if (count($loadTimes) >= 5) {
        array_shift($loadTimes); // Usuń najstarszy wpis, jeśli mamy już 5
    }
    $loadTimes[] = number_format($newLoadTime, 2); // Precyzja do 2 miejsc po przecinku

    // Zapisanie nowych czasów do pliku visits.php
    $data = "<?php\n";
    $data .= "const LOAD_TIMES = " . var_export($loadTimes, true) . ";\n";
    $data .= "?>";

    // Próba zapisu do pliku
    file_put_contents(VISITS_FILE_S, $data);

    return $loadTimes;
}