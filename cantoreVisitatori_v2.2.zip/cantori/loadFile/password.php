<?php
define('HASHED_PASSWORD', '$2y$10$A4vpSizKCytmESI3gkcBqewVDltDnN1wkKJiF6/tMSkfNOGqvzNp.');
define('USER_ID', 'amin');