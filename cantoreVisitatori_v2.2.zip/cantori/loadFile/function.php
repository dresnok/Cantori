<?php
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

function test_input($data) {
    $data = trim($data);
    $data = stripslashes($data);
    $data = htmlspecialchars($data);
    return $data;
}


if(!file_exists(VISITS_FILE)){

	justTo(VISITS_FILE);
	
	}else {
    include VISITS_FILE;
}

if (file_exists(VISITS_FILE)) {

    $_SESSION['unique_visits_day'] = NA_DZIEN;
    $_SESSION['unique_visits_week'] = NA_TYDZIEN;
    $_SESSION['unique_visits_month'] = NA_MIESIAC;
	
	
	// Utworzenie tablicy z miesięcznymi wizytami
    $_SESSION['monthly_visits'] = [
        'STYCZEN' => STYCZEN,
        'LUTY' => LUTY,
        'MARZEC' => MARZEC,
        'KWIECIEN' => KWIECIEN,
        'MAJ' => MAJ,
        'CZERWIEC' => CZERWIEC,
        'LIPIEC' => LIPIEC,
        'SIERPIEN' => SIERPIEN,
        'WRZESIEN' => WRZESIEN,
        'PAZDZIERNIK' => PAZDZIERNIK,
        'LISTOPAD' => LISTOPAD,
        'GRUDZIEN' => GRUDZIEN
    ];
} else {
    
    $newFile [] = "Plik (cantori/visits.php) nie istnieje. ";
}

function timeSinceFileCreation($filePath) {
    if (file_exists($filePath)) {
        // Pobranie czasu ostatniej modyfikacji pliku (substytut czasu utworzenia)
        $fileCreationTime = filemtime($filePath);
        
        // Tworzenie obiektu DateTime z czasu ostatniej modyfikacji
        $fileCreationDate = new DateTime();
        $fileCreationDate->setTimestamp($fileCreationTime);
        
        // Pobieranie obecnej daty i czasu
        $currentDate = new DateTime();
        
        // Obliczanie różnicy między datami
        $interval = $currentDate->diff($fileCreationDate);
        
        // Zwracanie liczby dni, godzin i minut
         return $interval->days;
		/* return [
            'days' => $interval->days,
            'hours' => $interval->h,
            'minutes' => $interval->i
        ]; */
    }
}


		// Definicja funkcji deleteFile
function deleteFile($filePath) {
    if(file_exists($filePath)){
        unlink($filePath);
    }
}

function displayFilePaths($directory) {
    $iterator = new DirectoryIterator($directory);
    foreach ($iterator as $file) {
        if ($file->isFile()) {
            $filePath = $directory . '/' . $file->getFilename();
            $fileInfo = getimagesize($filePath);
            if ($fileInfo && in_array($fileInfo['mime'], IMAGE_TYPES)) {
                echo $filePath . PHP_EOL;
            }
        }
    }
}


// sendemail_file




// Odczytanie wszystkich zapisanych danych z pliku logu
$logData = file_exists(SUSIP_FILE) ? file(SUSIP_FILE, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES) : [];

// Tablice do zliczania poszczególnych wartości
$urlCounts = [];
$browserCounts = [];
$osCounts = [];
$userIpCounts = [];
$serverIpCounts = [];

// Przetworzenie każdego wpisu w pliku logu
foreach ($logData as $entry) {
    $parts = explode('|', $entry);
    
    // Sprawdzenie, czy liczba elementów jest odpowiednia
    if (count($parts) === 6) {
        list($entryUrl, $entryBrowser, $entryOs, $entryTime, $entryUserIp, $entryServerIp) = $parts;
    } else {
        // Pominięcie niekompletnego wpisu
	$_SESSION['newError'] = 'Wystąpił niekompletny wpis.' . $entry;
	
    continue;
    
	}

    // Zliczanie URLi
    if (!isset($urlCounts[$entryUrl])) {
        $urlCounts[$entryUrl] = 0;
    }
    $urlCounts[$entryUrl]++;

    // Zliczanie przeglądarek
    if (!isset($browserCounts[$entryBrowser])) {
        $browserCounts[$entryBrowser] = 0;
    }
    $browserCounts[$entryBrowser]++;

    // Zliczanie systemów operacyjnych
    if (!isset($osCounts[$entryOs])) {
        $osCounts[$entryOs] = 0;
    }
    $osCounts[$entryOs]++;

    // Zliczanie adresów IP użytkowników
    if (!isset($userIpCounts[$entryUserIp])) {
        $userIpCounts[$entryUserIp] = 0;
    }
    $userIpCounts[$entryUserIp]++;

    // Zliczanie adresów IP serwera
    if (!isset($serverIpCounts[$entryServerIp])) {
        $serverIpCounts[$entryServerIp] = 0;
    }
    $serverIpCounts[$entryServerIp]++;
}






?>



