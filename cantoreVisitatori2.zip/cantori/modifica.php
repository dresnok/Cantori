<?php


if (!defined('ERROR_FILE')) {
define('ERROR_FILE', 'errorFile.log');
}
if (!defined('SUSIP_FILE')) {
define('SUSIP_FILE', 'cantori/susip.txt');
}
if (!defined('VISITS_FILE')) {
define('VISITS_FILE', 'cantori/visits.php');
}
if (!defined('VISITORS_FILE')) {
define('VISITORS_FILE', 'cantori/visitors.txt');
}
if (!defined('VISITS_FILE_S')) {
define('VISITS_FILE_S', 'cantori/visits2.php');
}
if (!defined('SFONDO')) {
define('SFONDO', 'cantori/dodatki/sfondo.php');
}
if (!defined('INFO_FILE')) {
define('INFO_FILE', 'info.php');
}
if (!defined('IPEX')) {
    define('IPEX', 'cantori/ipEx.txt');
}

#last_word
if (!defined('FUNCTIONE')) {
define('FUNCTIONE', 'cantori/loadFile/function.php');
}
if (!defined('PASSWORD_T')) {
define('PASSWORD_T', 'cantori/password.php');
}
if (!defined('SENDEMAIL')) {
define('SENDEMAIL', 'cantori/loadFile/SendEmail.php');
}
if (!defined('MODIFICA')) {
define('MODIFICA', 'cantori/modifica.php');
}
if (!defined('VISITORS_UNIK')) {
define('VISITORS_UNIK', 'cantori/newVisitors.php');
}


#sfondo

if (!defined('TARGETDIRECTORY')) {
    define('TARGETDIRECTORY', 'cantori/dorme');
}

if (!defined('BACKUPDIRECTORY')) {
    define('BACKUPDIRECTORY', 'cantori/backup');
}

if (!defined('TEMPLATEONE')) {
    define('TEMPLATEONE', 'cantori/dodatki/templateone.webp');
}

if (!defined('TEMPLATETWO')) {
    define('TEMPLATETWO', 'cantori/dodatki/templatetwo.webp');
}

if (!defined('IMAGE_TYPES')) {
define('IMAGE_TYPES', ['image/jpeg', 'image/png', 'image/gif', 'image/bmp', 'image/webp']);
}

if (!defined('IMAGE_TYPES')) {
define('IMAGE_TYPES', ['image/jpeg', 'image/png', 'image/gif', 'image/bmp', 'image/webp']);
}