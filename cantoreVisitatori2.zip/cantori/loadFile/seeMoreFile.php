<?php
session_start();
date_default_timezone_set('Europe/Warsaw');

define('SUSIP_FILE', '../susip.txt');
define('VISITS_FILE', '../visits.php');
define('VISITORS_FILE', '../visitors.txt');
define('VISITORS_UNIK', '../newVisitors.php');

include_once 'vistits_file.php';


$dir_info = "../../info.php";

	$backupDir = '..' . DIRECTORY_SEPARATOR . 'backup' . DIRECTORY_SEPARATOR;
	// Sprawdź, czy katalog istnieje
	if (!is_dir($backupDir)) {
	mkdir($backupDir, 0777, true);
	}


if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['SeeMoreFile'])) {

    if (isset($_POST['raport_all'])) {
		
        $action = $_POST['action'] ?? '';

        switch ($action) {
            case 'susipBackup':
			

$backupFilename = $backupDir . 'susip_backup_' . date('Ymd_His') . '.txt';
	

	// Sprawdź, czy plik z danymi istnieje i wykonaj backup
	if (file_exists(SUSIP_FILE)) {
		$backupData = file_get_contents(SUSIP_FILE);
		file_put_contents($backupFilename, $backupData);
		$_SESSION['newInfo'] = "Wykonałem backup pliku: " . $backupFilename;
	} else {
		$_SESSION['newError'] = "Plik " . SUSIP_FILE . " nie istnieje, backup nie został wykonany.";
	}
                header("Location: $dir_info");
				exit;
                break;
				
             
            case 'susipReset':
			
			$backupFilename = $backupDir . 'susip_file_' . date('Ymd_His') . '.txt';
	// Sprawdź, czy plik z danymi istnieje i wykonaj backup
	if (file_exists(SUSIP_FILE)) {
		$backupData = file_get_contents(SUSIP_FILE);
		file_put_contents($backupFilename, $backupData);
	}
	
                if (file_exists(SUSIP_FILE)) {
                    unlink(SUSIP_FILE);
                    $_SESSION['newInfo'] = 'Akcja resetowania przeprowadzona pomyślnie.';
                } else {
                    $_SESSION['newInfo'] = 'Nie znaleziono pliku.';
					}
					
					

		
                 header("Location: $dir_info");
				exit;
                break;
        }
    }

    if (isset($_POST['reset_all'])) {
        $action = $_POST['action'] ?? '';

        switch ($action) {
            case 'submit_statysty':
			
  $months = ['STYCZEN', 'LUTY', 'MARZEC', 'KWIECIEN', 'MAJ', 'CZERWIEC', 'LIPIEC', 'SIERPIEN', 'WRZESIEN', 'PAZDZIERNIK', 'LISTOPAD', 'GRUDZIEN'];

    // Mapowanie miesięcy z angielskiego na polski
    $monthMap = ['JANUARY' => 'STYCZEN', 'FEBRUARY' => 'LUTY', 'MARCH' => 'MARZEC', 'APRIL' => 'KWIECIEN', 'MAY' => 'MAJ', 'JUNE' => 'CZERWIEC', 'JULY' => 'LIPIEC', 'AUGUST' => 'SIERPIEN', 'SEPTEMBER' => 'WRZESIEN', 'OCTOBER' => 'PAZDZIERNIK', 'NOVEMBER' => 'LISTOPAD', 'DECEMBER' => 'GRUDZIEN'];

    // Aktualny miesiąc
    $currentMonth = $monthMap[strtoupper(date('F'))];

    $totalVisits = 0;

    // Obsługa indywidualnych zapisów dla każdego miesiąca
    foreach ($months as $month) {
        if (isset($_POST['submit_' . $month])) {
            $newVisits = (int)$_POST['visits_' . $month];
            $visitDifference = $newVisits - ($_SESSION['monthly_visits'][$month] ?? 0);
            $_SESSION['monthly_visits'][$month] = max($newVisits, 0);

            if ($month === $currentMonth) {
                $_SESSION['unique_visits_day'] = max($_SESSION['unique_visits_day'] + $visitDifference, 0);
                $_SESSION['unique_visits_week'] = max($_SESSION['unique_visits_week'] + $visitDifference, 0);
                $_SESSION['unique_visits_month'] = $_SESSION['monthly_visits'][$month];
            }

            saveVisitCounts($_SESSION['unique_visits_day'], $_SESSION['unique_visits_week'], $_SESSION['unique_visits_month'], $_SESSION['monthly_visits']);
            $_SESSION['newInfo'] = "Zapisano pomyślnie dane dla miesiąca: $month.";
            
  
        }
    }
	
	 // Zapisanie wszystkich miesięcy
                foreach ($months as $month) {
                    if (isset($_POST['visits_' . $month])) {
                        $newVisits = (int)$_POST['visits_' . $month];
                        $_SESSION['monthly_visits'][$month] = max($newVisits, 0);
                        $totalVisits += $newVisits;
                    }
                }
                
                saveVisitCounts($_SESSION['unique_visits_day'], $_SESSION['unique_visits_week'], $_SESSION['unique_visits_month'], $_SESSION['monthly_visits']);
                
				
		
				

                header("Location: $dir_info#st_od");
				exit;
                break;

            case 'reset_statysty':


$backupFilename = $backupDir . 'visits_backup_' . date('Ymd_His') . '.txt';

	

	// Sprawdź, czy plik z danymi istnieje i wykonaj backup
	if (file_exists(VISITS_FILE)) {
		$backupData = file_get_contents(VISITS_FILE);
		file_put_contents($backupFilename, $backupData);
		}
		
	if (file_exists(VISITS_FILE)) {
		unlink(VISITS_FILE);
		
		$_SESSION['newInfo'] = 'Akcja resetowania przeprowadzona pomyślnie.';
		} else {
			
		
		$_SESSION['newInfo'] = 'Nie znaleziono pliku.';
		}
				
           
                 header("Location: $dir_info");
				exit;
                break;

            case 'statystyka_backup':

$backupFilename = $backupDir . 'visits_backup_' . date('Ymd_His') . '.txt';
	

	// Sprawdź, czy plik z danymi istnieje i wykonaj backup
	if (file_exists(VISITS_FILE)) {
		$backupData = file_get_contents(VISITS_FILE);
		file_put_contents($backupFilename, $backupData);
		
		$_SESSION['newInfo'] = "Wykonałem backup pliku: " . $backupFilename;
	} else {
		$_SESSION['newError'] = "Plik " . VISITS_FILE . " nie istnieje, backup nie został wykonany.";
	}
                header("Location: $dir_info");
				exit;
                break;
 
        }
    }

    if (isset($_POST['res_uip'])) {
        $action = $_POST['action'] ?? '';

        switch ($action) {
            case 'visitorsReset':
			
						
$backupFilename = $backupDir . 'visitors_unik_' . date('Ymd_His') . '.txt';
if (file_exists(VISITORS_UNIK)) {
		$backupData = file_get_contents(VISITORS_UNIK);
		file_put_contents($backupFilename, $backupData);
	}
	$backupFilename = $backupDir . 'visitors_file_' . date('Ymd_His') . '.txt';
if (file_exists(VISITORS_FILE)) {
		$backupData = file_get_contents(VISITORS_FILE);
		file_put_contents($backupFilename, $backupData);
	}	
	
				if (file_exists(VISITORS_FILE)) {
		unlink(VISITORS_FILE);
		

		$_SESSION['newInfo'] = 'Usunięto jeden plik.('. VISITORS_FILE .')';
		} else {
		
		$_SESSION['newInfo'] = 'Nie znaleziono pliku. ('. VISITORS_FILE .')';
		}
if (file_exists(VISITORS_UNIK)) {
unlink(VISITORS_UNIK);
$_SESSION['newInfo'] = 'Usunięto jeden plik.('. VISITORS_UNIK .')';
		} else {
		
		$_SESSION['newInfo'] = 'Nie znaleziono pliku. ('. VISITORS_UNIK .')';
		}

                

			
                $_SESSION['newInfo'] = "Akcja resetowania przeprowadzona pomyślnie (cantori/visitors.txt).";
                
                header("Location: $dir_info");
				exit;
                break;

            case 'visitorsBackup':

$backupFilename = $backupDir . 'visitors_backup_' . date('Ymd_His') . '.txt';


	// Sprawdź, czy plik z danymi istnieje i wykonaj backup
	if (file_exists(VISITORS_FILE)) {
		$backupData = file_get_contents(VISITORS_FILE);
		file_put_contents($backupFilename, $backupData);
		$_SESSION['newInfo'] = "Wykonałem backup pliku: " . $backupFilename;
	} else {
		$_SESSION['newError'] = "Plik " . VISITORS_FILE . " nie istnieje, backup nie został wykonany.";
	}
                header("Location: $dir_info");
				exit;
                break;
				
				  default:
        // Kod domyślny
        header("Location: $dir_info");
        exit;
        break;
		

        }
    }
}
}