<?php
session_start();
include 'password.php';

if (!defined('ERROR_FILE')) {
    define('ERROR_FILE', './../errorFile.log');
}

if (isset($_GET['logout']) && $_GET['logout'] == 'success') {
    echo "Logout successful!";
    $errors[] = "Wylogowanie: użytkownik";
}

if (($_SERVER['REQUEST_METHOD'] == 'POST') && !isset($_POST['logout'])) {
    $password = $_POST['password'];

    if (password_verify($password, HASHED_PASSWORD)) {
        // Regeneracja ID sesji po udanym logowaniu
        session_regenerate_id(true);

        // Ustawienie sesji użytkownika
        $_SESSION['user_id'] = USER_ID;

        $errors[] = "Logowanie: użytkownik";

        // Przekierowanie po zalogowaniu
        header('Location: ./../info.php');
        exit;
    } else {
        echo "Invalid password!";
        $errors[] = "Logowanie: Invalid password!";
    }
} elseif (isset($_POST['logout'])) {
    session_destroy();
    header('Location: ./login.php?logout=success');
    exit;
}

if (!empty($errors)) {
    $errorData = "Data błędu: " . date('Y-m-d H:i:s') . "\n";
    $errorData .= "Lista błędów:\n";
    foreach ($errors as $error) {
        $errorData .= $error . "\n";
    }
    $errorData .= "\n";
    file_put_contents(ERROR_FILE, $errorData, FILE_APPEND);
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Login</title>
</head>
<body>
    <form method="post" action="login.php">
        <label for="password">Password:</label>
        <input type="password" id="password" name="password" autofocus>
        <input type="submit" value="Login">
    </form>
</body>
</html>