<?php
//Zmień tło

function moveFileToBackup($directory) {
    $allowedExtensions = ['jpg', 'jpeg', 'png', 'webp', 'tiff'];
    global $error_file, $errors;

    $iterator = new DirectoryIterator($directory);
    $fileFound = false;

    foreach ($iterator as $file) {
        if ($file->isFile()) {
            $extension = strtolower(pathinfo($file->getFilename(), PATHINFO_EXTENSION));
            if (in_array($extension, $allowedExtensions)) {
                $fileFound = true;
                $backupPath = BACKUPDIRECTORY . DIRECTORY_SEPARATOR . $file->getFilename();
                if (!file_exists(BACKUPDIRECTORY)) {
                    mkdir(BACKUPDIRECTORY, 0777, true);
                }
                rename($file->getRealPath(), $backupPath);
                return;
            }
        }
    }

    if (!$fileFound) {
        
        $newInfo[] = 'Plik nie istnieje.';
    }
}

function is_image($file_path) {
    $file_info = getimagesize($file_path);
    return $file_info && in_array($file_info['mime'], IMAGE_TYPES);
}

function clear_directory($directory) {
    $iterator = new DirectoryIterator($directory);
    foreach ($iterator as $file) {
        if (!$file->isDot() && $file->isFile()) {
            unlink($file->getPathname());
        }
    }
}

function copy_image($source_file, $target_dir) {
    $error_file = [];
    $errors = [];

    if (!is_file($source_file)) {
         
        $newInfo[] = "Plik nie jest zdjęciem lub nie istnieje (Zmień tło): $source_file";
        return;
    }
    if (!is_dir($target_dir)) {
		 $newInfo[] = "Katalog nie istnieje (Zmień tło): $target_dir";
        
        
        return;
    }

    // Clear the target directory
    clear_directory($target_dir);

    if (is_image($source_file)) {
        $file_name = basename($source_file);
        $target_file = $target_dir . DIRECTORY_SEPARATOR . $file_name;

        if (!copy($source_file, $target_file)) {
              $newInfo[] = "Nie skopiowałem pliku (Zmień tło):  $file_name.";
			
        } else {
             
            $newInfo[] = "Skopiowałem plik (Zmień tło): $file_name to $target_dir.";
        }
    } else {
        $newInfo[] = "Plik nie jest zdjęciem, (Zmień tło): $source_file";
        
    }


}
// Run the copy operation
if (isset($_POST['zmienTlo']) && $_POST['zmienTlo'] === "Template_one") {
    // Assuming TEMPLATEONE and TARGETDIRECTORY are defined
    if(copy_image(TEMPLATEONE, TARGETDIRECTORY)){
  $newInfo[] = 'Akcja przeprowadzona pomyślnie (Zmień tło). <a href="#operacje" title="Skrót">Operacje</a>';
        
    } else {
        // Error handling
		 $newInfo[] = 'Błąd: nie udało się skopiować obrazu. Możliwy brak pliku.';
        
    }
}

if (isset($_POST['zmienTlo']) && ($_POST['zmienTlo']) === "Template_two" ) {
    // Run the copy operation
    if (copy_image(TEMPLATETWO, TARGETDIRECTORY)) {
        $newInfo[] = 'Akcja przeprowadzona pomyślnie (Zmień tło). <a href="#operacje" title="Skrót">Operacje</a>';
        
    } else {
        // Error handling
		 $newInfo[] = 'Błąd: nie udało się skopiować obrazu. Możliwy brak pliku.';
        
    }
}



	
	if (isset($_POST['zmienTlo']) && ($_POST['zmienTlo']) === "moveOrDelateFile" ) {
    moveFileToBackup(TARGETDIRECTORY);

        $newInfo[] = 'Plik został przeniesiony do katalogu: ' . BACKUPDIRECTORY;
        
    
	
    }
	
	
if (isset($_POST['zmienTlo']) && $_POST['zmienTlo'] === "uploadFile") {

$targetFile = TARGETDIRECTORY . '/' . basename($_FILES["fileToUpload"]["name"]);
$uploadOk = 1;
$imageFileType = strtolower(pathinfo($targetFile, PATHINFO_EXTENSION));

// Check if image file is an actual image or fake image
if(isset($_POST["submit"])) {
    $check = getimagesize($_FILES["fileToUpload"]["tmp_name"]);
    if($check !== false) {
        $newInfo[] = "Plik jest obrazem - " . $check["mime"] . ".";
        $uploadOk = 1;
    } else {
        $newInfo[] = "Plik nie jest obrazem.";
        $uploadOk = 0;
    }
}

// Check if file already exists in the target directory
if (file_exists($targetFile)) {
    $newInfo[] = "Przepraszamy, plik już istnieje.";
    $uploadOk = 0;
}

// Check file size
if ($_FILES["fileToUpload"]["size"] > 5 * 1024 * 1024) { // 5MB limit
    $newInfo[] = "Przepraszamy, Twój plik jest za duży.";
    $uploadOk = 0;
}

// Allow certain file formats
if(!in_array($imageFileType, ['jpg', 'jpeg', 'png', 'webp', 'tiff'])) {
    $newInfo[] = "Przepraszamy, tylko pliki JPG, JPEG, PNG, WEBP & TIFF są dozwolone.";
    $uploadOk = 0;
}

// Check if $uploadOk is set to 0 by an error
if ($uploadOk == 0) {
    $newInfo[] = "Twój plik nie został przesłany.";
// if everything is ok, try to upload file
} else {
    // Move existing file to backup directory
    moveFileToBackup(TARGETDIRECTORY, BACKUPDIRECTORY);

    if (move_uploaded_file($_FILES["fileToUpload"]["tmp_name"], $targetFile)) {
        $newInfo[] = "Plik ". htmlspecialchars(basename($_FILES["fileToUpload"]["name"])) . " został przesłany.";
    } else {
        $newInfo[] = "Wystąpił błąd podczas przesyłania pliku.";
    }
}
}