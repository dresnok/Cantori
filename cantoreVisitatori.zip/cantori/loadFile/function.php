<?php

if (file_exists(VISITS_FILE)) {

    $_SESSION['unique_visits_day'] = NA_DZIEN;
    $_SESSION['unique_visits_week'] = NA_TYDZIEN;
    $_SESSION['unique_visits_month'] = NA_MIESIAC;
	$_SESSION['visitors_unik_ip'] = VISITORS_UNIK_IP;
	
	// Utworzenie tablicy z miesięcznymi wizytami
    $_SESSION['monthly_visits'] = [
        'STYCZEN' => STYCZEN,
        'LUTY' => LUTY,
        'MARZEC' => MARZEC,
        'KWIECIEN' => KWIECIEN,
        'MAJ' => MAJ,
        'CZERWIEC' => CZERWIEC,
        'LIPIEC' => LIPIEC,
        'SIERPIEN' => SIERPIEN,
        'WRZESIEN' => WRZESIEN,
        'PAZDZIERNIK' => PAZDZIERNIK,
        'LISTOPAD' => LISTOPAD,
        'GRUDZIEN' => GRUDZIEN
    ];
} else {
    
    $newFile [] = "Plik 'cantori/visits.php' nie istnieje. ";
}


function saveVisitCounts($dailyVisits, $weeklyVisits, $monthlyVisits, $monthlyData, $uniqueIpVisits) {
    $data = "<?php\n";
    $data .= "define('NA_DZIEN', $dailyVisits);\n";
    $data .= "define('NA_TYDZIEN', $weeklyVisits);\n";
    $data .= "define('NA_MIESIAC', $monthlyVisits);\n";
    $data .= "define('VISITORS_UNIK_IP', $uniqueIpVisits);\n";
    
    
    foreach ($monthlyData as $month => $count) {
        $data .= "define('$month', $count);\n";
    }
    
    $data .= "?>";
    
    file_put_contents(VISITS_FILE, $data);
}

// Funkcja resetująca wszystkie liczniki i zapisująca dane do pliku
function resetAllCounters() {
    // Zapisz obecne dane jako backup
    saveBackupData();
    // Zeruj liczniki
    $_SESSION['unique_visits_day'] = 0;
    $_SESSION['unique_visits_week'] = 0;
    $_SESSION['unique_visits_month'] = 0;
    $_SESSION['monthly_visits'] = array_fill_keys(['STYCZEN', 'LUTY', 'MARZEC', 'KWIECIEN', 'MAJ', 'CZERWIEC', 'LIPIEC', 'SIERPIEN', 'WRZESIEN', 'PAZDZIERNIK', 'LISTOPAD', 'GRUDZIEN'], 0);
	
    // Zapisz nowe dane z aktualną datą
    saveVisitCounts($_SESSION['unique_visits_day'], $_SESSION['unique_visits_week'], $_SESSION['unique_visits_month'], $_SESSION['monthly_visits'], $_SESSION['visitors_unik_ip']);
}

// Funkcja zapisująca obecne dane jako backup
function saveBackupData() {
    $backupFilename = 'cantori/backup/visits_backup_' . date('Ymd_His') . '.txt';
    $backupData = file_get_contents(VISITS_FILE);
    file_put_contents($backupFilename, $backupData);
}



// Funkcja do obliczania dni od utworzenia pliku
function daysSinceFileCreation($filePath) {
    if (file_exists($filePath)) {
        // Pobranie czasu utworzenia pliku
        $fileCreationTime = filectime($filePath);

        // Tworzenie obiektu DateTime z czasu utworzenia pliku
        $fileCreationDate = new DateTime();
        $fileCreationDate->setTimestamp($fileCreationTime);

        // Pobieranie obecnej daty i czasu
        $currentDate = new DateTime();

        // Obliczanie różnicy między datami
        $interval = $currentDate->diff($fileCreationDate);

        // Zwracanie liczby dni
        return $interval->days;
    } else {
		
		$newInfo[] = "Plik nie istnieje.";
        
    }
}

		// Definicja funkcji deleteFile
function deleteFile($filePath) {
    if(file_exists($filePath)){
        unlink($filePath);
    }
}

function displayFilePaths($directory) {
    $iterator = new DirectoryIterator($directory);
    foreach ($iterator as $file) {
        if ($file->isFile()) {
            $filePath = $directory . '/' . $file->getFilename();
            $fileInfo = getimagesize($filePath);
            if ($fileInfo && in_array($fileInfo['mime'], IMAGE_TYPES)) {
                echo $filePath . PHP_EOL;
            }
        }
    }
}


