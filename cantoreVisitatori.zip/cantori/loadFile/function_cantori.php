<?php



// Funkcja do uruchomienia na początku skryptu
function startTimer() {
    global $startTime;
    $startTime = microtime(true);
}

// Funkcja do uruchomienia na końcu skryptu
function endTimer() {
    global $startTime;
    $endTime = microtime(true);
    $loadTime = ($endTime - $startTime) * 1000; // Przekształcenie na milisekundy

    // Zapisanie czasu ładowania strony do pliku
    $updatedLoadTimes = updateLoadTimes($loadTime);

    // Obliczenie średniego czasu ładowania
    $averageLoadTime = array_sum($updatedLoadTimes) / count($updatedLoadTimes);

    return [
        'currentLoadTime' => number_format($loadTime, 2),
        'averageLoadTime' => number_format($averageLoadTime, 2)
    ];
	
}





// Funkcja do aktualizacji czasów ładowania
function updateLoadTimes($newLoadTime) {
    $loadTimes = [];

    // Sprawdź, czy plik istnieje przed próbą jego załadowania
    if (defined('LOAD_TIMES')) {
        $loadTimes = LOAD_TIMES;
    }

    if (count($loadTimes) >= 5) {
        array_shift($loadTimes); // Usuń najstarszy wpis, jeśli mamy już 5
    }
    $loadTimes[] = number_format($newLoadTime, 2); // Precyzja do 2 miejsc po przecinku

    // Zapisanie nowych czasów do pliku visits.php
    $data = "<?php\n";
    $data .= "const LOAD_TIMES = " . var_export($loadTimes, true) . ";\n";
    $data .= "?>";

    // Próba zapisu do pliku
    file_put_contents(VISITS_FILE_S, $data);

    return $loadTimes;
}
