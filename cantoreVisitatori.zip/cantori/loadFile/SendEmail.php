<?php
function calculateAverageLoadTime($times) {
    if (empty($times)) {
        return 0; // Dla uproszczenia zakładam, że średni czas to 0, gdy brak danych
    }
    return array_sum($times) / count($times);
}

//IF(file_exists(VISITS_FILE_S)){
if (isset($LOAD_TIMES)) {
    if (function_exists('calculateAverageLoadTime')) {
        // Obliczenie średniego czasu ładowania
        $averageLoadTime = calculateAverageLoadTime($LOAD_TIMES);
        // Pobranie 5 ostatnich wpisów, jeśli istnieją
        $lastEntries = array_slice($LOAD_TIMES, -5);
    } else {
        $averageLoadTime = 0;
        $newInfo[] = "Wczytywanie wyników: błąd funkcji 'calculateAverageLoadTime'.";
    }
} else {
    // Przypadek, gdy zmienna $LOAD_TIMES nie istnieje
    $averageLoadTime = 0; // Dla uproszczenia zakładam, że średni czas to 0, gdy brak danych
    $lastEntries = []; // Ustawienie pustej tablicy dla ostatnich wpisów
}


// Odczytaj istniejącą zawartość pliku lub inicjalizuj pustą tablicę
$visitors = file_exists(VISITORS_FILE) ? unserialize(file_get_contents(VISITORS_FILE)) : [];

// Pobranie adresu IP użytkownika
$userIp = $_SERVER['REMOTE_ADDR'];

// Dodaj nowy adres IP, jeśli go nie ma w tablicy
if (!in_array($userIp, $visitors)) {
    $visitors[] = $userIp;
    // Zapisz zaktualizowaną tablicę z powrotem do pliku
    file_put_contents(VISITORS_FILE, serialize($visitors));

    // Zwiększ licznik unikalnych odwiedzających
    // Check if the file exists


 $fileContent = file_get_contents(VISITS_FILE);

    // Zwiększ licznik unikalnych odwiedzających
    $currentVisitorsCount = VISITORS_UNIK_IP;
    $newVisitorsCount = $currentVisitorsCount + 1;

    // Zaktualizuj wartość VISITORS_UNIK_IP w zawartości pliku
    $updatedContent = preg_replace(
        "/define\('VISITORS_UNIK_IP', \d+\);/",
        "define('VISITORS_UNIK_IP', $newVisitorsCount);",
        $fileContent
    );

    // Zapisz zaktualizowaną zawartość pliku
    file_put_contents(VISITS_FILE, $updatedContent);


}



// Odczytanie wszystkich zapisanych danych z pliku logu
$logData = file_exists(SUSIP_FILE) ? file(SUSIP_FILE, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES) : [];

// Tablice do zliczania poszczególnych wartości
$urlCounts = [];
$browserCounts = [];
$osCounts = [];
$userIpCounts = [];
$serverIpCounts = [];

// Przetworzenie każdego wpisu w pliku logu
foreach ($logData as $entry) {
    $parts = explode('|', $entry);
    
    // Sprawdzenie, czy liczba elementów jest odpowiednia
    if (count($parts) === 6) {
        list($entryUrl, $entryBrowser, $entryOs, $entryTime, $entryUserIp, $entryServerIp) = $parts;
    } else {
        // Pominięcie niekompletnego wpisu
	$newInfo[] = 'Wystąpił niekompletny wpis.' . $entry;
	
    continue;
    
	}

    // Zliczanie URLi
    if (!isset($urlCounts[$entryUrl])) {
        $urlCounts[$entryUrl] = 0;
    }
    $urlCounts[$entryUrl]++;

    // Zliczanie przeglądarek
    if (!isset($browserCounts[$entryBrowser])) {
        $browserCounts[$entryBrowser] = 0;
    }
    $browserCounts[$entryBrowser]++;

    // Zliczanie systemów operacyjnych
    if (!isset($osCounts[$entryOs])) {
        $osCounts[$entryOs] = 0;
    }
    $osCounts[$entryOs]++;

    // Zliczanie adresów IP użytkowników
    if (!isset($userIpCounts[$entryUserIp])) {
        $userIpCounts[$entryUserIp] = 0;
    }
    $userIpCounts[$entryUserIp]++;

    // Zliczanie adresów IP serwera
    if (!isset($serverIpCounts[$entryServerIp])) {
        $serverIpCounts[$entryServerIp] = 0;
    }
    $serverIpCounts[$entryServerIp]++;
}



$nowe = filter_input(INPUT_POST, 'nowe', FILTER_SANITIZE_SPECIAL_CHARS);
if ($nowe !== null) {
    $haslo = @filter_input(INPUT_POST, 'haslo', FILTER_SANITIZE_STRING); // Opcjonalnie można to dodać, ale nie jest to konieczne przy password_hash
    
    // Walidacja hasła
    if (!empty($haslo)) {
        $hash_hasla = password_hash($haslo, PASSWORD_DEFAULT);

        $newInfo[] = "Hasło wygenerowane pomyślnie (generator hasła).";
        
    }
}


?>



<?php
$months = ['STYCZEN', 'LUTY', 'MARZEC', 'KWIECIEN', 'MAJ', 'CZERWIEC', 'LIPIEC', 'SIERPIEN', 'WRZESIEN', 'PAZDZIERNIK', 'LISTOPAD', 'GRUDZIEN'];
$currentMonth = strtoupper(date('F')); // Aktualny miesiąc w języku angielskim
// Mapowanie miesięcy z angielskiego na polski
$monthMap = ['JANUARY' => 'STYCZEN', 'FEBRUARY' => 'LUTY', 'MARCH' => 'MARZEC', 'APRIL' => 'KWIECIEN', 'MAY' => 'MAJ', 'JUNE' => 'CZERWIEC', 'JULY' => 'LIPIEC', 'AUGUST' => 'SIERPIEN', 'SEPTEMBER' => 'WRZESIEN', 'OCTOBER' => 'PAZDZIERNIK', 'NOVEMBER' => 'LISTOPAD', 'DECEMBER' => 'GRUDZIEN'];
$currentMonth = $monthMap[$currentMonth];
if (isset($_POST['submit_all'])) {
	
	
    $totalVisits = 0;
    foreach ($months as $month) {
        if (isset($_POST['visits_' . $month])) {
            $newVisits = (int)$_POST['visits_' . $month];
            $_SESSION['monthly_visits'][$month] = max($newVisits, 0);
            $totalVisits+= $newVisits;
        }
    }
    $currentMonth = $monthMap[strtoupper(date('F')) ];
    $currentMonthVisits = $_SESSION['monthly_visits'][$currentMonth];
    $_SESSION['unique_visits_day'] = $currentMonthVisits;
    $_SESSION['unique_visits_week'] = $currentMonthVisits;
    $_SESSION['unique_visits_month'] = $totalVisits;
    saveVisitCounts($_SESSION['unique_visits_day'], $_SESSION['unique_visits_week'], $_SESSION['unique_visits_month'], $_SESSION['monthly_visits'], $_SESSION['visitors_unik_ip']);
	
	$newInfo [] = "Zapisano pomyślnie.";

}

foreach ($months as $month) {
    if (isset($_POST['submit_' . $month])) {
        $newVisits = (int)$_POST['visits_' . $month];
        $visitDifference = $newVisits - $_SESSION['monthly_visits'][$month];
        $_SESSION['monthly_visits'][$month] = max($newVisits, 0);
        if ($month == $currentMonth) {
            $_SESSION['unique_visits_day'] = max($_SESSION['unique_visits_day'] + $visitDifference, 0);
            $_SESSION['unique_visits_week'] = max($_SESSION['unique_visits_week'] + $visitDifference, 0);            //$_SESSION['unique_visits_month'] = max($_SESSION['unique_visits_month'] + $visitDifference, 0);
            $_SESSION['unique_visits_month'] = $_SESSION["monthly_visits"][$month];
        }
        saveVisitCounts($_SESSION['unique_visits_day'], $_SESSION['unique_visits_week'], $_SESSION['unique_visits_month'], $_SESSION['monthly_visits'], $_SESSION['visitors_unik_ip']);
		
		$newInfo [] = "Zapisano pomyślnie.";
 }
		}



?>

<?php

function sumSpecifiedFilesWeightInMegabytes($dir, $extensions) {
        $totalWeight = 0;
        $files = new RecursiveIteratorIterator(new RecursiveDirectoryIterator($dir));
        foreach ($files as $file) {
            if ($file->isFile()) {
                $extension = $file->getExtension();
                if (in_array($extension, $extensions)) {
                    $totalWeight += $file->getSize();
                }
            }
        }
        // Konwersja z bajtów na megabajty
        $totalWeightMegabytes = $totalWeight / (1024 * 1024);
        return $totalWeightMegabytes;
    }


if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['seeMore'])) {

include"cantori/loadFile/specyficFiles.php";

    // Funkcja do obliczania wagi plików w megabajtach
try {
    // Sprawdzenie, czy funkcja istnieje przed jej wywołaniem
    if (function_exists('sumSpecifiedFilesWeightInMegabytes')) {
        // Obliczenie wagi plików dla każdej kategorii
        $totalFolderWeightMegabytesText = sumSpecifiedFilesWeightInMegabytes($folderPath, SPECIFIED_EXTENSIONS_TEXT);
        $totalFolderWeightMegabytesImage = sumSpecifiedFilesWeightInMegabytes($folderPath, SPECIFIED_EXTENSIONS_IMAGE);
        $totalFolderWeightMegabytesAudio = sumSpecifiedFilesWeightInMegabytes($folderPath, SPECIFIED_EXTENSIONS_AUDIO);
        $totalFolderWeightMegabytesScripts = sumSpecifiedFilesWeightInMegabytes($folderPath, SPECIFIED_EXTENSIONS_SCRIPTS);
        $totalFolderWeightMegabytesArchiwe = sumSpecifiedFilesWeightInMegabytes($folderPath, SPECIFIED_EXTENSIONS_ARCHIWE);
        $totalFolderWeightMegabytesOther = sumSpecifiedFilesWeightInMegabytes($folderPath, SPECIFIED_EXTENSIONS_OTHER);

        // Formatowanie wyników do dwóch miejsc po przecinku
        $waga_pText = number_format($totalFolderWeightMegabytesText, 2);
        $waga_pImage = number_format($totalFolderWeightMegabytesImage, 2);
        $waga_pAudio = number_format($totalFolderWeightMegabytesAudio, 2);
        $waga_pScripts = number_format($totalFolderWeightMegabytesScripts, 2);
        $waga_pArchiwe = number_format($totalFolderWeightMegabytesArchiwe, 2);
        $waga_pOther = number_format($totalFolderWeightMegabytesOther, 2);
		
	$newInfo[] = "Dane wczytane poprawnie (Rozmiar projektu).";
    
    } else {
        // Jeśli funkcja nie istnieje, ustaw wartości na 0 i zapisz błąd
        $totalFolderWeightMegabytesText = 0;
        $totalFolderWeightMegabytesImage = 0;
        $totalFolderWeightMegabytesAudio = 0;
        $totalFolderWeightMegabytesScripts = 0;
        $totalFolderWeightMegabytesArchiwe = 0;
        $totalFolderWeightMegabytesOther = 0;

	$newInfo[] = "Wystąpił błąd: funkcja sumSpecifiedFilesWeightInMegabytes nie istnieje.";
    
	        
    }
} catch (Exception $e) {
    // Obsługa błędów sesji
    $totalFolderWeightMegabytesText = 0;
	
	$newInfo[] = 'Wystąpił błąd: podczas przetwarzania funcji sumSpecifiedFilesWeightInMegabytes: ' . $e->getMessage();
    
    
}

// Dalej kontynuuj wykonywanie skryptu

    try {
        // Zapisywanie wartości do sesji
        $_SESSION['waga_pText'] = $waga_pText;
        $_SESSION['waga_pImage'] = $waga_pImage;
        $_SESSION['waga_pAudio'] = $waga_pAudio;
        $_SESSION['waga_pScripts'] = $waga_pScripts;
        $_SESSION['waga_pArchiwe'] = $waga_pArchiwe;
        $_SESSION['waga_pOther'] = $waga_pOther;
    } catch (Exception $e) {
		
		
    // Obsługa błędów sesji
	$newInfo[] = 'Wystąpił błąd podczas przetwarzania danych sesji: ' . $e->getMessage();
    
    
}
}
?>

<?php
if (($_SERVER["REQUEST_METHOD"] == "POST") && isset($_POST['reset_all'])) {


$action = $_POST['action'] ?? '';


  switch ($action) {
        case 'submit_statysty':
            // Zapisz wszystkie zmiany dla miesięcy
            // Tutaj obsłuż zapisanie danych z $_POST
            break;
			
        case 'reset_statysty':
		
			resetAllCounters();
			$newInfo [] = 'Akcja resetowania przeprowadzona pomyślnie.';

            break;
			
			        case 'statystyka_backup':
	$backupFilename = 'cantori/backup/visits_backup_' . date('Ymd_His') . '.txt';
    $backupData = file_get_contents(VISITS_FILE);
    file_put_contents($backupFilename, $backupData);

$newInfo [] = "Wykonałem backup pliku: " . $backupFilename;
            break;
			

}
}

if (($_SERVER['REQUEST_METHOD'] === 'POST') && isset($_POST['SeeMoreFile'])) {

	

	$waga_pText = isset($_SESSION['waga_pText']) ? $_SESSION['waga_pText'] : null;
    $waga_pImage = isset($_SESSION['waga_pImage']) ? $_SESSION['waga_pImage'] : null;
    $waga_pAudio = isset($_SESSION['waga_pAudio']) ? $_SESSION['waga_pAudio'] : null;
    $waga_pScripts = isset($_SESSION['waga_pScripts']) ? $_SESSION['waga_pScripts'] : null;
    $waga_pArchiwe = isset($_SESSION['waga_pArchiwe']) ? $_SESSION['waga_pArchiwe'] : null;
    $waga_pOther = isset($_SESSION['waga_pOther']) ? $_SESSION['waga_pOther'] : null;


$message = '
    <html>
    <head>
        <title>Raport - Panel statystyk</title>
    </head>
    <body>
        <table border="1">
            <tr>
                <td>Pliki tekstowe: ' . $waga_pText . ' MB</td>
            </tr>
            <tr>
                <td>Pliki graficzne: ' . $waga_pImage . ' MB</td>
            </tr>
            <tr>
                <td>Pliki audio: ' . $waga_pAudio . ' MB</td>
            </tr>
            <tr>
                <td>Pliki skryptowe: ' . $waga_pScripts . ' MB</td>
            </tr>
            <tr>
                <td>Pliki archiwów: ' . $waga_pArchiwe . ' MB</td>
            </tr>
            <tr>
                <td>Inne pliki: ' . $waga_pOther . ' MB</td>
            </tr>
        </table>
		
		
    </body>
    </html>
    ';
	
if (($_SERVER["REQUEST_METHOD"] == "POST") && isset($_POST['res_uip'])) {
function resetStringAndData() {
    $filePath = VISITORS_FILE;
    if (file_exists($filePath)) {
        // Zamiast resetowania poszczególnych elementów, ustaw pustą tablicę
        $unserializedData = [];
        $serializedData = serialize($unserializedData);
        file_put_contents($filePath, $serializedData);
    }
}

    resetStringAndData();
    
	$newInfo[] = 'Akcja resetowania przeprowadzona pomyślnie (cantori/visitors.txt).';
    
}





if ( isset($_POST['wykluczenia'])){


   // Funkcja do walidacji adresu IP
    function isValidIP($ip) {
        return filter_var($ip, FILTER_VALIDATE_IP) !== false;
    }

    // Ścieżka do pliku
    $filePath = IPEX;

    // Sprawdzenie czy plik istnieje, jeśli nie to tworzenie pliku
    if (!file_exists($filePath)) {
        $fileDir = dirname($filePath);
        if (!is_dir($fileDir)) {
            mkdir($fileDir, 0777, true);
        }
        touch($filePath);
    }

    // Odczyt zawartości pliku do tablicy
    $existingIPs = file($filePath, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);

    // Funkcja do sprawdzenia, czy adres IP już istnieje w pliku
    function ipExists($ip, $existingIPs) {
        return in_array($ip, $existingIPs);
    }

    // Przetwarzanie checkboxów
    if (isset($_POST['address'])) {
        foreach ($_POST['address'] as $address) {
            if ($address === 'localhost' && !ipExists('localhost', $existingIPs)) {
                file_put_contents($filePath, "localhost\n", FILE_APPEND);
							$newInfo [] = "Dodano wykluczenie: $address (Wykluczenia IP).";
        
            } elseif ($address === 'moj_adres_ip') {
                $myIPAddress = $_SERVER['REMOTE_ADDR']; // Przykładowe aktualne IP
                if (!ipExists($myIPAddress, $existingIPs)) {
                    file_put_contents($filePath, "$myIPAddress\n", FILE_APPEND);
					$newInfo [] = "Dodano wykluczenie: $myIPAddress (Wykluczenia IP).";
        
                }
            }
        }
    }

    // Dodawanie wykluczenia
    if (!empty($_POST['dodaj_wykluczenie'])) {
        $dodaj_wykluczenie = $_POST['dodaj_wykluczenie'];
        if (isValidIP($dodaj_wykluczenie) && !ipExists($dodaj_wykluczenie, $existingIPs)) {
            file_put_contents($filePath, "$dodaj_wykluczenie\n", FILE_APPEND);
			$newInfo [] = "Dodano wykluczenie: $dodaj_wykluczenie (Wykluczenia IP).";
       
            
        } elseif (!isValidIP($dodaj_wykluczenie)) {
			$newInfo [] = "Nieprawidłowy adres IP do dodania. (Wykluczenia IP).";
       
            
        } else {
			$newInfo [] = "Adres IP już istnieje. (Wykluczenia IP).";
       
           
        }
    }

    // Usuwanie wykluczenia
    if (!empty($_POST['usun_wykluczenie'])) {
        $usun_wykluczenie = $_POST['usun_wykluczenie'];
        if (isValidIP($usun_wykluczenie)) {
            $fileContents = file_get_contents($filePath);
            $fileContents = str_replace("$usun_wykluczenie\n", '', $fileContents);
            file_put_contents($filePath, $fileContents);
			$newInfo [] = "Usunięto wykluczenie: $usun_wykluczenie (Wykluczenia IP).";
       
		
            
        } else {
		$newInfo [] = "Nieprawidłowy adres IP do usunięcia. (Wykluczenia IP).";
       

        }
    }

    // Usuwanie wszystkich wykluczeń
    if (isset($_POST['action']) && $_POST['action'] === 'usun_wszystkie_wykluczenia') {
        file_put_contents($filePath, '');
		$newInfo [] = "Usunięto wszystkie wykluczenia. (Wykluczenia IP).";
        
       
    }
}




if(isset($_POST['new_password'])) {


    $new_password = $_POST['new_password'];
    $confirm_password = $_POST['confirm_password'];

        // Sprawdź, czy nowe hasło i potwierdzenie są takie same
        if ($new_password === $confirm_password) {
            // Zhashuj nowe hasło
            $new_hashed_password = password_hash($new_password, PASSWORD_DEFAULT);

            // Zaktualizuj plik z hasłem, tylko zmieniając linię z hasłem
            $password_file_content = file('cantori/password.php');
            foreach ($password_file_content as &$line) {
                if (strpos($line, "define('HASHED_PASSWORD'") !== false) {
                    $line = "define('HASHED_PASSWORD', '" . $new_hashed_password . "');\n";
                    break;
                }
            }
            file_put_contents('cantori/password.php', implode('', $password_file_content));


			$newInfo[] = "Hasło zostało zmienione.";
		
				
            
        } else {
			 $newInfo [] = 'Nowe hasło i potwierdzenie nie są takie same.';

} 
}



	
if(isset($_POST['downloadFile'])) {

$directory = "cantori/downloadFile/";
if (!is_dir($directory)) {
    mkdir($directory, 0777, true);
}
// Generowanie unikatowej nazwy pliku
$unique_filename = uniqid('raport_', true) . '.html';
$file_path = "$directory/$unique_filename";

$file = fopen($file_path, "w");
if ($file) {
    
    fwrite($file, $message);
    fclose($file);

    // Opcjonalnie, przekierowanie do pobrania pliku
    header('Content-Type: application/octet-stream');
    header('Content-Disposition: attachment; filename="' . $unique_filename . '"');
    readfile($file_path);
	
	$newInfo [] = "Pobrałem plik: $unique_filename";

	}
	
	else {
	$newInfo [] = 'Pobranie pliku nie powidło się';
}


}

	

}




?>