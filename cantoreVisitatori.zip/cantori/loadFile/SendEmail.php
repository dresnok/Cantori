<?php



function calculateAverageLoadTime($times) {
    if (empty($times)) {
        return 0; // Dla uproszczenia zakładam, że średni czas to 0, gdy brak danych
    }
    return array_sum($times) / count($times);
}

//IF(file_exists(VISITS_FILE_S)){
if (isset($LOAD_TIMES)) {
    if (function_exists('calculateAverageLoadTime')) {
        // Obliczenie średniego czasu ładowania
        $averageLoadTime = calculateAverageLoadTime($LOAD_TIMES);
        // Pobranie 5 ostatnich wpisów, jeśli istnieją
        $lastEntries = array_slice($LOAD_TIMES, -5);
    } else {
        $averageLoadTime = 0;
        $newInfo[] = "Wczytywanie wyników: błąd funkcji 'calculateAverageLoadTime'.";
    }
} else {
    // Przypadek, gdy zmienna $LOAD_TIMES nie istnieje
    $averageLoadTime = 0; // Dla uproszczenia zakładam, że średni czas to 0, gdy brak danych
    $lastEntries = []; // Ustawienie pustej tablicy dla ostatnich wpisów
}



$userIp = $_SERVER['REMOTE_ADDR'];
?>

<?php

function sumSpecifiedFilesWeightInMegabytes($dir, $extensions) {
        $totalWeight = 0;
        $files = new RecursiveIteratorIterator(new RecursiveDirectoryIterator($dir));
        foreach ($files as $file) {
            if ($file->isFile()) {
                $extension = $file->getExtension();
                if (in_array($extension, $extensions)) {
                    $totalWeight += $file->getSize();
                }
            }
        }
        // Konwersja z bajtów na megabajty
        $totalWeightMegabytes = $totalWeight / (1024 * 1024);
        return $totalWeightMegabytes;
    }


if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['seeMore'])) {

include"cantori/loadFile/specyficFiles.php";

    // Funkcja do obliczania wagi plików w megabajtach
try {
    // Sprawdzenie, czy funkcja istnieje przed jej wywołaniem
    if (function_exists('sumSpecifiedFilesWeightInMegabytes')) {
        // Obliczenie wagi plików dla każdej kategorii
        $totalFolderWeightMegabytesText = sumSpecifiedFilesWeightInMegabytes($folderPath, SPECIFIED_EXTENSIONS_TEXT);
        $totalFolderWeightMegabytesImage = sumSpecifiedFilesWeightInMegabytes($folderPath, SPECIFIED_EXTENSIONS_IMAGE);
        $totalFolderWeightMegabytesAudio = sumSpecifiedFilesWeightInMegabytes($folderPath, SPECIFIED_EXTENSIONS_AUDIO);
        $totalFolderWeightMegabytesScripts = sumSpecifiedFilesWeightInMegabytes($folderPath, SPECIFIED_EXTENSIONS_SCRIPTS);
        $totalFolderWeightMegabytesArchiwe = sumSpecifiedFilesWeightInMegabytes($folderPath, SPECIFIED_EXTENSIONS_ARCHIWE);
        $totalFolderWeightMegabytesOther = sumSpecifiedFilesWeightInMegabytes($folderPath, SPECIFIED_EXTENSIONS_OTHER);

        // Formatowanie wyników do dwóch miejsc po przecinku
        $waga_pText = number_format($totalFolderWeightMegabytesText, 2);
        $waga_pImage = number_format($totalFolderWeightMegabytesImage, 2);
        $waga_pAudio = number_format($totalFolderWeightMegabytesAudio, 2);
        $waga_pScripts = number_format($totalFolderWeightMegabytesScripts, 2);
        $waga_pArchiwe = number_format($totalFolderWeightMegabytesArchiwe, 2);
        $waga_pOther = number_format($totalFolderWeightMegabytesOther, 2);
		
	$newInfo[] = "Dane wczytane poprawnie (Rozmiar projektu).";
    
    } else {
        // Jeśli funkcja nie istnieje, ustaw wartości na 0 i zapisz błąd
        $totalFolderWeightMegabytesText = 0;
        $totalFolderWeightMegabytesImage = 0;
        $totalFolderWeightMegabytesAudio = 0;
        $totalFolderWeightMegabytesScripts = 0;
        $totalFolderWeightMegabytesArchiwe = 0;
        $totalFolderWeightMegabytesOther = 0;

	$newInfo[] = "Wystąpił błąd: funkcja sumSpecifiedFilesWeightInMegabytes nie istnieje.";
    
	        
    }
} catch (Exception $e) {
    // Obsługa błędów sesji
    $totalFolderWeightMegabytesText = 0;
	
	$newInfo[] = 'Wystąpił błąd: podczas przetwarzania funcji sumSpecifiedFilesWeightInMegabytes: ' . $e->getMessage();
    
    
}

// Dalej kontynuuj wykonywanie skryptu

    try {
        // Zapisywanie wartości do sesji
        $_SESSION['waga_pText'] = $waga_pText;
        $_SESSION['waga_pImage'] = $waga_pImage;
        $_SESSION['waga_pAudio'] = $waga_pAudio;
        $_SESSION['waga_pScripts'] = $waga_pScripts;
        $_SESSION['waga_pArchiwe'] = $waga_pArchiwe;
        $_SESSION['waga_pOther'] = $waga_pOther;
    } catch (Exception $e) {
		
		
    // Obsługa błędów sesji
	$newInfo[] = 'Wystąpił błąd podczas przetwarzania danych sesji: ' . $e->getMessage();
    
    
}
}
?>
<?php
date_default_timezone_set('Europe/Warsaw');

// Pobierz aktualny czas
$now = new DateTime();

// Ustaw formatowanie na polski
$formatter_time = new IntlDateFormatter(
    'pl_PL', 
    IntlDateFormatter::SHORT, 
    IntlDateFormatter::NONE, 
    'Europe/Warsaw'
);
$formatter_date = new IntlDateFormatter(
    'pl_PL', 
    IntlDateFormatter::FULL, 
    IntlDateFormatter::NONE, 
    'Europe/Warsaw'
);

// Sformatuj czas i datę
$time = $now->format('H:i:s');
$date = $formatter_date->format($now);
?>



<?php

	


if ( isset($_POST['wykluczenia'])){


   // Funkcja do walidacji adresu IP
    function isValidIP($ip) {
        return filter_var($ip, FILTER_VALIDATE_IP) !== false;
    }

    // Ścieżka do pliku
    $filePath = IPEX;

    // Sprawdzenie czy plik istnieje, jeśli nie to tworzenie pliku
    if (!file_exists($filePath)) {
        $fileDir = dirname($filePath);
        if (!is_dir($fileDir)) {
            mkdir($fileDir, 0777, true);
        }
        touch($filePath);
    }

    // Odczyt zawartości pliku do tablicy
    $existingIPs = file($filePath, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);

    // Funkcja do sprawdzenia, czy adres IP już istnieje w pliku
    function ipExists($ip, $existingIPs) {
        return in_array($ip, $existingIPs);
    }

if (isset($_POST['action']) && $_POST['action'] === 'dodaj_local') {
    // Przetwarzanie checkboxów
    if (isset($_POST['address'])) {
        foreach ($_POST['address'] as $address) {
            if ($address === '127.0.0.1' && !ipExists('127.0.0.1', $existingIPs)) {
                file_put_contents($filePath, "127.0.0.1\n", FILE_APPEND);
							$newInfo [] = "Dodano wykluczenie: $address (Wykluczenia IP).";
        
            } elseif ($address === 'moj_adres_ip') {
                $myIPAddress = $_SERVER['REMOTE_ADDR']; // Przykładowe aktualne IP
                if (!ipExists($myIPAddress, $existingIPs)) {
                    file_put_contents($filePath, "$myIPAddress\n", FILE_APPEND);
					$newInfo [] = "Dodano wykluczenie: $myIPAddress (Wykluczenia IP).";
        
                }
            }
        }
		
    }
}

    // Dodawanie wykluczenia
	 if (isset($_POST['action']) && $_POST['action'] === 'dodaj_wykluczenie') {
    if (!empty($_POST['dodaj_wykluczenie'])) {
        $dodaj_wykluczenie = $_POST['dodaj_wykluczenie'];
        if (isValidIP($dodaj_wykluczenie) && !ipExists($dodaj_wykluczenie, $existingIPs)) {
            file_put_contents($filePath, "$dodaj_wykluczenie\n", FILE_APPEND);
			$newInfo [] = "Dodano wykluczenie: $dodaj_wykluczenie (Wykluczenia IP).";
       
            
        } elseif (!isValidIP($dodaj_wykluczenie)) {
			$newInfo [] = "Nieprawidłowy adres IP do dodania. (Wykluczenia IP).";
       
            
        } else {
			$newInfo [] = "Adres IP już istnieje. (Wykluczenia IP).";
       
           
        }
    }
	 }

if (isset($_POST['action']) && $_POST['action'] === 'usun_wykluczenie') {
    // Usuwanie wykluczenia
    if (!empty($_POST['usun_wykluczenie'])) {
        $usun_wykluczenie = $_POST['usun_wykluczenie'];
        if (isValidIP($usun_wykluczenie)) {
            $fileContents = file_get_contents($filePath);
            $fileContents = str_replace("$usun_wykluczenie\n", '', $fileContents);
            file_put_contents($filePath, $fileContents);
			$newInfo [] = "Usunięto wykluczenie: $usun_wykluczenie (Wykluczenia IP).";
       
		
            
        } else {
		$newInfo [] = "Nieprawidłowy adres IP do usunięcia. (Wykluczenia IP).";
       

        }
    }
}

    // Usuwanie wszystkich wykluczeń
    if (isset($_POST['action']) && $_POST['action'] === 'usun_wszystkie_wykluczenia') {
        file_put_contents($filePath, '');
		$newInfo [] = "Usunięto wszystkie wykluczenia. (Wykluczenia IP).";
        
       
    }
}


if(isset($_POST['new_password'])) {


    $new_password = $_POST['new_password'];
    $confirm_password = $_POST['confirm_password'];

        // Sprawdź, czy nowe hasło i potwierdzenie są takie same
        if ($new_password === $confirm_password) {
            // Zhashuj nowe hasło
            $new_hashed_password = password_hash($new_password, PASSWORD_DEFAULT);

            // Zaktualizuj plik z hasłem, tylko zmieniając linię z hasłem
            $password_file_content = file('cantori/password.php');
            foreach ($password_file_content as &$line) {
                if (strpos($line, "define('HASHED_PASSWORD'") !== false) {
                    $line = "define('HASHED_PASSWORD', '" . $new_hashed_password . "');\n";
                    break;
                }
            }
            file_put_contents('cantori/password.php', implode('', $password_file_content));


			$newInfo[] = "Hasło zostało zmienione.";
		
				
            
        } else {
			 $newInfo [] = 'Błąd: nowe hasło i potwierdzenie nie są takie same.';

} 
}


if(isset($_POST['downloadFile'])) {

$directory = "cantori/downloadFile/";
if (!is_dir($directory)) {
    mkdir($directory, 0777, true);
}
// Generowanie unikatowej nazwy pliku
$unique_filename = uniqid('raport_', true) . '.html';
$file_path = "$directory/$unique_filename";

$file = fopen($file_path, "w");
if ($file) {
    
    fwrite($file, $message);
    fclose($file);

    // Opcjonalnie, przekierowanie do pobrania pliku
    header('Content-Type: application/octet-stream');
    header('Content-Disposition: attachment; filename="' . $unique_filename . '"');
    readfile($file_path);
	
	$newInfo [] = "Pobrałem plik: $unique_filename";

	}
	
	else {
	$newInfo [] = 'Pobranie pliku nie powidło się';
}


}

?>