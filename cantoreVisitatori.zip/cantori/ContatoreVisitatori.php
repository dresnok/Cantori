<?php
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

define('VISITS_FILE', 'cantori/visits.php');
define('VISITORS_FILE', 'cantori/visitors.txt');
define('SUSIP_FILE', 'cantori/susip.txt');
define('ERROR_FILE', 'errorFile.log');
define ('FUNCTION_CANTORI', 'cantori/loadFile/function_cantori.php');
define('VISITS_FILE_S', 'cantori/visits2.php');

if(file_exists(VISITS_FILE_S)){include (VISITS_FILE_S);}
include_once(FUNCTION_CANTORI);

include_once'cantori/loadFile/vistits_file.php';
if(!file_exists(VISITS_FILE)){justTo(VISITS_FILE);}else {
    include VISITS_FILE;
}

function saveVisitCounts($dailyVisits, $weeklyVisits, $monthlyVisits, $monthlyData, $uniqueIpVisits) {
    $data = "<?php\n";
    $data .= "define('NA_DZIEN', $dailyVisits);\n";
    $data .= "define('NA_TYDZIEN', $weeklyVisits);\n";
    $data .= "define('NA_MIESIAC', $monthlyVisits);\n";
    $data .= "define('VISITORS_UNIK_IP', $uniqueIpVisits);\n";
    
    
    foreach ($monthlyData as $month => $count) {
        $data .= "define('$month', $count);\n";
    }
    
    $data .= "?>";
    
    file_put_contents(VISITS_FILE, $data);
}

checkNewYear();

// Pobranie aktualnej daty i godziny
$time = date("Y-m-d H:i:s");

// Pobranie adresu IP użytkownika
$userIp = $_SERVER['REMOTE_ADDR'];

// Odczytaj istniejącą zawartość pliku lub inicjalizuj pustą tablicę
$visitors = file_exists(VISITORS_FILE) ? unserialize(file_get_contents(VISITORS_FILE)) : [];

// Dodaj nowy adres IP, jeśli go nie ma w tablicy
if (!in_array($userIp, $visitors)) {
    $visitors[] = $userIp;
    // Zapisz zaktualizowaną tablicę z powrotem do pliku
    file_put_contents(VISITORS_FILE, serialize($visitors));
}

date_default_timezone_set('Europe/Warsaw');
// Pobranie adresu URL
$url = $_SERVER['REQUEST_URI'];

// Pobranie adresu IP serwera
$serverIp = $_SERVER['SERVER_ADDR'];


$browsers = [
    'Chrome' => 'Google Chrome',
    'Firefox' => 'Mozilla Firefox',
    'Safari' => 'Safari',
    'MSIE' => 'Internet Explorer',
    'Trident' => 'Internet Explorer',
    'Edge' => 'Microsoft Edge'
];

$osList = [
    'Windows NT 10.0' => 'Windows 10',
    'Windows NT 6.3' => 'Windows 8.1',
    'Windows NT 6.2' => 'Windows 8',
    'Windows NT 6.1' => 'Windows 7',
    'Macintosh' => 'Mac OS',
    'Linux' => 'Linux',
    'Android' => 'Android',
    'iPhone' => 'iOS',
    'iPad' => 'iOS'
];
$userAgent = $_SERVER['HTTP_USER_AGENT'];
$browser = 'Inna przeglądarka';
foreach ($browsers as $key => $value) {
    if (strpos($userAgent, $key) !== false) {
        $browser = $value;
        break;
    }
}

$os = 'Inny system operacyjny';
foreach ($osList as $key => $value) {
    if (strpos($userAgent, $key) !== false) {
        $os = $value;
        break;
    }
}

// Złożenie danych w jeden ciąg znaków
$logEntry = $url . "|" . $browser . "|" . $os . "|" . $time . "|" . $userIp . "|" . $serverIp . PHP_EOL;

    // Zapisanie danych do pliku logu
    file_put_contents(SUSIP_FILE, $logEntry, FILE_APPEND);


function checkNewYear() {
    $currentYear = date('Y');
    $lastYear = $currentYear - 1;
    $lastYearFile = 'cantori/last_year/visits_' . $lastYear . '.php';
    $lastYearFile1 = 'cantori/last_year/susip_' . $lastYear . '.php';

    // Sprawdzenie, czy data to 22 sierpnia i czy backup już istnieje
    if (date('m-d') !== '01-01' || file_exists($lastYearFile)) {
        return;
    }

    // Kopiowanie pliku VISITS_FILE
    if (file_exists(VISITS_FILE)) {
        if (copy(VISITS_FILE, $lastYearFile)) {
            $newFile[] = "Plik 'visits' został skopiowany: " . $lastYearFile;
        } else {
            $newFile[] = "Backup z ostatniego roku dla 'visits' nie powiódł się.";
        }
    } else {
        $newFile[] = "Plik 'visits' nie istnieje.";
    }

}

function resetCountersIfNeeded() {

    // Przypisanie wczytanych wartości do zmiennych sesji
    $_SESSION['unique_visits_day'] = NA_DZIEN;
    $_SESSION['unique_visits_week'] = NA_TYDZIEN;
    $_SESSION['unique_visits_month'] = NA_MIESIAC;
    $_SESSION['monthly_visits'] = array(
        'STYCZEN' => STYCZEN,
        'LUTY' => LUTY,
        'MARZEC' => MARZEC,
        'KWIECIEN' => KWIECIEN,
        'MAJ' => MAJ,
        'CZERWIEC' => CZERWIEC,
        'LIPIEC' => LIPIEC,
        'SIERPIEN' => SIERPIEN,
        'WRZESIEN' => WRZESIEN,
        'PAZDZIERNIK' => PAZDZIERNIK,
        'LISTOPAD' => LISTOPAD,
        'GRUDZIEN' => GRUDZIEN,
    );
    $_SESSION['unique_ip_visits'] = VISITORS_UNIK_IP;

    // Sprawdzenie nowego tygodnia
    $currentDate = date('Y-m-d'); // Aktualna data
    $dayOfWeek = date('N', strtotime($currentDate)); // 1 oznacza poniedziałek

    if ($dayOfWeek == 1) { // Jeśli jest poniedziałek
        $_SESSION['unique_visits_week'] = 0; // Resetowanie licznika tygodniowego
    }

    // Sprawdzenie nowego miesiąca
    if (date('j') == 1) { // Jeśli to pierwszy dzień miesiąca
        $_SESSION['unique_visits_month'] = 0; // Resetowanie licznika miesięcznego
    }

  
}




function countUniqueVisit() {
    resetCountersIfNeeded();

/* $currentDate = '2024-09-01'; // Ustawiasz na pierwszy dzień miesiąca

// Używając symulowanej daty
if (date('j', strtotime($currentDate)) == 1) {
    // Początek nowego miesiąca
    $_SESSION['unique_visits_month'] = 0; // Resetowanie licznika miesięcznego
} */


    if (!isset($_SESSION['unique_visits_day'])) {
        $_SESSION['unique_visits_day'] = NA_DZIEN;
    }

    if (!isset($_SESSION['unique_visits_week'])) {
        $_SESSION['unique_visits_week'] = NA_TYDZIEN;
    }

    if (!isset($_SESSION['unique_visits_month'])) {
        $_SESSION['unique_visits_month'] = NA_MIESIAC;
    }

    if (!isset($_SESSION['monthly_visits'])) {
        $_SESSION['monthly_visits'] = array(
            'STYCZEN' => STYCZEN,
            'LUTY' => LUTY,
            'MARZEC' => MARZEC,
            'KWIECIEN' => KWIECIEN,
            'MAJ' => MAJ,
            'CZERWIEC' => CZERWIEC,
            'LIPIEC' => LIPIEC,
            'SIERPIEN' => SIERPIEN,
            'WRZESIEN' => WRZESIEN,
            'PAZDZIERNIK' => PAZDZIERNIK,
            'LISTOPAD' => LISTOPAD,
            'GRUDZIEN' => GRUDZIEN,
        );
    }

    // Dodano: inicjalizacja sesji dla unikalnych IP
    if (!isset($_SESSION['unique_ip_visits'])) {
        $_SESSION['unique_ip_visits'] = VISITORS_UNIK_IP;
    }

    if (!isset($_COOKIE['unique_visit'])) {
        $_SESSION['unique_visits_day'] += 1;
        $_SESSION['unique_visits_week'] += 1;
        $_SESSION['unique_visits_month'] += 1;
        $_SESSION['unique_ip_visits'] += 1; // Aktualizacja unikalnych IP

        $englishToPolishMonths = [
            'January' => 'STYCZEN',
            'February' => 'LUTY',
            'March' => 'MARZEC',
            'April' => 'KWIECIEN',
            'May' => 'MAJ',
            'June' => 'CZERWIEC',
            'July' => 'LIPIEC',
            'August' => 'SIERPIEN',
            'September' => 'WRZESIEN',
            'October' => 'PAZDZIERNIK',
            'November' => 'LISTOPAD',
            'December' => 'GRUDZIEN',
        ];
        $currentMonth = strtoupper($englishToPolishMonths[date('F')]);

        $_SESSION['monthly_visits'][$currentMonth] += 1;

//        setcookie('unique_visit', '1', time() + (86400), "/"); // 86400 sekund = 1 dzień

        saveVisitCounts(
            $_SESSION['unique_visits_day'],
            $_SESSION['unique_visits_week'],
            $_SESSION['unique_visits_month'],
            $_SESSION['monthly_visits'],
            $_SESSION['unique_ip_visits'] // Przekazanie wartości unikalnych IP
        );
    }
}

// Wywołaj funkcję zliczającą unikalne odwiedziny
countUniqueVisit();


if (!empty($newFile)) {
    $errorData = "Data błędu: " . date('Y-m-d H:i:s') . "\n";
    $errorData .= "Lista błędów:\n";
    foreach ($newFile as $error) {
        $errorData .= $error . "\n";
    }
    $errorData .= "\n";

    file_put_contents(ERROR_FILE, $errorData, FILE_APPEND);
}


?>
</p>


