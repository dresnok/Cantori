<?php
define('HASHED_PASSWORD', '$2y$10$I7ePT8KEwSs0dnBsRoaXNewR3s.zxnrN4QNZ8Q0ovQ3Akgb9xP7sm');
define('USER_ID', 'amin');