<?php
define('HASHED_PASSWORD', '$2y$10$9aU5zq/jUb.EdIdSE8FlMexU4zAEbb6.C85Mm11gKXOYHSwS5vLoC');
define('USER_ID', 'amin');