<?php
define('HASHED_PASSWORD', '$2y$10$6EUHK9gjMq11UpjMa/Z7/eNXlL9VbkqnGJ2yxrbOfcfctehMqzMWi');
define('USER_ID', 'amin');