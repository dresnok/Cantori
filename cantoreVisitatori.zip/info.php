  <?php
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

if (!isset($_SESSION['user_id'])) {
    header('Location: cantori/login.php');
    exit();
}


include_once'cantori/modifica.php';
include_once'cantori/loadFile/vistits_file.php';



if ($_SERVER["REQUEST_METHOD"] === "POST" && isset($_POST['visits_file_s'])) {
    file_put_contents(VISITS_FILE_S, "<?php\nconst LOAD_TIMES = array ();\n?>");
}

if(file_exists(SFONDO)){include_once(SFONDO);}
if (file_exists(VISITS_FILE_S)) {
    include VISITS_FILE_S;
} elseif(empty($_SESSION['refresh_count'])) {
	
	$_SESSION['refresh_count'] = 1;
	
    $_SESSION['newInfo'] = 'Prawdopodobnie nie chcesz lub nie dołączyłeś kodu niezbędnego do pomiaru szybkości wczytywania strony, sprawdź plik <a href="readme.html" target="_blank" title="readme">readme.html</a>, lub na stronie <a href="https://github.com/dresnok/Cantori" target="_blank">https://github.com/dresnok/Cantori</a>.<br><form action="' . htmlspecialchars($_SERVER['PHP_SELF']) . '" method="post"><input type="hidden" name="visits_file_s"><label><i>Utwórz plik tymczasowy</i> </label> <input value="Prześlij" type="submit"></form>';
}


if(file_exists(FUNCTIONE)){include_once(FUNCTIONE);}

if(file_exists(PASSWORD_T)){include_once(PASSWORD_T);}
if(file_exists(SENDEMAIL)){include(SENDEMAIL);}

?>

<!DOCTYPE html>
<html lang="pl">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Panel Statystyk Strony</title>
  <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet"><link id="customStylesheet" rel="stylesheet" href="cantori/css/normalize.css">
  <link id="customStylesheet" rel="stylesheet" href="cantori/css/styl-gl.css">
  
  <link href="https://fonts.googleapis.com/css2?family=Cairo+Play:wght@200..1000&display=swap" rel="stylesheet">

  <style>
  
  @import url('https://fonts.googleapis.com/css2?family=Cairo+Play:wght@200..1000&display=swap');

@import url('https://fonts.googleapis.com/css2?family=Reem+Kufi+Fun:wght@400..700&display=swap');


  body {
	  background:url(<?php displayFilePaths(TARGETDIRECTORY); ?>) no-repeat;
	  background-attachment: fixed;
        background-color: #1e2b35;
		background-size: cover;
        color: #cdd3d8;
        font-family:  Arial, sans-serif;
		
    }

    .container {
        width: 70%;
        margin: 0 auto;
        background-color: #2d3e50;
        padding: 20px;
        border-radius: 8px;
        box-shadow: 0 0 10px rgba(0, 0, 0, 0.5);
    }

.container a {
	font-family: "Reem Kufi Fun", sans-serif, Arial, sans-serif;
}
    .table td, .table th {
        padding: 10px;
        border: 1px solid #2d3e50;
        text-align: left;
        border-radius: 5px;
        transition: background-color 0.3s;
        background-color: #3a4b61;
        color: #cdd3d8;
    }

    .table td:hover, .table th:hover {
        background-color: #4e6a88;
    }

    .section, .header {
        margin-bottom: 20px;
    }

    .section h2 {
        font-size: 1.5em;
        margin-bottom: 15px;
        color: #7aa6c7;
    }

    .header h1 {
        font-size: 2em;
        margin-bottom: 15px;
        color: #cdd3d8;
    }

    .header h5 {
        font-size: 1.2em;
        color: #7aa6c7;
    }

    button[type="submit"], input[type="submit"], input[type="button"], input[type="file"], button, select {
        padding: 10px 20px;
        border: none;
        border-radius: 5px;
        cursor: pointer;
        font-size: 16px;
        background-color: #6a8eae;
        color: #fff;
        transition: background-color 0.3s;
		margin:3px;
    }

    button[type="submit"], input[type="submit"], input[type="button"], input[type="file"], button, select {
        background-color: #587a9b;
		
    }

    form {
        display: inline;
    }
@media (max-width: 800px) { 
td.at > input {
	width:50px;
}
 }

td.userIpCounts {max-height: 800px;
overflow-y: auto;display: block; }

a:link.vok, a:visited.vok {
	color:grey;
	
}

</style>
</head>
<body>




<?php


if(isset($_SESSION['newInfo'])){
	echo "<div class='alert alert-secondary'>" . $_SESSION['newInfo'] . "</div>";$_SESSION['refresh_count']++;

if ($_SESSION['refresh_count'] > 3) {
	unset ($_SESSION['newInfo']);
	}	
}

if(isset($newInfo)){
	$errorData = "Data błędu: " . date('Y-m-d H:i:s') . "\n";
	$errorData .= "Lista błędów:\n";
	
	foreach($newInfo as $good_info)
	{
	echo "<div class='alert alert-secondary'>" . $good_info . "</div>";
	$errorData .= $good_info . "\n";
	}
	
	file_put_contents('errorFile.log', mb_convert_encoding($errorData . PHP_EOL, 'UTF-8'), FILE_APPEND);

}
?> 


<div class="container">
    <div class="header">
	<div class="row my-3">
	<div class="col-6">
        <h1 style="display:inline">Panel Administracyjny</h1><br>
		<a href="https://accordian.org.pl/" title="link" class="vok">https://accordian.org.pl/</a>
		</div>
		<div class="clock col-6">
        <div class="time">
            <?php echo $time; ?>
        </div>
        <div class="date">
            <?php echo $date; ?>
			<p><a href="http://cantori.antyki.space/" title="link" class="vok">http://cantori.antyki.space/</a></p>
    </div></div></div>
		
		<div class="my-3">
		   <form method="post" action="cantori/login.php">
        
        <input type="hidden" name="logout">
        <input type="submit" value="Logout">
    </form></div>

    <!-- Wyświetlanie wyników tylko po wysłaniu formularza -->

        <div class="section">
            <h2>Rozmiar projektu (<?php echo $_SERVER['DOCUMENT_ROOT'];?>/)</h2>
			<form method="post" action="<?php echo htmlspecialchars($_SERVER['PHP_SELF']); ?>">
            
            <input type="hidden" name="seeMore">
            <button type="submit">Wczytaj dane</button>
        </form>
		
        </div>
		    <?php if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['seeMore'])): ?>
        <div class="section">
            <table class="table">
                <tbody>
                    <tr>
                        <td>Pliki tekstowe: <?php if (isset($waga_pText)) echo $waga_pText; ?> MB</td>
                    </tr>
                    <tr>
                        <td>Pliki graficzne: <?php if (isset($waga_pImage)) echo $waga_pImage; ?> MB</td>
                    </tr>
                    <tr>
                        <td>Pliki audio: <?php if (isset($waga_pAudio)) echo $waga_pAudio; ?> MB</td>
                    </tr>
                    <tr>
                        <td>Pliki skryptowe: <?php if (isset($waga_pScripts)) echo $waga_pScripts; ?> MB</td>
                    </tr>
                    <tr>
                        <td>Pliki archiwów: <?php if (isset($waga_pArchiwe)) echo $waga_pArchiwe; ?> MB</td>
                    </tr>
                    <tr>
                        <td>Inne pliki: <?php if (isset($waga_pOther)) echo $waga_pOther; ?> MB</td>

                    </tr>

                </tbody>
            </table>

        </div>
		   <?php endif; ?>



<div class="section">
            <h2>Średni czas ładowania strony (cantori/visits.php)</h2>
			
			<div class="section">
            
            <table class="table">
			<tbody><tr>
           <td><?php echo number_format($averageLoadTime, 2); ?> ms</td>
			</tbody>
			</table>
						
			
			</div></div>
			
			<div class="section">
			
			<table class="table">
                <tbody>
           
			<tr><td> 5 ostanich wspisów:</td></tr> 
<?php

$time = date("Y-m-d H:i:s");

 foreach ($lastEntries as $time) {
    echo "<tr><td>$time ms</td></tr>";
}; ?>
			
            
			</tbody></table>
				</div>
		

<!-- Wizyty użytkowników -->
<div class="section">
            <h2>Wizyty użytkowników na stronie (cantori/visits.php)</h2>
			
			<div class="section">
            
            <table class="table">
			
			 <thead>
                    <tr>
                        <th>W tym dniu</th>
<th>W tym tygodniu</th>
<th>W tym miesiącu</th>

                    </tr>
                </thead>
				
			<tbody><tr>
            <td><?php echo (!empty($_SESSION["unique_visits_day"]) ? $_SESSION["unique_visits_day"] : "");
			
?></td>
            <td><?php echo (!empty($_SESSION["unique_visits_week"]) ? $_SESSION["unique_visits_week"] : "");
?></td>
            <td><?php echo (!empty($_SESSION["unique_visits_month"]) ? $_SESSION["unique_visits_month"] : "");
?></td>
			
			</tr>
			</tbody>
			</table>
						
			
			</div></div>
			
<!-- Statystyki odwiedzin -->
<div class="section" id="st_od">
            <h2>Statystyki odwiedzin (cantori/visits.php)</h2>
			
			</div>
			
			<div class="section">
		<form action="cantori/loadFile/seeMoreFile.php" method="post">
		<table class="table">

           
<?php $months = ['STYCZEN', 'LUTY', 'MARZEC', 'KWIECIEN', 'MAJ', 'CZERWIEC', 'LIPIEC', 'SIERPIEN', 'WRZESIEN', 'PAZDZIERNIK', 'LISTOPAD', 'GRUDZIEN'];
?>
 <?php foreach ($months as $month): ?>

		<tr>
		<td class="col-4"><?php echo $month; ?></td>
		<td class="at col-4">
		
		<input type="number" name="visits_<?php echo $month; ?>" value="<?php echo $_SESSION["monthly_visits"][$month] ?? ''; ?>">
		</td>
		<td class="col-4">
		<input type="submit" name="submit_<?php echo $month; ?>" value="Zapisz">
		
		</td></tr>
		
		
            <?php endforeach; ?>

	<tr><td>
    

 <!-- Wybór akcji -->
    <label for="actionSelect">Wybierz akcję:</label>
    <select name="action" id="actionSelect">
        <option value="submit_statysty">Zapisz wszystkie zmiany</option>
        <option value="reset_statysty">Resetuj wszystkie dane</option>
        <option value="statystyka_backup">Wykonaj backup</option>
		<input type="hidden" name="SeeMoreFile">
    </select>

    
	<input type="hidden" name="reset_all">
    <input type="submit" value="Wykonaj">
</form>

</td></tr>
    

    
	</table>
				</div>
				

<!-- Operacje -->
<div class="section">
            <h2>Statystyka raportu (cantori/susip.txt)</h2>
		
			

			</div>
			<div class="section bla">
			<table class="table">
                <tbody>
           
			<tr>
			
			<td>
			URL Counts:
			</td>
			<td class="userIpCounts">
			
			<?php

// Pobranie adresu URL
$url = $_SERVER['REQUEST_URI'];
foreach ($urlCounts as $url => $count) {
echo "$url: $count<br>";

}

?>

			</td>
			</tr>
			
						<tr>
			
			<td>
			Browser Counts:
			</td>
			<td>
			<?php
foreach ($browserCounts as $browser => $count) {
    echo "$browser: $count<br>";
}
?>
			</td>
			</tr>
			
									<tr>
			
			<td>
			OS Counts:
			</td>
			<td>
			<?php
foreach ($osCounts as $os => $count) {
    echo "$os: $count<br>";
}
?>
			</td>
			</tr>
			
							<tr>
			
			<td>
			User IP Counts:
			</td>
<td class="userIpCounts">
			<?php
foreach ($userIpCounts as $userIp => $count) {
    echo "$userIp: $count<br>";
}
?>

			</td>
			</tr>
			
										<tr>
			
			<td>
			Server IP Counts:
			</td>
			<td>

			<?php
foreach ($serverIpCounts as $userIp => $count) {
    echo "$userIp: $count<br>";
}
?>

			</td>
			</tr>
			
<tr><td>			
			<form action="cantori/loadFile/seeMoreFile.php" method="post">

	
	<label for="actionSelect">Wybierz opcję:</label>
	
    <select name="action" id="actionSelect">
        <option value="susipBackup">Backup</option>
        <option value="susipReset">Reset</option>
    </select>
	<input type="hidden" name="raport_all">
    <input type="submit" value="Wykonaj">
	<input type="hidden" name="SeeMoreFile">
</form>
</td>
			</tr>

			</table>
                </tbody>
			</div>
			
			
			<?php

// Plik z danymi odwiedzających
// Odczytaj istniejącą zawartość pliku lub inicjalizuj pustą tablicę
if (file_exists(VISITORS_FILE)) {
    $visitors = unserialize(file_get_contents(VISITORS_FILE));
} else {
    $visitors = [];
}
$ip_show = count($visitors);

if(!file_exists(VISITORS_UNIK)){
$newVisitorContent = "<?php\n";
$newVisitorContent .= "define('VISITORS_UNIK_IP', 0);\n";
$newVisitorContent .= "?>";
file_put_contents(VISITORS_UNIK, $newVisitorContent);
}
include VISITORS_UNIK;
?>


<!-- unikalne odwiedziny -->
<div class="section">
            <h2 id="ipUnik">Unikalne adresy IP (cantori/visitors.txt)</h2>

	</div>
			
			<div class="section">
            
            <table class="table">
			<tbody><tr>
            <td>Według tabeli: <?php if(!empty($ip_show)){ echo $ip_show;}?></td>
            <td>Wszystko od poczatku: <?php echo VISITORS_UNIK_IP . ""; ?></td>
			
			
			</tr>

			</tbody>
			</table>
						
			
			</div>
			
			<div class="section telaio">
			
			<table class="table">
                <tbody>
            <?php
foreach ($visitors as $ip) {
    echo '
			<tr><td>' . $ip . '</td></tr>';
} ?>
            
			
						<tr><td>
							
<form action="cantori/loadFile/seeMoreFile.php" method="post">
    <input type="hidden" name="res_uip">
		
	<label for="actionSelect">Wybierz opcję:</label>
    
    <select name="action" id="actionSelect">
        <option value="visitorsBackup">Backup</option>
        <option value="visitorsReset">Reset</option>
    </select>
    <input type="submit" value="Wykonaj">
	<input type="hidden" name="SeeMoreFile">
</form>


				
				</td></tr>
				
			</tbody></table>
				</div>
				
				
				<div class="section">
            <h2 id="ipUnik">Statystyki upływu czasu</h2>

	</div>
			
			<div class="section">
            
            <table class="table">
			<tbody><tr>
            <td>
			Utworzenie panelu (info.php)
			</td>
            
			<td>
			<?php echo "Minęło dni: " . timeSinceFileCreation(INFO_FILE);?>
			
			</td></tr>
			
			<tr><td>
			
			<a href="cantori/dodatki/editFile.php?file=visits" target="blank" title="visits">Statystyki odwiedzin (cantori/visits.php)</a>
		
			
			</td>
            
			<td>


			<?php echo "Minęło dni: " . timeSinceFileCreation(VISITS_FILE);
			?>
			
			</td>
			
			
			</tr><tr>
			
			<tr><td>
			
			<a href="cantori/dodatki/editFile.php?file=susip" target="blank" title="susip">Raporty (cantori/susip.php)</a>
		
			
			</td>
            
			<td>
			<?php echo "Minęło dni: " . timeSinceFileCreation(SUSIP_FILE);?>
			
			</td>
			
			
			</tr><tr>
			<td>
			<a href="cantori/dodatki/editFile.php?file=errorFile" target="blank" title="errorFile">Logi (errorFile.log):</a>
				
			
			</td>
            
			<td>
			
			
			<?php echo "Minęło dni: " . timeSinceFileCreation(ERROR_FILE);?>
			
			</td>
			
			
			</tr>
			
			
			<!-- VISITORS_FILE-->
			<tr>
			<td>
			<a href="cantori/dodatki/editFile.php?file=visitors" target="blank" title="errorFile">Unikalne adresy IP (visitors.txt):</a>
				
			
			</td>
            
			<td>
			
			
			<?php echo "Minęło dni: " . timeSinceFileCreation(VISITORS_FILE);?>
			
			</td>
			
			
			</tr>
			
			</tbody>
			</table>
						
			
			</div>
			
	
	


		
<!-- Operacje -->
<div class="section" id="operacje">
            <h2>Operacje</h2>
			<!--<a href="http://kinpin.antyki.space/" title="link" class="vok">http://kinpin.antyki.space/</a>-->
			</div>
			<div class="section bla">
			<table class="table">
                <tbody>
           

			
			
		
		
<tr>
			<td id="genHaslo">
			Generator hasła
			</td>
			
			<td>
			
			<?php
if(isset($_POST['nowe'])){
	if(!empty($hash_hasla)){
echo "<p>" . $hash_hasla . "</p>";
}}

?>

<form action="<?php echo htmlspecialchars($_SERVER['PHP_SELF']); ?>#genHaslo" method="post">
<input name="haslo" placeholder="Podaj hasło do schaszowania" type="password" required>
<input type="hidden" name="nowe" value="1">
<button type="submit">Generuj</button>

</form>

			</td>
			
			</tr>
<tr><td>Zmień hasło</td>
			
			<td>
			  <form action="<?php echo htmlspecialchars($_SERVER['PHP_SELF']); ?>" method="post">
        <label for="old_password">Stare hasło:</label>
        <input type="password" id="old_password" name="password2" required><br><br>
        
        <label for="new_password">Nowe hasło:</label>
        <input type="password" id="new_password" name="new_password" required><br><br>
        
        <label for="confirm_password">Potwierdź nowe hasło:</label>
        <input type="password" id="confirm_password" name="confirm_password" required><br><br>
        
        <input type="submit" value="Zmień hasło">
    </form>
			</td>
			
			</tr>

<tr>
			<td>
			Wygeneruj plik</button>
			</td>
			
<td>

	<form method="post" action="<?php echo htmlspecialchars($_SERVER['PHP_SELF']); ?>">
	<button type="submit" name="downloadFile" disabled>Download</button>
	</form>

</td>
</tr>
			
	
			
			<tr>
			<td>
			Wykluczenia IP
			</td>
		

			<td>
	<form method="post" action="<?php echo htmlspecialchars($_SERVER['PHP_SELF']); ?>">

<label>
<input type="checkbox" name="address[]" value="127.0.0.1">localhost
</label>

<label>
<input type="checkbox" name="address[]" value="moj_adres_ip">Mój adres IP
</label>
<button type="submit" name="action" value="dodaj_local">Dodaj</button>

<p>
        <!-- Dodaj wykluczenie -->
		 <label for="dodaj_wykluczenie">Dodaj wykluczenie:</label>
        <input type="text" name="dodaj_wykluczenie">
        <button type="submit" name="action" value="dodaj_wykluczenie">Dodaj</button>
</p>
<p>
        <!-- Usuń wykluczenie -->
		<label for="usun_wykluczenie">Usuń wykluczenie:</label>
        <input type="text" name="usun_wykluczenie">
        <button type="submit" name="action" value="usun_wykluczenie">Usuń</button>
		</p>

        <!-- Usuń wszystkie wykluczenia -->
        <button type="submit" name="action" value="usun_wszystkie_wykluczenia">Usuń wszystkie wykluczenia</button>

		<input type="hidden" name="wykluczenia">
	</form>

			</td>
			
			</tr>
            
			<tr>
			<td>
			Zmień tło<br>
					<!--<a href="http://contafe.antyki.space/" title="link" class="vok">http://contafe.antyki.space/</a>-->
			</td>
			<td>
		<form method="post" action="<?php echo htmlspecialchars($_SERVER['PHP_SELF']); ?>" enctype="multipart/form-data">
    
    Wybierz plik do przesłania:
    <p>
    <input type="file" name="fileToUpload" id="fileToUpload" required></p>
    
    <p><button type="submit" value="uploadFile" name="zmienTlo">Prześlij plik</button></p>
    </form>
	
	<form method="post" action="<?php echo htmlspecialchars($_SERVER['PHP_SELF']); ?>">
    <select name="action">
        <option value="moveOrDeleteFile">Usuń tło</option>
        <option value="Template_one">Template_one</option>
        <option value="Template_two">Template_two</option>
    </select>
<input type="hidden" name="move_background">
    <p><button type="submit">Wykonaj</button></p>
    
</form>

			</td>
			
			</tr>
			</tbody></table>
				</div>
				


				
<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js"></script><script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
